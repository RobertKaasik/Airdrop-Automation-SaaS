// --- Глобальные переменные и состояние ---
let currentLang = localStorage.getItem('ax_lang') || 'ru';
let isLoggedIn = false;
let currentSection = 'Account';
const localeStore = window.AIRDROP_LOCALES || {};
const translations = localeStore;
const OPTIONAL_STORAGE_CONSENT_KEY = 'ax_optional_storage_consent_v1';

function getOptionalStorageConsent() {
    const value = localStorage.getItem(OPTIONAL_STORAGE_CONSENT_KEY);
    return value === 'accepted' || value === 'essential' ? value : null;
}

function applyOptionalStorageConsent(value) {
    window.AIRDROP_X_OPTIONAL_STORAGE_CONSENT = value === 'accepted';
    window.dispatchEvent(new CustomEvent('ax:optional-storage-consent', {
        detail: { optionalStorageAllowed: value === 'accepted' }
    }));
}

function setOptionalStorageConsent(value) {
    localStorage.setItem(OPTIONAL_STORAGE_CONSENT_KEY, value);
    applyOptionalStorageConsent(value);
    const banner = document.getElementById('cookieConsentBanner');
    if (banner) banner.hidden = true;
}

function initializeCookieConsent() {
    const savedConsent = getOptionalStorageConsent();
    if (savedConsent) {
        applyOptionalStorageConsent(savedConsent);
        return;
    }
    const banner = document.getElementById('cookieConsentBanner');
    if (banner) banner.hidden = false;
}

window.acceptOptionalCookies = () => setOptionalStorageConsent('accepted');
window.declineOptionalCookies = () => setOptionalStorageConsent('essential');
window.hasOptionalStorageConsent = () => getOptionalStorageConsent() === 'accepted';

function getActiveLang() {
    const savedLang = (currentLang || localStorage.getItem('ax_lang') || 'ru').toLowerCase();
    if (savedLang === 'cn') return 'zh';
    return translations[savedLang] ? savedLang : 'ru';
}

function t(key) {
    const lang = getActiveLang();
    const locale = translations[lang] || {};
    const value = key.split('.').reduce((current, part) => current?.[part], locale);
    if (value === undefined || value === null) {
        return key;
    }
    return value;
}

function setLanguage(lang) {
    const normalizedLang = lang === 'cn' ? 'zh' : lang;
    currentLang = translations[normalizedLang] ? normalizedLang : 'ru';
    localStorage.setItem('ax_lang', currentLang);
    document.documentElement.setAttribute('lang', currentLang);
    document.documentElement.setAttribute('data-lang', currentLang);
    document.body.setAttribute('data-lang', currentLang);
    return currentLang;
}

function setFormError(containerId, message, type = 'error', fieldId = '') {
    const container = document.getElementById(containerId);
    if (!container) return;
    const cls = type === 'success' ? 'form-feedback success' : 'form-feedback error';
    const feedback = document.createElement('div');
    feedback.className = cls;
    feedback.textContent = String(message || '');
    container.replaceChildren(feedback);
    if (fieldId) {
        setFieldValidationState(fieldId, false, message);
    }
}

function clearFormError(containerId, fieldId = '') {
    const container = document.getElementById(containerId);
    if (container) container.innerHTML = '';
    if (fieldId) {
        clearFieldValidationState(fieldId);
    }
}

function setFieldValidationState(fieldId, isValid, message = '') {
    const field = document.getElementById(fieldId);
    if (!field) return;
    field.classList.toggle('field-error', !isValid);
    field.dataset.validationMessage = message;
    if (!isValid) {
        field.style.borderColor = '#ef4444';
        field.style.boxShadow = '0 0 0 1px rgba(239, 68, 68, 0.35)';
        field.style.background = 'rgba(239, 68, 68, 0.08)';
    } else {
        field.style.borderColor = '';
        field.style.boxShadow = '';
        field.style.background = '';
    }
}

function clearFieldValidationState(fieldId) {
    const field = document.getElementById(fieldId);
    if (!field) return;
    field.classList.remove('field-error');
    field.dataset.validationMessage = '';
    field.style.borderColor = '';
    field.style.boxShadow = '';
    field.style.background = '';
}

function setButtonLoading(button, isLoading, text = '') {
    if (!button) return;
    if (isLoading) {
        if (!button.dataset.defaultText) button.dataset.defaultText = button.innerText;
        button.classList.add('btn-loading');
        button.disabled = true;
        button.innerText = text || t('loading');
    } else {
        button.classList.remove('btn-loading');
        button.disabled = false;
        const defaultText = text || button.dataset.defaultText || '';
        if (defaultText) button.innerText = defaultText;
        delete button.dataset.defaultText;
    }
}

function renderLoginRateLimitState() {
    const remaining = Math.max(0, Math.ceil((loginRateLimitUntil - Date.now()) / 1000));
    const submitButton = document.getElementById('loginSubmitBtn');
    if (!remaining) {
        if (loginRateLimitTimer) clearInterval(loginRateLimitTimer);
        loginRateLimitTimer = null;
        loginRateLimitUntil = 0;
        if (submitButton && !loginRequestInFlight) {
            submitButton.disabled = false;
            submitButton.classList.remove('btn-loading');
            submitButton.innerText = t('auth.login');
        }
        return;
    }
    if (submitButton) {
        submitButton.disabled = true;
        submitButton.classList.remove('btn-loading');
        submitButton.innerText = t('auth.retryInSeconds').replace('{seconds}', remaining);
    }
    setFormError('loginErrorContainer', t('auth.loginRateLimited').replace('{seconds}', remaining));
}

function startLoginRateLimitCooldown(retryAfterSeconds) {
    const safeSeconds = Math.min(15 * 60, Math.max(1, Number(retryAfterSeconds) || 60));
    loginRateLimitUntil = Math.max(loginRateLimitUntil, Date.now() + (safeSeconds * 1000));
    if (loginRateLimitTimer) clearInterval(loginRateLimitTimer);
    renderLoginRateLimitState();
    loginRateLimitTimer = setInterval(renderLoginRateLimitState, 1000);
}

let userPlan = 'Standard';
let deviceFingerprint = generateDeviceFingerprint();
let subscriptionDaysLeft = 29;
let subscriptionStatus = 'active';
let subscriptionGraceDaysLeft = 0;
let subscriptionExpiresAt = 0;
let subscriptionExpiryHandled = false;
let authExpiryHandled = false;
let showWelcomeGuide = true;
let activeSafeStartStep = 0;

let codeCooldownTimer = null;
let codeCooldownSeconds = 0;
let loginRequestInFlight = false;
let loginRateLimitUntil = 0;
let loginRateLimitTimer = null;
let confirmedRegistrationEmail = sessionStorage.getItem('ax_registration_email') || '';
let passwordResetCooldownTimer = null;
let passwordResetCooldownSeconds = 0;
let currentEditingWallet = null;
let activeOperationWalletId = null;
let activeOperationBalanceData = null;
let activeUniversalBridgeAsset = null;
let universalBridgeTokensByNetwork = {};
let activeUniversalBridgeQuote = null;
let universalBridgeRefreshTimer = null;
let universalBridgeCooldownTimer = null;
const universalBridgeRefreshCooldowns = new Map();
let directTransferWallets = [];
let directTransferBalanceData = null;
let operationsJournalFilter = 'all';
let operationsJournalTypeFilter = 'all';
let operationsJournalWalletFilter = 'all';
let operationsJournalCheckCooldownUntil = 0;
let lastSaveTimestamp = 0; 
let lastRandomizeTimestamp = 0; 
let cachedStatsData = { current_slots: 1, max_slots: 300, is_sold_out: false };

const PLAN_PRICES = { Standard: 29, Pro: 49, Premium: 89 };
const clientSessionId = getOrCreateClientSessionId();
let paymentAccessToken = sessionStorage.getItem('ax_payment_token') || '';
let paymentUnlocked = sessionStorage.getItem('ax_paid_session_id') === clientSessionId && !!paymentAccessToken;
let activeAuthModalType = '';
let paymentInteractionInProgress = false;

if (typeof window.fetch === 'function') {
    const nativeFetch = window.fetch.bind(window);
    window.fetch = (resource, options = {}) => {
        const requestUrl = typeof resource === 'string' ? resource : resource.url;
        const accessToken = sessionStorage.getItem('ax_access_token');
        if (!accessToken || !requestUrl || !requestUrl.startsWith('/api/')) {
            return nativeFetch(resource, options);
        }
        const headers = new Headers(options.headers || {});
        headers.set('Authorization', `Bearer ${accessToken}`);
        return nativeFetch(resource, { ...options, headers }).then((response) => {
            if (response.status === 401 && !requestUrl.startsWith('/api/login')) {
                handleExpiredAuthSession();
            }
            if (
                response.status === 402
                && !requestUrl.startsWith('/api/subscription/')
            ) {
                handleSubscriptionExpired();
            }
            return response;
        });
    };
}

const MASTER_WALLET = "0x5e5316Dea1c44d220d4c60A5fcC2949E5A06Fc66";
const BASE_MAINNET_CHAIN_ID = '0x2105';
const BASE_MAINNET_CONFIG = {
    chainId: BASE_MAINNET_CHAIN_ID,
    chainName: 'Base Mainnet',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: ['https://mainnet.base.org'],
    blockExplorerUrls: ['https://base.blockscout.com'],
};
const UNIVERSAL_BRIDGE_NETWORKS = {
    Ethereum: {
        chainId: '0x1', chainName: 'Ethereum Mainnet',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://ethereum-rpc.publicnode.com'], blockExplorerUrls: ['https://etherscan.io'],
    },
    Base: BASE_MAINNET_CONFIG,
    Arbitrum: {
        chainId: '0xa4b1', chainName: 'Arbitrum One',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://arb1.arbitrum.io/rpc'], blockExplorerUrls: ['https://arbiscan.io'],
    },
    Optimism: {
        chainId: '0xa', chainName: 'OP Mainnet',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://mainnet.optimism.io'], blockExplorerUrls: ['https://optimistic.etherscan.io'],
    },
    Polygon: {
        chainId: '0x89', chainName: 'Polygon PoS',
        nativeCurrency: { name: 'POL', symbol: 'POL', decimals: 18 },
        rpcUrls: ['https://polygon-bor-rpc.publicnode.com'], blockExplorerUrls: ['https://polygonscan.com'],
    },
    Linea: {
        chainId: '0xe708', chainName: 'Linea',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://rpc.linea.build'], blockExplorerUrls: ['https://lineascan.build'],
    },
    'BNB Chain': {
        chainId: '0x38', chainName: 'BNB Smart Chain',
        nativeCurrency: { name: 'BNB', symbol: 'BNB', decimals: 18 },
        rpcUrls: ['https://bsc-rpc.publicnode.com'], blockExplorerUrls: ['https://bscscan.com'],
    },
    Avalanche: {
        chainId: '0xa86a', chainName: 'Avalanche C-Chain',
        nativeCurrency: { name: 'Avalanche', symbol: 'AVAX', decimals: 18 },
        rpcUrls: ['https://api.avax.network/ext/bc/C/rpc'], blockExplorerUrls: ['https://snowtrace.io'],
    },
    'zkSync Era': {
        chainId: '0x144', chainName: 'zkSync Era Mainnet',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://mainnet.era.zksync.io'], blockExplorerUrls: ['https://explorer.zksync.io'],
    },
    Scroll: {
        chainId: '0x82750', chainName: 'Scroll',
        nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
        rpcUrls: ['https://rpc.scroll.io'], blockExplorerUrls: ['https://scrollscan.com'],
    },
    Gnosis: {
        chainId: '0x64', chainName: 'Gnosis Chain',
        nativeCurrency: { name: 'xDAI', symbol: 'xDAI', decimals: 18 },
        rpcUrls: ['https://rpc.gnosischain.com'], blockExplorerUrls: ['https://gnosisscan.io'],
    },
    Mantle: {
        chainId: '0x1388', chainName: 'Mantle',
        nativeCurrency: { name: 'Mantle', symbol: 'MNT', decimals: 18 },
        rpcUrls: ['https://rpc.mantle.xyz'], blockExplorerUrls: ['https://mantlescan.xyz'],
    },
};
const UNIVERSAL_BRIDGE_NATIVE_TOKEN = '0x0000000000000000000000000000000000000000';
const BASE_SEPOLIA_CHAIN_ID = '0x14a34';
const BASE_SEPOLIA_CONFIG = {
    chainId: BASE_SEPOLIA_CHAIN_ID,
    chainName: 'Base Sepolia',
    nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 },
    rpcUrls: ['https://sepolia.base.org'],
    blockExplorerUrls: ['https://sepolia-explorer.base.org'],
};
const WALLETCONNECT_PROVIDER_MODULE_URL = 'https://esm.sh/@walletconnect/ethereum-provider@2.23.10?bundle&target=es2022';
let walletConnectProvider = null;
let walletConnectModulePromise = null;
let walletConnectListenersProvider = null;
let injectedWalletListenersProvider = null;
let walletConnectionFlowInProgress = false;
let savedWalletAddressesCache = new Set();
let savedWalletAddressesCacheOwner = '';
let savedWalletAddressesCacheUpdatedAt = 0;
const walletSessionStateApi = window.AxWalletSessionState;

const NETWORKS_CONFIG = [
    { name: "Ethereum", symbol: "ETH", key: "Ethereum", icon: '<img src="https://cryptologos.cc/logos/ethereum-eth-logo.svg?v=032" style="width:32px; height:32px;">', explorer: "https://etherscan.io" },
    { name: "Base", symbol: "ETH", key: "Base", icon: '<img src="https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/base/info/logo.png" style="width:32px; height:32px; border-radius:50%;">', explorer: "https://basescan.org" },
    { name: "Arbitrum", symbol: "ETH", key: "Arbitrum", icon: '<img src="https://cryptologos.cc/logos/arbitrum-arb-logo.svg?v=032" style="width:32px; height:32px;">', explorer: "https://arbiscan.io" },
    { name: "Optimism", symbol: "ETH", key: "Optimism", icon: '<img src="https://cryptologos.cc/logos/optimism-ethereum-op-logo.svg?v=032" style="width:32px; height:32px;">', explorer: "https://optimistic.etherscan.io" },
    { name: "Polygon", symbol: "POL", key: "Polygon", icon: '<img src="https://cryptologos.cc/logos/polygon-matic-logo.svg?v=032" style="width:32px; height:32px;">', explorer: "https://polygonscan.com" },
    { name: "Linea", symbol: "ETH", key: "Linea", icon: '<img src="https://raw.githubusercontent.com/trustwallet/assets/master/blockchains/linea/info/logo.png" style="width:32px; height:32px; border-radius:50%;">', explorer: "https://lineascan.build" },
    { name: "BNB Chain", symbol: "BNB", key: "BNB Chain", icon: '<img src="https://cryptologos.cc/logos/bnb-bnb-logo.svg?v=032" style="width:32px; height:32px;">', explorer: "https://bscscan.com" },
    { name: "Avalanche", symbol: "AVAX", key: "Avalanche", icon: '<span class="network-monogram">AV</span>', explorer: "https://snowtrace.io" },
    { name: "zkSync Era", symbol: "ETH", key: "zkSync Era", icon: '<span class="network-monogram">ZK</span>', explorer: "https://explorer.zksync.io" },
    { name: "Scroll", symbol: "ETH", key: "Scroll", icon: '<span class="network-monogram">SC</span>', explorer: "https://scrollscan.com" },
    { name: "Gnosis", symbol: "xDAI", key: "Gnosis", icon: '<span class="network-monogram">GN</span>', explorer: "https://gnosisscan.io" },
    { name: "Mantle", symbol: "MNT", key: "Mantle", icon: '<span class="network-monogram">MN</span>', explorer: "https://mantlescan.xyz" }
];
let networksOverviewWallets = [];

// --- Инициализация при загрузке ---
document.getElementById('main-logo-btn').addEventListener('click', function(e) {
    e.preventDefault();
    logoutUser();
});

window.addEventListener('DOMContentLoaded', () => {
    initializeInterfaceHintsPreference();
    updateStaticText(currentLang);
    initializeCookieConsent();
    loadPlatformStats();
    const line = document.getElementById('preloader-line');
    if(line) {
        setTimeout(() => { 
            line.style.opacity = '0'; 
        }, 800);
    }

    const savedUsername = localStorage.getItem('airdrop_username');
    const savedAccessToken = sessionStorage.getItem('ax_access_token');
    if (savedUsername && savedAccessToken) {
        isLoggedIn = true;
        document.documentElement.classList.add('ax-dashboard-active');
        userPlan = localStorage.getItem('selected_plan') || 'Standard';
        
        const loginBtn = document.getElementById('login-btn');
        if (loginBtn) loginBtn.style.display = 'none';

        document.getElementById('main-content').style.display = 'none';
        document.getElementById('dashboard-content').style.display = 'flex';
        const mobileNav = document.getElementById('mobileNavBar');
        if(mobileNav) mobileNav.style.display = ''; 
        
        currentSection = localStorage.getItem('airdrop_current_section') || 'Account';
        renderDashboardContent(currentSection);
        void initializeWalletSessionLifecycle();
    }
    syncEmailCodeCooldown();
    updateRegistrationContinueAction();
    if (!isLoggedIn && !paymentUnlocked && !isPendingRegistrationDismissed()) void restorePaidRegistrationAccess();
    
    // --- Инициализация продвинутых интерактивных анимаций ---
    initButtonGlowEffect();
    initFeatureCardsInteraction();
    initRouteLab();
    initSafeStart();
    initAirdropXVisualSystem();
});

// --- Вспомогательные функции ---
function getCurrentUsername() {
    return String(localStorage.getItem('airdrop_username') || '').trim();
}

function getOrCreateClientSessionId() {
    let existing = sessionStorage.getItem('ax_client_session_id') || localStorage.getItem('ax_client_session_id');
    if (existing) {
        sessionStorage.setItem('ax_client_session_id', existing);
        localStorage.setItem('ax_client_session_id', existing);
        return existing;
    }
    if (window.crypto?.randomUUID) {
        existing = `sess_${window.crypto.randomUUID()}`;
    } else {
        const bytes = new Uint8Array(16);
        window.crypto.getRandomValues(bytes);
        existing = `sess_${Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('')}`;
    }
    sessionStorage.setItem('ax_client_session_id', existing);
    localStorage.setItem('ax_client_session_id', existing);
    return existing;
}

function clearPaymentAccess() {
    paymentUnlocked = false;
    paymentAccessToken = '';
    sessionStorage.removeItem('ax_payment_token');
    sessionStorage.removeItem('ax_paid_session_id');
    sessionStorage.removeItem('ax_paid_plan');
    sessionStorage.removeItem('ax_subscription_payment_pending');
    updateRegistrationContinueAction();
}

function getPendingRegistrationDismissKey() {
    return `ax_registration_dismissed_${clientSessionId}`;
}

function isPendingRegistrationDismissed() {
    return localStorage.getItem(getPendingRegistrationDismissKey()) === '1';
}

function dismissPendingRegistration() {
    localStorage.setItem(getPendingRegistrationDismissKey(), '1');
    clearPaymentAccess();
    closeAuthModal();
    showNotification(t('auth.registrationDismissed'));
}

function updateRegistrationContinueAction() {
    const loginBtn = document.getElementById('login-btn');
    if (!loginBtn || isLoggedIn) return;
    const canContinue = paymentUnlocked && !!paymentAccessToken;
    loginBtn.textContent = canContinue ? t('resumeRegistration') : t('login');
    loginBtn.onclick = () => openModal(canContinue ? 'register' : 'login');
    loginBtn.classList.toggle('pending-registration-button', canContinue);
    loginBtn.title = canContinue ? t('resumeRegistrationHint') : '';
}

function generateDeviceFingerprint() {
    try {
        const stored = localStorage.getItem('ax_device_id');
        if (stored && /^device_[a-zA-Z0-9_-]{20,}$/.test(stored)) return stored;
        const value = window.crypto?.randomUUID
            ? `device_${window.crypto.randomUUID()}`
            : `device_${Array.from(window.crypto.getRandomValues(new Uint8Array(24)), byte => byte.toString(16).padStart(2, '0')).join('')}`;
        localStorage.setItem('ax_device_id', value);
        return value;
    } catch (e) {
        return `device_fallback_${navigator.userAgent.length}_${Date.now().toString(36)}`;
    }
}

function showNotification(text, type = 'success') {
    let container = document.getElementById('toastNotificationContainer');
    if (!container) {
        container = document.createElement('div');
        container.id = 'toastNotificationContainer';
        container.style.cssText = 'position: fixed; bottom: 20px; right: 20px; z-index: 99999; display: flex; flex-direction: column; gap: 8px;';
        document.body.appendChild(container);
    }

    while (container.children.length >= 3) {
        container.firstChild.remove();
    }

    const toast = document.createElement('div');
    const borderColor = type === 'success' ? '#22c55e' : '#ef4444';
    const icon = type === 'success' ? '✅' : '⚠️';
    toast.style.cssText = `background: #121212; border: 1px solid ${borderColor}; color: #fff; padding: 12px 16px; border-radius: 12px; font-size: 13px; box-shadow: 0 10px 25px rgba(0,0,0,0.5); display: flex; align-items: center; gap: 10px; animation: fadeIn 0.3s ease;`;
    const iconEl = document.createElement('span');
    iconEl.textContent = icon;
    const textEl = document.createElement('span');
    textEl.innerHTML = String(text || '');
    toast.replaceChildren(iconEl, textEl);
    container.appendChild(toast);

    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transition = 'opacity 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

function openAntiSybilModal() {
    const modal = document.getElementById('antiSybilModal');
    if (!modal) return;
    showAppModal('antiSybilModal');
}

function closeAntiSybilModal() {
    const modal = document.getElementById('antiSybilModal');
    if (!modal) return;
    hideAppModal('antiSybilModal');
}

function injectWalletSecurityBanner() {
    const existingBanner = document.getElementById('walletSecurityBanner');
    if (existingBanner) existingBanner.remove();

    if (!isInterfaceHintVisible('wallet-security')) return;

    const container = document.getElementById('walletsListContainer');
    if (!container || !container.parentElement) return;

    const banner = document.createElement('div');
    banner.id = 'walletSecurityBanner';
    banner.className = 'security-banner';
    banner.dataset.interfaceHint = 'wallet-security';
    banner.innerHTML = `
        <div class="security-banner__content">
            <div class="security-banner__icon">🛡️</div>
            <div class="security-banner__body">
                <div class="security-banner__title">Anti-Sybil защита активна</div>
                <div class="security-banner__text">Проверяем схемы активности и связанные адреса</div>
            </div>
        </div>
        <div class="security-banner__actions">
            <button type="button" class="security-banner__link" onclick="openAntiSybilModal();">Подробнее</button>
            <button type="button" class="security-banner__close" aria-label="${escapeHtml(t('interfaceHintClose'))}" onclick="dismissInterfaceHint('wallet-security');">✕</button>
        </div>
    `;

    container.parentElement.insertBefore(banner, container);
}

function getRandomDelay(min, max) {
    const skew = Math.random();
    const range = max - min;
    const delay = min + (skew * skew * range);
    return Math.floor(delay);
}

function getAntiSybilJitter(baseValue, jitterPercent = 15) {
    const jitter = baseValue * (jitterPercent / 100);
    return baseValue + (Math.random() * jitter * 2 - jitter);
}

function rotateProxyIndex() {
    const currentIndex = parseInt(sessionStorage.getItem('ax_proxy_rotation_index') || '0', 10);
    const nextIndex = (currentIndex + 1) % 100;
    sessionStorage.setItem('ax_proxy_rotation_index', String(nextIndex));
    sessionStorage.setItem('ax_last_proxy_rotation', String(Date.now()));
    return nextIndex;
}

function shouldRotateProxy() {
    const lastRotation = parseInt(sessionStorage.getItem('ax_last_proxy_rotation') || '0', 10);
    const minInterval = 300000 + Math.random() * 300000;
    return (Date.now() - lastRotation) > minInterval;
}

function renderLanguageAwareText() {
    const lang = setLanguage(currentLang);
    updateRegistrationContinueAction();

    const badge = document.getElementById('current-lang-badge');
    const text = document.getElementById('current-lang-text');
    if (badge) badge.innerText = translations[lang].langCode || lang.toUpperCase();
    if (text) text.innerText = translations[lang].langCode || lang.toUpperCase();

    const counterEl = document.getElementById('slots-counter-text');
    if (counterEl && window.cachedStatsData) {
        counterEl.innerHTML = `${t('privateSoftware')}. <b style="color:#fff; margin-left:8px;">${window.cachedStatsData.current_slots} / ${window.cachedStatsData.max_slots} ${t('slotsShort')}</b>`;
    }
}

function checkInputLimit(input, maxLimit) {
    const val = parseFloat(input.value);
    if (val > maxLimit) {
        input.value = String(maxLimit);
    }
    input.style.color = '#fff';
    input.style.borderColor = 'var(--border-color)';
    input.style.boxShadow = 'none';
    return input.value;
}

// 🌍 Обновление всего статического текста
const STATIC_TEXT_BINDINGS = [
    ['login-btn', 'login'], ['hero-title', 'heroTitle', true], ['hero-desc', 'heroDesc'], ['farm-btn', 'farmBtn'], ['settings-btn', 'settingsBtn'],
    ['nav-features', 'navFeatures'], ['nav-safe-start', 'navSafeStart'], ['nav-how', 'navHow'], ['nav-pricing', 'navPricing'], ['hero-signing', 'heroSigning'],
    ['core-status-label', 'coreStatusLabel'], ['core-status-val', 'coreStatus'], ['features-heading', 'featuresHeading', true], ['features-desc', 'featuresDesc'], ['instr-title', 'instructionHeading'], ['faq-heading', 'faqHeading'],
    ['c1-t', 'c1t'], ['c1-d', 'c1d'], ['c2-t', 'c2t'], ['c2-d', 'c2d'], ['c3-t', 'c3t'], ['c3-d', 'c3d'],
    ['c4-t', 'c4t'], ['c4-d', 'c4d'], ['c6-t', 'c6t'], ['c6-d', 'c6d'], ['c7-tg-t', 'c7tgT'], ['c7-tg-d', 'c7tgD'], ['telegram-preview-title', 'telegramPreviewTitle'], ['telegram-preview-meta', 'telegramPreviewMeta'],
    ['c8-t', 'routeLabTitle'], ['c8-d', 'routeLabDesc'], ['route-tab-swap', 'routeLabSwap'], ['route-tab-bridge', 'routeLabBridge'], ['route-tab-defi', 'routeLabDefi'],
    ['c7-t', 'environmentCardTitle'], ['c7-d', 'environmentCardDesc'],
    ['preview-title', 'previewTitle', true], ['preview-desc', 'previewDesc'], ['preview-networks', 'previewNetworks'], ['preview-statuses', 'previewStatuses'], ['preview-no-keys', 'previewNoKeys'], ['preview-private-keys', 'previewPrivateKeys'],
    ['safe-start-eyebrow', 'safeStartEyebrow'], ['safe-start-title', 'safeStartTitle'], ['safe-start-desc', 'safeStartDesc'],
    ['safe-step-label-1', 'safeStartLabels.account'], ['safe-step-label-2', 'safeStartLabels.wallet'], ['safe-step-label-3', 'safeStartLabels.review'], ['safe-step-label-4', 'safeStartLabels.alerts'],
    ['summary-card-1-title', 'safeStartSummary.connectTitle'], ['summary-card-1-desc', 'safeStartSummary.connectDesc'], ['summary-card-2-title', 'safeStartSummary.reviewTitle'], ['summary-card-2-desc', 'safeStartSummary.reviewDesc'], ['summary-card-3-title', 'safeStartSummary.signTitle'], ['summary-card-3-desc', 'safeStartSummary.signDesc'],
    ['sc1-t', 'sc1t'], ['sc1-b1', 'sc1b1'], ['sc1-d1', 'sc1d1'], ['sc1-d2', 'sc1d2'], ['sc1-l1', 'sc1l1'], ['sc1-l2', 'sc1l2'], ['sc1-l3', 'sc1l3'],
    ['sc2-t', 'sc2t'], ['sc2-b1', 'sc2b1'], ['sc2-d1', 'sc2d1'], ['sc2-d2', 'sc2d2'], ['sc2-l1', 'sc2l1'], ['sc2-l2', 'sc2l2'], ['sc2-l3', 'sc2l3'],
    ['sc3-t', 'sc3t'], ['sc3-b1', 'sc3b1'], ['sc3-d1', 'sc3d1'], ['sc3-d2', 'sc3d2'], ['sc3-l1', 'sc3l1'], ['sc3-l2', 'sc3l2'], ['sc3-l3', 'sc3l3'],
    ['sc4-t', 'sc4t'], ['sc4-b1', 'sc4b1'], ['sc4-d1', 'sc4d1'], ['sc4-l1', 'sc4l1'], ['sc4-l2', 'sc4l2'], ['sc4-l3', 'sc4l3'],
    ['q1', 'q1'], ['a1', 'a1'], ['q2', 'q2'], ['a2', 'a2'], ['q3', 'q3'], ['a3', 'a3'], ['q4', 'q4'], ['a4', 'a4'],
    ['mn-looter', 'mnLooter'], ['mn-farm', 'mnFarm'], ['mn-proxy', 'mnProxy'], ['mn-stats', 'mnStats'], ['mn-more', 'mnMore'],
    ['p-title-modal', 'pTitleModal'], ['p-desc-modal', 'pDescModal'], ['p-std-top', 'subTop'], ['p-std-name', 'stdName'], ['p-std-per', 'stdPer'], ['p-std-f1', 'stdF1'], ['p-std-f2', 'stdF2'], ['p-std-f3', 'stdF3'], ['p-std-btn', 'stdBtn'],
    ['p-pro-badge', 'proBadge'], ['p-pro-top', 'subTop'], ['p-pro-name', 'proName'], ['p-pro-per', 'proPer'], ['p-pro-f1', 'proF1'], ['p-pro-f2', 'proF2'], ['p-pro-f3', 'proF3'], ['p-pro-f4', 'proF4'], ['p-pro-btn', 'proBtn'],
    ['p-prem-top', 'subTop'], ['p-prem-name', 'premName'], ['p-prem-per', 'premPer'], ['p-prem-f1', 'premF1'], ['p-prem-f2', 'premF2'], ['p-prem-f3', 'premF3'], ['p-prem-f4', 'premF4'], ['p-prem-btn', 'premBtn'],
    ['footer-rights', 'footerRights'], ['footer-privacy', 'footerPrivacy'], ['footer-terms', 'footerTerms'], ['footer-cookies', 'footerCookies'], ['footer-support', 'footerSupport'], ['footer-support-hours', 'footerSupportHours'], ['page-title', 'pageTitle'],
    ['cookie-consent-eyebrow', 'cookieConsentEyebrow'], ['cookie-consent-title', 'cookieConsentTitle'], ['cookie-consent-desc', 'cookieConsentDesc'], ['cookie-consent-essential', 'cookieConsentEssential'], ['cookie-consent-policy', 'cookieConsentPolicy'], ['cookie-consent-accept', 'cookieConsentAccept']
];

function updateStaticText(lang) {
    setLanguage(lang);
    STATIC_TEXT_BINDINGS.forEach(([id, key, useHtml]) => {
        const element = document.getElementById(id);
        if (element) element[useHtml ? 'innerHTML' : 'innerText'] = t(key);
    });
    ['current-lang-badge', 'current-lang-text'].forEach(id => {
        const element = document.getElementById(id);
        if (element) element.innerText = t('langCode');
    });
    const counterEl = document.getElementById('slots-counter-text');
    if (counterEl && window.cachedStatsData) {
        counterEl.innerHTML = `${t('privateSoftware')}. <b style="color:#fff; margin-left:8px;">${window.cachedStatsData.current_slots} / ${window.cachedStatsData.max_slots} ${t('slotsShort')}</b>`;
    }
    updateLocalizedDemoMedia();
    updateRouteLab();
    renderSafeStart(activeSafeStartStep);
    updateRegistrationContinueAction();
    syncEmailCodeCooldown();
}

const LOCALIZED_DEMO_MEDIA = [
    { id: 'demo-gas-media', name: 'gas', altKey: 'demoGasAlt' },
    { id: 'demo-wallets-media', name: 'wallets', altKey: 'demoWalletsAlt' },
    { id: 'demo-checks-media', name: 'checks', altKey: 'demoChecksAlt' },
    { id: 'demo-telegram-media', name: 'telegram', altKey: 'demoTelegramAlt' },
];

function updateLocalizedDemoMedia() {
    const language = getActiveLang();
    LOCALIZED_DEMO_MEDIA.forEach(({ id, name, altKey }) => {
        const image = document.getElementById(id);
        if (!image) return;
        const nextSource = `demo-${name}-${language}.gif?v=20260820`;
        if (image.getAttribute('src') !== nextSource) image.setAttribute('src', nextSource);
        image.setAttribute('alt', t(altKey));
    });
    const mainNav = document.getElementById('header-nav');
    if (mainNav) mainNav.setAttribute('aria-label', t('mainNavAria'));
    const heroProof = document.getElementById('hero-proof');
    if (heroProof) heroProof.setAttribute('aria-label', t('heroProofAria'));
    const routeLab = document.getElementById('route-lab');
    if (routeLab) routeLab.setAttribute('aria-label', t('routeLabAria'));
    const interfacePreview = document.getElementById('interface-preview');
    if (interfacePreview) interfacePreview.setAttribute('aria-label', t('previewAria'));
}

window.translateBackendMessage = function(msg) {
    if (!msg) return "";

    const activeLang = getActiveLang();
    const locale = translations[activeLang] || {};
    const exactMessages = locale.backend || {};
    if (exactMessages[msg]) return exactMessages[msg];
    if (msg === 'Subscription payments are temporarily unavailable while exact USDC settlement is configured.') {
        return locale.errors?.subscriptionPaymentsUnavailable || locale.errors?.paymentFailed || msg;
    }

    const dynamicPatterns = [
        ['invalidCodeAttempts', /^Invalid code! Attempts left:\s*(.*)$/],
        ['planLimitReached', /^Plan limit reached:\s*(.*)$/],
        ['slotPurchased', /^Slot purchased! Total slots:\s*(.*)$/],
        ['proxyWorking', /^Proxy is working! Ping:\s*(.*)$/],
        ['connectionError', /^Connection error:\s*(.*)$/],
        ['delayLimitExceeded', /^Delay limit exceeded for day\s*(.*)$/],
        ['deviceChangeLimit', /^Device change limit reached\. Try again in\s*(.*)$/]
    ];

    for (const [key, pattern] of dynamicPatterns) {
        const match = msg.match(pattern);
        const template = locale.backendDynamic?.[key];
        if (match && template) return template.replace('{details}', match[1].trim());
    }

    return msg;
};

function escapeHtml(value) {
    return String(value).replace(/[&<>'"]/g, character => ({
        '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;'
    })[character]);
}

function translateBackendDetail(detail, fallbackKey = 'errors.genericRequestFailed') {
    let translated;
    if (Array.isArray(detail)) {
        translated = detail.map(item => {
            const message = item?.msg || '';
            return message === 'Field required' ? t('errors.fillAllFields') : window.translateBackendMessage(message);
        }).filter(Boolean).join(', ') || t(fallbackKey);
    } else {
        translated = typeof detail === 'string' && detail ? window.translateBackendMessage(detail) : t(fallbackKey);
    }
    return escapeHtml(translated);
}

function renderAppEmptyState(title, message, actionLabel = '', action = '') {
    const actionHtml = actionLabel && action
        ? `<button type="button" class="app-empty-state__action" onclick="${action}">${escapeHtml(actionLabel)}</button>`
        : '';
    return `<section class="app-empty-state" aria-live="polite">
        <strong>${escapeHtml(title)}</strong>
        <span>${escapeHtml(message)}</span>
        ${actionHtml}
    </section>`;
}

function operationErrorMessage(error, locale, fallbackMessage = '') {
    const raw = String(error?.message || error || '').trim();
    const normalized = raw.toLowerCase();
    const code = error?.code;
    if (code === 4001 || code === 'ACTION_REJECTED' || /rejected|cancelled|denied/.test(normalized)) return locale.operationErrorRejected;
    if (/quote[\s_-]*expired|quote_expired|expired quote/.test(normalized)) return locale.operationErrorQuoteExpired;
    if (/wallet[\s_-]*(mismatch|required)|wrong[\s_-]*account|no[\s_-]*accounts|save this wallet|active wallet/.test(normalized)) return locale.operationErrorWallet;
    if (/base_mainnet_not_selected|universal_bridge_network_not_selected|wrong network|chain.?id|switch network|network.*selected/.test(normalized)) return locale.operationErrorNetwork;
    if (/insufficient|gas reserve|insufficient funds|not enough.*gas/.test(normalized)) return locale.operationErrorGas;
    if (/invalid.*amount|amount.*invalid|amount.*positive/.test(normalized)) return locale.operationErrorAmount;
    if (/failed to fetch|network error|connection|timeout|temporarily unavailable|provider unavailable/.test(normalized)) return locale.operationErrorConnection;
    const translated = raw ? window.translateBackendMessage(raw) : '';
    return translated && translated !== raw ? translated : (fallbackMessage || locale.operationErrorTryAgain);
}

function returnToMainSite() {
    closeBottomSheetMenu();
    isLoggedIn = false;
    authExpiryHandled = false;
    subscriptionExpiryHandled = false;
    document.documentElement.classList.remove('ax-dashboard-active');
    clearConnectedWalletState();
    localStorage.removeItem('airdrop_username');
    localStorage.removeItem('airdrop_current_section');
    sessionStorage.removeItem('ax_access_token');
    sessionStorage.removeItem('ax_base_wallet_address');
    sessionStorage.removeItem('ax_active_wallet_address');
    
    const loginBtn = document.getElementById('login-btn');
    if (loginBtn) loginBtn.style.display = '';
    updateRegistrationContinueAction();

    document.getElementById('dashboard-content').style.display = 'none';
    const mobileNav = document.getElementById('mobileNavBar');
    if(mobileNav) mobileNav.style.display = 'none'; 
    document.getElementById('main-content').style.display = 'block';
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function logoutUser() {
    const accessToken = sessionStorage.getItem('ax_access_token');
    if (accessToken) {
        try {
            await fetch('/api/logout', { method: 'POST' });
        } catch (_) {
            // Local cleanup still protects the current browser if the server is offline.
        }
    }
    returnToMainSite();
}

function toggleLangMenu(event) {
    if (event) event.stopPropagation();
    document.getElementById('langMenu').classList.toggle('show');
}

window.addEventListener('click', function(event) {
    if (!event.target.closest('.lang-dropdown-wrapper')) {
        const menu = document.getElementById('langMenu');
        if (menu) menu.classList.remove('show');
    }
});

function changeLanguage(lang) {
    const normalizedLang = setLanguage(lang);
    document.getElementById('langMenu').classList.remove('show');
    updateStaticText(normalizedLang);
    if (isLoggedIn) {
        renderDashboardContent(currentSection);
    }
}

// --- Модальные окна и авторизация ---
const APP_MODAL_IDS = [
    'pricingModal', 'authModal', 'antiSybilModal', 'walletConfigModal',
    'walletConnectModal', 'baseSwapConfirmModal', 'appConfirmModal', 'walletScheduleModal', 'legalModal'
];

function syncModalScrollLock() {
    const isAnyModalOpen = APP_MODAL_IDS.some(id => document.getElementById(id)?.classList.contains('show'));
    document.body.classList.toggle('modal-open', isAnyModalOpen);
}

function showAppModal(modalId) {
    APP_MODAL_IDS.forEach(id => {
        if (id !== modalId) document.getElementById(id)?.classList.remove('show');
    });
    const modal = document.getElementById(modalId);
    if (!modal) return null;
    modal.classList.add('show');
    syncModalScrollLock();
    return modal;
}

function hideAppModal(modalId) {
    document.getElementById(modalId)?.classList.remove('show');
    syncModalScrollLock();
}

function hideAllAppModals() {
    APP_MODAL_IDS.forEach(id => document.getElementById(id)?.classList.remove('show'));
    syncModalScrollLock();
}

function openPricingModal() {
    syncPricingModalForAccount();
    showAppModal('pricingModal');
}

function syncPricingModalForAccount() {
    const locale = translations[getActiveLang()];
    const ranks = { Standard: 1, Pro: 2, Premium: 3 };
    const planNames = { Standard: locale.stdName, Pro: locale.proName, Premium: locale.premName };
    const status = document.getElementById('pricingAccountStatus');
    const closeButton = document.getElementById('pricingModalClose');
    if (closeButton) closeButton.setAttribute('aria-label', locale.modalCloseLabel);
    const buttons = [
        ['Standard', document.getElementById('p-std-btn'), locale.stdBtn],
        ['Pro', document.getElementById('p-pro-btn'), locale.proBtn],
        ['Premium', document.getElementById('p-prem-btn'), locale.premBtn],
    ];
    buttons.forEach(([, button, defaultLabel]) => {
        if (!button) return;
        button.disabled = false;
        button.style.opacity = '';
        button.style.cursor = '';
        button.textContent = defaultLabel;
    });
    if (status) {
        status.hidden = !isLoggedIn;
        status.className = 'pricing-account-status';
        status.textContent = '';
    }
    if (!isLoggedIn) return;

    if (status) {
        status.classList.add(`pricing-account-status--${subscriptionStatus}`);
        if (subscriptionStatus === 'grace') {
            status.textContent = locale.subscriptionPricingGrace
                .replace('{plan}', planNames[userPlan] || userPlan)
                .replace('{days}', String(subscriptionGraceDaysLeft));
        } else if (subscriptionStatus === 'expired') {
            status.textContent = locale.subscriptionPricingExpired;
        } else {
            status.textContent = locale.subscriptionPricingActive
                .replace('{plan}', planNames[userPlan] || userPlan);
        }
    }

    const canChooseAnyPlan = subscriptionStatus !== 'active';
    buttons.forEach(([plan, button, defaultLabel]) => {
        if (!button) return;
        const isCurrent = plan === userPlan;
        const isDowngrade = ranks[plan] < ranks[userPlan];
        const disabled = !canChooseAnyPlan && (isCurrent || isDowngrade);
        button.disabled = disabled;
        button.style.opacity = disabled ? '.55' : '';
        button.style.cursor = disabled ? 'not-allowed' : '';
        if (isCurrent && !canChooseAnyPlan) button.textContent = locale.subscriptionCurrentPlan;
        if (isDowngrade && !canChooseAnyPlan) button.textContent = locale.subscriptionDowngradeBlocked;
        if (!canChooseAnyPlan && !isCurrent && !isDowngrade) {
            button.textContent = locale.subscriptionUpgradePlan
                .replace('{plan}', planNames[plan] || plan)
                .replace('{price}', String(PLAN_PRICES[plan]));
        }
        if (canChooseAnyPlan) {
            button.textContent = locale.subscriptionRestorePlan
                .replace('{plan}', planNames[plan] || plan)
                .replace('{price}', String(PLAN_PRICES[plan]));
        }
    });
}

function closePricingModal() {
    hideAppModal('pricingModal');
}

function toggleFaq(item) {
    if (!item) return;
    const willOpen = !item.classList.contains('active');
    item.classList.toggle('active', willOpen);
    const trigger = item.querySelector('.faq-question');
    const icon = item.querySelector('.faq-toggle');
    if (trigger) trigger.setAttribute('aria-expanded', String(willOpen));
    if (icon) icon.textContent = willOpen ? '−' : '+';
}

let mousedownOverlayTarget = null;
window.addEventListener('mousedown', (e) => { mousedownOverlayTarget = e.target; });

function handleOverlayClick(event) { if (event.target.id === 'authModal' && mousedownOverlayTarget?.id === 'authModal') void requestCloseAuthModal(); }
function handlePricingOverlayClick(event) { if (event.target.id === 'pricingModal' && mousedownOverlayTarget?.id === 'pricingModal') closePricingModal(); }

window.addEventListener('keydown', (event) => {
    if (event.key !== 'Escape' || event.defaultPrevented) return;
    if (document.getElementById('appConfirmModal')?.classList.contains('show')) {
        event.preventDefault();
        finishAppConfirm(false);
        return;
    }
    if (document.getElementById('authModal')?.classList.contains('show')) {
        event.preventDefault();
        void requestCloseAuthModal();
        return;
    }
    if (document.getElementById('pricingModal')?.classList.contains('show')) {
        event.preventDefault();
        closePricingModal();
    }
});

function selectPlanAndRegister(planName, price) {
    closePricingModal();
    if (isLoggedIn) {
        const rank = { Standard: 1, Pro: 2, Premium: 3 };
        if (subscriptionStatus === 'active' && rank[planName] <= rank[userPlan]) {
            showNotification(translations[getActiveLang()].subscriptionDowngradeBlocked, 'warning');
            return;
        }
        localStorage.setItem('selected_plan', planName);
        localStorage.setItem('selected_price', String(price));
        clearPendingSubscriptionPayment();
        openModal('payment');
        return;
    }
    userPlan = planName;
    localStorage.setItem('selected_plan', planName);
    localStorage.setItem('selected_price', String(price));
    localStorage.removeItem('selected_onboarding');
    clearPaymentAccess();
    openModal('payment');
}

function closeAuthModal() {
    activeAuthModalType = '';
    hideAppModal('authModal');
}

async function requestCloseAuthModal() {
    if (activeAuthModalType !== 'payment') {
        closeAuthModal();
        return;
    }
    const locale = translations[getActiveLang()] || translations.ru;
    const pendingPayment = getPendingSubscriptionPayment();
    if (paymentInteractionInProgress) {
        showNotification(pendingPayment ? locale.payVerificationInProgress : locale.payCancelInWalletFirst, 'warning');
        return;
    }
    if (!pendingPayment) {
        closeAuthModal();
        return;
    }
    const shouldClose = await openAppConfirm({
        title: locale.payClosePendingTitle,
        message: locale.payClosePendingMessage,
        confirmText: locale.payClosePendingAction,
    });
    if (shouldClose) closeAuthModal();
    else openModal('payment');
}

let appConfirmResolver = null;

function openAppConfirm({ title, message, confirmText }) {
    const modal = document.getElementById('appConfirmModal');
    if (!modal) return Promise.resolve(false);
    const locale = translations[getActiveLang()] || translations.ru;
    document.getElementById('appConfirmTitle').textContent = title || '';
    document.getElementById('appConfirmMessage').textContent = message || '';
    document.getElementById('appConfirmCancel').textContent = locale.confirmCancel;
    document.getElementById('appConfirmProceed').textContent = confirmText || locale.walletRemoveAction;
    showAppModal('appConfirmModal');
    return new Promise((resolve) => { appConfirmResolver = resolve; });
}

function finishAppConfirm(confirmed) {
    hideAppModal('appConfirmModal');
    const resolve = appConfirmResolver;
    appConfirmResolver = null;
    if (resolve) resolve(Boolean(confirmed));
}

function handleAppConfirmOverlayClick(event) {
    if (event.target.id === 'appConfirmModal' && mousedownOverlayTarget?.id === 'appConfirmModal') {
        finishAppConfirm(false);
    }
}

function passwordVisibilityIcon(isVisible) {
    return isVisible
        ? '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 3l18 18M10.6 10.7a2 2 0 0 0 2.7 2.7M9.9 4.2A10.8 10.8 0 0 1 12 4c5.5 0 9 5 9 8a8.5 8.5 0 0 1-2.1 3.6M6.6 6.6C4.3 8 3 10.2 3 12c0 3 3.5 8 9 8 1.5 0 2.8-.4 4-1"/></svg>'
        : '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 12c0-3 3.5-8 9-8s9 5 9 8-3.5 8-9 8-9-5-9-8Z"/><circle cx="12" cy="12" r="3"/></svg>';
}

function sanitizeDecimalInput(input, maxDecimals = 18) {
    if (!input) return '';
    const raw = String(input.value || '').replace(',', '.');
    const cleaned = raw.replace(/[^0-9.]/g, '');
    const dotIndex = cleaned.indexOf('.');
    const whole = (dotIndex >= 0 ? cleaned.slice(0, dotIndex) : cleaned).slice(0, 30);
    const fraction = dotIndex >= 0
        ? cleaned.slice(dotIndex + 1).replace(/\./g, '').slice(0, Math.max(0, Number(maxDecimals) || 0))
        : '';
    input.value = dotIndex >= 0 && maxDecimals > 0 ? `${whole}.${fraction}` : whole;
    return input.value;
}

function sanitizeIntegerInput(input, maxLength = 12) {
    if (!input) return '';
    input.value = String(input.value || '').replace(/\D/g, '').slice(0, Math.max(1, Number(maxLength) || 12));
    return input.value;
}

function togglePasswordVisibility(fieldId, iconEl) {
    const input = document.getElementById(fieldId);
    if (!input) return;
    const willShow = input.type === 'password';
    input.type = willShow ? 'text' : 'password';
    iconEl.innerHTML = passwordVisibilityIcon(willShow);
    iconEl.setAttribute('aria-pressed', willShow ? 'true' : 'false');
}

function openModal(type) {
    const modal = document.getElementById('authModal');
    const container = document.getElementById('modalContainer');

    if (type === 'register' && (!paymentUnlocked || !paymentAccessToken)) {
        closeAuthModal();
        openPricingModal();
        return;
    }

    activeAuthModalType = type;
    showAppModal('authModal');

    if (type === 'login') {
        container.innerHTML = `
            <form onsubmit="event.preventDefault(); validateLogin();">
                <div class="modal-logo" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
                    <span style="font-weight:bold; font-size:16px;">${t('login')}</span>
                    <button type="button" class="icon-button-plain" onclick="requestCloseAuthModal()" aria-label="${t('modalCloseLabel')}" style="color: #a3a3a3; font-size: 18px;">✕</button>
                </div>
                <div class="input-group" style="margin-bottom:12px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.usernameLabel')}</label>
                    <input type="text" class="auth-input" placeholder="${t('auth.usernamePlaceholder')}" id="loginUsername" oninput="clearFormError('loginErrorContainer', 'loginUsername'); clearFieldValidationState('loginUsername')">
                    <div style="font-size:11px; color:#a3a3a3; margin-top:6px;">${t('auth.loginWithEmail')}</div>
                </div>
                <div class="input-group" style="margin-bottom:16px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.password')}</label>
                    <div class="password-wrapper" style="position:relative;">
                        <input type="password" class="auth-input" placeholder="${t('auth.passwordPlaceholder')}" id="loginPass" style="padding-right: 35px;" oninput="clearFormError('loginErrorContainer', 'loginPass'); clearFieldValidationState('loginPass')">
                        <button type="button" class="password-toggle-icon" onclick="togglePasswordVisibility('loginPass', this)" aria-label="Show or hide password" aria-pressed="false">${passwordVisibilityIcon(false)}</button>
                    </div>
                </div>
                <button type="submit" class="btn-modal-primary" id="loginSubmitBtn" style="width:100%; padding:12px;">${t('login')}</button>
                <button type="button" onclick="openModal('reset')" style="width:100%; margin-top:10px; padding:6px; border:0; background:transparent; color:#c4b5fd; cursor:pointer; font-size:12px;">${t('auth.forgotPassword')}</button>
                <div id="loginErrorContainer" style="margin-top:10px;"></div>
            </form>
        `;
    } else if (type === 'reset') {
        syncPasswordResetCooldown();
        const resetButtonDisabled = passwordResetCooldownSeconds > 0 ? 'disabled' : '';
        const resetButtonText = passwordResetCooldownSeconds > 0
            ? formatCodeCooldownLabel(passwordResetCooldownSeconds)
            : t('auth.sendResetCode');
        container.innerHTML = `
            <form onsubmit="event.preventDefault(); confirmPasswordReset();">
                <div class="modal-logo" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <span style="font-weight:bold; font-size:16px;">${t('auth.resetPassword')}</span>
                    <button type="button" class="icon-button-plain" onclick="requestCloseAuthModal()" aria-label="${t('modalCloseLabel')}" style="color:#a3a3a3; font-size:18px;">✕</button>
                </div>
                <p style="margin:0 0 14px; color:#a3a3a3; font-size:12px; line-height:1.5;">${t('auth.resetInstructions')}</p>
                <div class="input-group" style="margin-bottom:10px;">
                    <label style="font-size:11px; color:#a3a3a3; display:block; margin-bottom:4px;">${t('auth.email')}</label>
                    <input type="email" class="auth-input" placeholder="${t('auth.emailPlaceholder')}" id="resetEmail" oninput="clearFormError('resetErrorContainer', 'resetEmail'); clearFieldValidationState('resetEmail')">
                </div>
                <div class="input-group" style="margin-bottom:10px;">
                    <label style="font-size:11px; color:#a3a3a3; display:block; margin-bottom:4px;">${t('auth.code')}</label>
                    <div style="display:flex; gap:8px;">
                        <input type="text" inputmode="numeric" maxlength="6" class="auth-input" placeholder="${t('auth.codePlaceholder')}" id="resetCode" style="flex:1; margin:0;" oninput="sanitizeIntegerInput(this, 6); clearFormError('resetErrorContainer', 'resetCode'); clearFieldValidationState('resetCode')">
                        <button type="button" id="sendResetCodeBtn" onclick="requestPasswordResetCode()" ${resetButtonDisabled} class="auth-input ${passwordResetCooldownSeconds > 0 ? 'btn-cooldown' : ''}" style="width:auto; background:#1f1f1f; color:#fff; cursor:pointer; font-weight:600;">${resetButtonText}</button>
                    </div>
                </div>
                <div class="input-group" style="margin-bottom:14px;">
                    <label style="font-size:11px; color:#a3a3a3; display:block; margin-bottom:4px;">${t('auth.newPassword')}</label>
                    <div class="password-wrapper" style="position:relative;">
                        <input type="password" class="auth-input" placeholder="${t('auth.passwordPlaceholder')}" id="resetPass" style="padding-right:35px;" oninput="clearFormError('resetErrorContainer', 'resetPass'); clearFieldValidationState('resetPass')">
                        <button type="button" class="password-toggle-icon" onclick="togglePasswordVisibility('resetPass', this)" aria-label="Show or hide password" aria-pressed="false">${passwordVisibilityIcon(false)}</button>
                    </div>
                </div>
                <button type="submit" class="btn-modal-primary" style="width:100%; padding:10px;">${t('auth.resetSubmit')}</button>
                <button type="button" onclick="openModal('login')" style="width:100%; margin-top:8px; padding:5px; border:0; background:transparent; color:#a3a3a3; cursor:pointer; font-size:12px;">${t('auth.backToLogin')}</button>
                <div id="resetErrorContainer" style="margin-top:10px;"></div>
            </form>
        `;
    } else if (type === 'payment') {
        const chosenPlan = localStorage.getItem('selected_plan') || 'Standard';
        const basePrice = Number(localStorage.getItem('selected_price') || PLAN_PRICES[chosenPlan] || PLAN_PRICES.Standard);
        const displayAmount = basePrice.toFixed(2);
        const planDisplayLabel = chosenPlan === 'Standard' ? t('stdName') : chosenPlan === 'Pro' ? t('proName') : t('premName');

        container.innerHTML = `
            <div class="modal-logo" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                <span style="font-weight:bold; font-size:16px;">${t('payTitle')}: ${planDisplayLabel}</span>
                <button type="button" class="icon-button-plain" onclick="requestCloseAuthModal()" aria-label="${t('modalCloseLabel')}" style="color: #a3a3a3; font-size: 18px;">✕</button>
            </div>
            
            <div style="margin-bottom:12px; padding:10px 12px; border:1px solid rgba(96,165,250,.35); background:rgba(30,58,138,.13); border-radius:10px; color:#dbeafe; font-size:12px; line-height:1.5;">
                ${t('payWalletInstruction')}
            </div>

            <div style="background:#0a0a0a; border:1px solid var(--border-color); border-radius:12px; padding:12px; margin-bottom:12px; text-align:center;">
                <div style="font-size:11px; color:#a3a3a3; margin-bottom:2px;">${t('payAmount')}</div>
                <div id="paymentAmountValue" style="font-size:20px; color:#fff; font-weight:700; margin-bottom:8px;">${displayAmount} USDC</div>
                <div id="paymentTestModeNotice" style="display:none; font-size:11px; color:#86efac; margin-bottom:8px;"></div>
                <div style="font-size:11px; color:#a3a3a3;">${t('payAssetNotice')}</div>
            </div>

            <button type="button" id="paymentActionBtn" class="btn-modal-primary" onclick="startPlanPayment()" style="width:100%; padding:10px;">${t('payWithWallet')} · ${displayAmount} USDC</button>
            <div id="paymentStatusContainer"></div>
        `;
        restorePendingSubscriptionPayment();
    } else if (type === 'register') {
        syncEmailCodeCooldown();
        const chosenPlan = localStorage.getItem('selected_plan') || 'Standard';
        const chosenPrice = Number(localStorage.getItem('selected_price') || PLAN_PRICES[chosenPlan] || PLAN_PRICES.Standard);
        const planDisplayLabel = chosenPlan === 'Standard' ? t('stdName') : chosenPlan === 'Pro' ? t('proName') : t('premName');
        const btnText = codeCooldownSeconds > 0 ? formatCodeCooldownLabel(codeCooldownSeconds) : t('auth.sendCode');
        const btnDisabled = codeCooldownSeconds > 0 ? 'disabled' : '';
        const emailState = codeCooldownSeconds > 0 ? `readonly style="opacity: 0.7;" value="${confirmedRegistrationEmail}"` : '';

        container.innerHTML = `
            <form onsubmit="event.preventDefault(); validateRegister();">
                <div class="modal-logo" style="display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;">
                    <span style="font-weight:bold; font-size:16px;">${t('auth.register')}: ${planDisplayLabel} ($${chosenPrice})</span>
                    <button type="button" class="icon-button-plain" onclick="requestCloseAuthModal()" aria-label="${t('modalCloseLabel')}" style="color: #a3a3a3; font-size: 18px;">✕</button>
                </div>
                
                <div class="input-group" style="margin-bottom:10px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.nickname')}</label>
                    <input type="text" class="auth-input" placeholder="${t('auth.usernamePlaceholder')}" id="regUsername" oninput="clearFormError('errorContainer', 'regUsername'); clearFieldValidationState('regUsername')">
                </div>
                
                <div class="input-group" style="margin-bottom:10px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.email')}</label>
                    <input type="email" class="auth-input" placeholder="${t('auth.emailPlaceholder')}" id="regEmail" ${emailState} oninput="clearFormError('errorContainer', 'regEmail'); clearFieldValidationState('regEmail')">
                </div>
                
                <div class="input-group" style="margin-bottom:10px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.password')}</label>
                    <div class="password-wrapper" style="position:relative;">
                        <input type="password" class="auth-input" placeholder="${t('auth.passwordPlaceholder')}" id="regPass" style="padding-right: 35px;" oninput="clearFormError('errorContainer', 'regPass'); clearFieldValidationState('regPass')">
                        <button type="button" class="password-toggle-icon" onclick="togglePasswordVisibility('regPass', this)" aria-label="Show or hide password" aria-pressed="false">${passwordVisibilityIcon(false)}</button>
                    </div>
                </div>
                
                <div class="input-group" style="margin-bottom:14px;">
                    <label style="font-size: 11px; color: #a3a3a3; display: block; margin-bottom: 4px;">${t('auth.code')}</label>
                    <div style="display: flex; gap: 8px;">
                        <input type="text" inputmode="numeric" maxlength="6" class="auth-input" placeholder="${t('auth.codePlaceholder')}" id="regCode" style="flex: 1; margin: 0;" oninput="sanitizeIntegerInput(this, 6); clearFormError('errorContainer', 'regCode'); clearFieldValidationState('regCode')">
                        <button type="button" id="sendCodeBtn" onclick="sendVerificationEmailCode()" ${btnDisabled} class="auth-input ${codeCooldownSeconds > 0 ? 'btn-cooldown' : ''}" style="width: auto; background:#1f1f1f; color:#fff; cursor:pointer; font-weight:600;">${btnText}</button>
                    </div>
                </div>
                
                <button type="submit" class="btn-modal-primary" style="width:100%; padding:10px;">${t('auth.register')}</button>
                <button type="button" onclick="dismissPendingRegistration()" style="width:100%; margin-top:8px; padding:5px; border:0; background:transparent; color:#a3a3a3; cursor:pointer; font-size:12px;">${t('auth.alreadyRegistered')}</button>
                <div id="errorContainer" style="margin-top:10px;"></div>
            </form>
        `;
    }
}

function getEmailCodeCooldownRemaining() {
    const until = Number(sessionStorage.getItem('ax_email_code_cooldown_until') || 0);
    return until > Date.now() ? Math.ceil((until - Date.now()) / 1000) : 0;
}

function formatCodeCooldownLabel(seconds) {
    return t('auth.resendInSeconds').replace('{seconds}', String(Math.max(0, seconds)));
}

function applyEmailCodeCooldownUi() {
    const button = document.getElementById('sendCodeBtn');
    const emailInput = document.getElementById('regEmail');
    if (codeCooldownSeconds <= 0) {
        if (button) {
            button.disabled = false;
            button.classList.remove('btn-loading', 'btn-cooldown');
            button.textContent = t('auth.sendCode');
        }
        if (emailInput) {
            emailInput.readOnly = false;
            emailInput.style.opacity = '1';
        }
        return;
    }
    if (button) {
        button.disabled = true;
        button.classList.remove('btn-loading');
        button.classList.add('btn-cooldown');
        button.textContent = formatCodeCooldownLabel(codeCooldownSeconds);
    }
    if (emailInput) {
        emailInput.readOnly = true;
        emailInput.style.opacity = '0.7';
    }
}

function syncEmailCodeCooldown() {
    codeCooldownSeconds = getEmailCodeCooldownRemaining();
    if (codeCooldownSeconds <= 0) {
        sessionStorage.removeItem('ax_email_code_cooldown_until');
        if (codeCooldownTimer) clearInterval(codeCooldownTimer);
        codeCooldownTimer = null;
        applyEmailCodeCooldownUi();
        return;
    }
    applyEmailCodeCooldownUi();
    if (codeCooldownTimer) return;
    codeCooldownTimer = setInterval(() => {
        codeCooldownSeconds = getEmailCodeCooldownRemaining();
        if (codeCooldownSeconds <= 0) {
            sessionStorage.removeItem('ax_email_code_cooldown_until');
            clearInterval(codeCooldownTimer);
            codeCooldownTimer = null;
        }
        applyEmailCodeCooldownUi();
    }, 1000);
}

function startEmailCodeCooldown(email) {
    confirmedRegistrationEmail = email;
    sessionStorage.setItem('ax_registration_email', email);
    sessionStorage.setItem('ax_email_code_cooldown_until', String(Date.now() + 60_000));
    if (codeCooldownTimer) clearInterval(codeCooldownTimer);
    codeCooldownTimer = null;
    syncEmailCodeCooldown();
}

function getPasswordResetCooldownRemaining() {
    const until = Number(sessionStorage.getItem('ax_password_reset_cooldown_until') || 0);
    return until > Date.now() ? Math.ceil((until - Date.now()) / 1000) : 0;
}

function applyPasswordResetCooldownUi() {
    const button = document.getElementById('sendResetCodeBtn');
    if (!button) return;
    if (passwordResetCooldownSeconds <= 0) {
        button.disabled = false;
        button.classList.remove('btn-loading', 'btn-cooldown');
        button.textContent = t('auth.sendResetCode');
        return;
    }
    button.disabled = true;
    button.classList.remove('btn-loading');
    button.classList.add('btn-cooldown');
    button.textContent = formatCodeCooldownLabel(passwordResetCooldownSeconds);
}

function syncPasswordResetCooldown() {
    passwordResetCooldownSeconds = getPasswordResetCooldownRemaining();
    if (passwordResetCooldownSeconds <= 0) {
        sessionStorage.removeItem('ax_password_reset_cooldown_until');
        if (passwordResetCooldownTimer) clearInterval(passwordResetCooldownTimer);
        passwordResetCooldownTimer = null;
        applyPasswordResetCooldownUi();
        return;
    }
    applyPasswordResetCooldownUi();
    if (passwordResetCooldownTimer) return;
    passwordResetCooldownTimer = setInterval(() => {
        passwordResetCooldownSeconds = getPasswordResetCooldownRemaining();
        if (passwordResetCooldownSeconds <= 0) {
            sessionStorage.removeItem('ax_password_reset_cooldown_until');
            clearInterval(passwordResetCooldownTimer);
            passwordResetCooldownTimer = null;
        }
        applyPasswordResetCooldownUi();
    }, 1000);
}

function startPasswordResetCooldown() {
    sessionStorage.setItem('ax_password_reset_cooldown_until', String(Date.now() + 60_000));
    if (passwordResetCooldownTimer) clearInterval(passwordResetCooldownTimer);
    passwordResetCooldownTimer = null;
    syncPasswordResetCooldown();
}

async function sendVerificationEmailCode() {
    if (getEmailCodeCooldownRemaining() > 0) return;
    const emailInput = document.getElementById('regEmail');
    const email = emailInput.value.trim();
    const btn = document.getElementById('sendCodeBtn');

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!email || !emailRegex.test(email)) {
        setFormError('errorContainer', t('errors.invalidEmail'), 'error', 'regEmail');
        return;
    }

    emailInput.readOnly = true;
    emailInput.style.opacity = '0.7';
    setButtonLoading(btn, true, t('auth.codeSending'));

    try {
        const response = await fetch('/api/send-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        if (!response.ok) {
            throw new Error('request failed');
        }
        setFormError('errorContainer', t('auth.codeSent'), 'success');
        showNotification(t('auth.codeSent'));
        setButtonLoading(btn, false, t('auth.sendCode'));
        startEmailCodeCooldown(email);
    } catch (e) {
        setFormError('errorContainer', t('errors.networkError'));
        showNotification(t('errors.networkError'), 'error');
        setButtonLoading(btn, false, t('auth.sendCode'));
        emailInput.readOnly = false;
        emailInput.style.opacity = '1';
    }
}

async function requestPasswordResetCode() {
    if (getPasswordResetCooldownRemaining() > 0) return;
    const email = document.getElementById('resetEmail')?.value.trim() || '';
    const button = document.getElementById('sendResetCodeBtn');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setFormError('resetErrorContainer', t('errors.invalidEmail'), 'error', 'resetEmail');
        return;
    }
    setButtonLoading(button, true, t('auth.codeSending'));
    try {
        const response = await fetch('/api/password-reset/request', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email }),
        });
        if (!response.ok) throw new Error('reset_code_request_failed');
        setFormError('resetErrorContainer', t('auth.resetCodeSent'), 'success');
        startPasswordResetCooldown();
    } catch (_) {
        setFormError('resetErrorContainer', t('errors.networkError'));
        setButtonLoading(button, false, t('auth.sendResetCode'));
    }
}

async function confirmPasswordReset() {
    const email = document.getElementById('resetEmail')?.value.trim() || '';
    const code = document.getElementById('resetCode')?.value.trim() || '';
    const password = document.getElementById('resetPass')?.value.trim() || '';
    const button = document.querySelector('#modalContainer .btn-modal-primary');
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setFormError('resetErrorContainer', t('errors.invalidEmail'), 'error', 'resetEmail');
        return;
    }
    if (!/^\d{6}$/.test(code)) {
        setFormError('resetErrorContainer', t('auth.invalidResetCode'), 'error', 'resetCode');
        return;
    }
    if (password.length < 12) {
        setFormError('resetErrorContainer', t('errors.registrationPasswordTooShort'), 'error', 'resetPass');
        return;
    }
    setButtonLoading(button, true, t('auth.resetSubmit'));
    try {
        const response = await fetch('/api/password-reset/confirm', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email, code, password }),
        });
        const data = await response.json();
        if (!response.ok) {
            setFormError('resetErrorContainer', translateBackendDetail(data.detail, 'auth.invalidResetCode'));
            return;
        }
        sessionStorage.removeItem('ax_password_reset_cooldown_until');
        setFormError('resetErrorContainer', t('auth.passwordResetSuccess'), 'success');
        showNotification(t('auth.passwordResetSuccess'));
        setTimeout(() => openModal('login'), 1100);
    } catch (_) {
        setFormError('resetErrorContainer', t('errors.networkError'));
    } finally {
        setButtonLoading(button, false, t('auth.resetSubmit'));
    }
}

function scrollToFeatures() {
    const heading = document.getElementById('features-heading');
    if (heading) {
        heading.scrollIntoView({ behavior: 'smooth' });
    }
}

// --- Продвинутые интерактивные анимации в стиле Huly.io ---

/**
 * Инициализация эффекта свечения кнопок за курсором
 * Оптимизированный обработчик без утечек памяти
 */
function initButtonGlowEffect() {
    const glowButtons = document.querySelectorAll('.glow-button-target');
    
    glowButtons.forEach(button => {
        const handleMouseMove = (e) => {
            const rect = button.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / rect.width) * 100;
            const y = ((e.clientY - rect.top) / rect.height) * 100;
            
            button.style.setProperty('--mouse-x', `${x}%`);
            button.style.setProperty('--mouse-y', `${y}%`);
        };
        
        const handleMouseLeave = () => {
            button.style.removeProperty('--mouse-x');
            button.style.removeProperty('--mouse-y');
        };
        
        // Используем passive listeners для лучшей производительности
        button.addEventListener('mousemove', handleMouseMove, { passive: true });
        button.addEventListener('mouseleave', handleMouseLeave, { passive: true });
    });
}

/**
 * Инициализация интерактивных карточек с эффектами 3D-tilt и Bento Box Border Glow
 */
function initFeatureCardsInteraction() {
    const cards = document.querySelectorAll('.feature-card-placeholder');
    const grid = document.querySelector('.features-placeholder-grid');
    
    if (!grid || cards.length === 0) return;
    
    // Глобальный обработчик для Border Glow эффекта
    const handleGridMouseMove = (e) => {
        const gridRect = grid.getBoundingClientRect();
        
        cards.forEach(card => {
            const cardRect = card.getBoundingClientRect();
            const cardCenterX = cardRect.left + cardRect.width / 2;
            const cardCenterY = cardRect.top + cardRect.height / 2;
            
            const deltaX = e.clientX - cardCenterX;
            const deltaY = e.clientY - cardCenterY;
            const distance = Math.sqrt(deltaX * deltaX + deltaY * deltaY);
            
            // Определяем, с какой стороны подсвечивать границу
            const angle = Math.atan2(deltaY, deltaX);
            const glowOpacity = Math.max(0, 1 - distance / 400);
            
            // Применяем градиент на границу
            if (glowOpacity > 0.05) {
                card.style.borderImage = `linear-gradient(${angle}rad, rgba(139, 92, 246, ${glowOpacity * 0.8}), rgba(168, 85, 247, ${glowOpacity * 0.4}), transparent 50%) 1`;
            } else {
                card.style.borderImage = '';
            }
        });
    };
    
    const handleGridMouseLeave = () => {
        cards.forEach(card => {
            card.style.borderImage = '';
        });
    };
    
    // 3D tilt эффект для каждой карточки
    cards.forEach(card => {
        const handleCardMouseMove = (e) => {
            const rect = card.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const centerX = rect.width / 2;
            const centerY = rect.height / 2;
            
            // Вычисляем углы поворота (ограничиваем для плавности)
            const rotateX = ((y - centerY) / centerY) * -8;
            const rotateY = ((x - centerX) / centerX) * 8;
            
            card.style.transform = `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) translateY(-2px)`;
        };
        
        const handleCardMouseLeave = () => {
            card.style.transform = '';
        };
        
        card.addEventListener('mousemove', handleCardMouseMove, { passive: true });
        card.addEventListener('mouseleave', handleCardMouseLeave, { passive: true });
    });
    
    // Привязываем Border Glow к сетке
    grid.addEventListener('mousemove', handleGridMouseMove, { passive: true });
    grid.addEventListener('mouseleave', handleGridMouseLeave, { passive: true });
}

const ROUTE_LAB_ROUTES = {
    swap: { from: 'ETH', to: 'USDC', statusKey: 'routeLabSwapFlow' },
    bridge: { from: 'Base', to: 'Arbitrum', statusKey: 'routeLabBridgeFlow' },
    defi: { from: 'USDC', to: 'Aave', statusKey: 'routeLabDefiFlow' }
};

function updateRouteLab(mode) {
    const card = document.getElementById('route-lab-card');
    if (!card) return;
    const activeButton = card.querySelector('.route-lab__tabs button.active');
    const selectedMode = mode || activeButton?.dataset.routeMode || 'swap';
    const route = ROUTE_LAB_ROUTES[selectedMode] || ROUTE_LAB_ROUTES.swap;
    const from = document.getElementById('route-lab-from');
    const to = document.getElementById('route-lab-to');
    const status = document.getElementById('route-lab-status');
    if (from) from.textContent = route.from;
    if (to) to.textContent = route.to;
    if (status) status.textContent = t(route.statusKey);
    card.dataset.routeMode = selectedMode;
}

function initRouteLab() {
    const card = document.getElementById('route-lab-card');
    if (!card || card.dataset.routeReady === 'true') return;
    card.dataset.routeReady = 'true';
    card.querySelectorAll('.route-lab__tabs button').forEach(button => {
        button.addEventListener('click', () => {
            card.querySelectorAll('.route-lab__tabs button').forEach(item => {
                const selected = item === button;
                item.classList.toggle('active', selected);
                item.setAttribute('aria-pressed', selected ? 'true' : 'false');
            });
            card.classList.remove('route-changing');
            void card.offsetWidth;
            card.classList.add('route-changing');
            updateRouteLab(button.dataset.routeMode);
            window.setTimeout(() => card.classList.remove('route-changing'), 320);
        });
    });
    updateRouteLab();
}

function getSafeStartSteps() {
    const steps = translations[getActiveLang()]?.safeStartSteps;
    return Array.isArray(steps) ? steps : [];
}

function renderSafeStart(nextStep = activeSafeStartStep) {
    const panel = document.getElementById('safe-start-panel');
    const steps = getSafeStartSteps();
    if (!panel || !steps.length) return;

    document.getElementById('safe-stepper')?.setAttribute('aria-label', t('safeStartAria'));

    activeSafeStartStep = Math.max(0, Math.min(Number(nextStep) || 0, steps.length - 1));
    const step = steps[activeSafeStartStep];
    const byId = (id) => document.getElementById(id);
    const setText = (id, value) => {
        const element = byId(id);
        if (element) element.textContent = value || '';
    };

    setText('safe-start-current', String(activeSafeStartStep + 1).padStart(2, '0'));
    setText('safe-shot-number', String(activeSafeStartStep + 1).padStart(2, '0'));
    setText('safe-shot-title', step.title);
    setText('safe-shot-desc', step.description);
    setText('safe-shot-brow', step.screenEyebrow);
    setText('safe-shot-screen-title', step.screenTitle);
    setText('safe-shot-screen-desc', step.screenDescription);
    setText('safe-shot-row-1', step.rows?.[0]);
    setText('safe-shot-row-2', step.rows?.[1]);
    setText('safe-shot-row-3', step.rows?.[2]);
    setText('safe-shot-status', step.status);

    const list = byId('safe-shot-list');
    if (list) {
        list.replaceChildren(...(step.points || []).map(point => {
            const item = document.createElement('li');
            const marker = document.createElement('i');
            const content = document.createElement('span');
            content.textContent = point;
            item.append(marker, content);
            return item;
        }));
    }

    document.querySelectorAll('.safe-step').forEach((button, index) => {
        const selected = index === activeSafeStartStep;
        button.classList.toggle('active', selected);
        button.setAttribute('aria-selected', selected ? 'true' : 'false');
        button.tabIndex = selected ? 0 : -1;
    });

    const previous = byId('safe-step-prev');
    const following = byId('safe-step-next');
    if (previous) {
        previous.disabled = activeSafeStartStep === 0;
        previous.textContent = t('safeStartPrevious');
    }
    if (following) {
        following.textContent = activeSafeStartStep === steps.length - 1 ? t('safeStartFinish') : t('safeStartNext');
    }

    panel.classList.remove('is-switching');
    void panel.offsetWidth;
    panel.classList.add('is-switching');
}

function initSafeStart() {
    const stepper = document.getElementById('safe-stepper');
    if (!stepper || stepper.dataset.ready === 'true') return;
    stepper.dataset.ready = 'true';
    stepper.querySelectorAll('.safe-step').forEach(button => {
        button.addEventListener('click', () => renderSafeStart(Number(button.dataset.safeStep)));
    });
    document.getElementById('safe-step-prev')?.addEventListener('click', () => renderSafeStart(activeSafeStartStep - 1));
    document.getElementById('safe-step-next')?.addEventListener('click', () => {
        const steps = getSafeStartSteps();
        renderSafeStart(activeSafeStartStep === steps.length - 1 ? 0 : activeSafeStartStep + 1);
    });
    stepper.setAttribute('aria-label', t('safeStartAria'));
    renderSafeStart(activeSafeStartStep);
}

/**
 * React Bits-inspired progressive effects for the new AIRDROP-X surface.
 * The content remains fully usable when motion is disabled or unsupported.
 */
function initAirdropXVisualSystem() {
    initPixelSnowBackdrop();
    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const supportsHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
    const cards = document.querySelectorAll('.border-glow-card');
    cards.forEach(card => {
        card.addEventListener('pointermove', event => {
            const rect = card.getBoundingClientRect();
            card.style.setProperty('--card-x', `${event.clientX - rect.left}px`);
            card.style.setProperty('--card-y', `${event.clientY - rect.top}px`);
        }, { passive: true });
    });

    if (supportsHover && !reducedMotion) {
        document.querySelectorAll('.feature-card, .showcase-card, .pricing-card').forEach(card => {
            card.classList.add('ax-motion-card');
            card.addEventListener('pointermove', event => {
                const rect = card.getBoundingClientRect();
                const horizontal = (event.clientX - rect.left) / rect.width - 0.5;
                const vertical = (event.clientY - rect.top) / rect.height - 0.5;
                card.style.setProperty('--tilt-x', `${(-vertical * 4.5).toFixed(2)}deg`);
                card.style.setProperty('--tilt-y', `${(horizontal * 5.5).toFixed(2)}deg`);
            }, { passive: true });
            card.addEventListener('pointerleave', () => {
                card.style.setProperty('--tilt-x', '0deg');
                card.style.setProperty('--tilt-y', '0deg');
            }, { passive: true });
        });
    }

    if (!('IntersectionObserver' in window) || reducedMotion) {
        document.documentElement.classList.add('ax-reveal-ready');
        return;
    }

    const targets = document.querySelectorAll('.feature-card, .showcase-card, .interface-preview, .status-wrap');
    targets.forEach(target => target.classList.add('ax-reveal'));

    const observer = new IntersectionObserver(entries => {
        entries.forEach(entry => {
            if (!entry.isIntersecting) return;
            entry.target.classList.add('ax-reveal--visible');
            observer.unobserve(entry.target);
        });
    }, { threshold: 0.12, rootMargin: '0px 0px -40px' });

    targets.forEach(target => observer.observe(target));
    document.documentElement.classList.add('ax-reveal-ready');
}

/**
 * Lightweight, original ambient particle backdrop. It stays decorative only:
 * no network requests, no pointer handling and a static fallback for reduced motion.
 */
function initPixelSnowBackdrop() {
    const root = document.getElementById('pixel-snow-root');
    if (!root || root.dataset.pixelSnowReady === 'true') return;
    root.dataset.pixelSnowReady = 'true';

    const canvas = document.createElement('canvas');
    canvas.className = 'pixel-snow-canvas';
    canvas.setAttribute('aria-hidden', 'true');
    root.replaceChildren(canvas);

    const context = canvas.getContext('2d', { alpha: true });
    if (!context) return;

    const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const density = 0.65;
    const brightness = 0.4;
    const direction = 145 * (Math.PI / 180);
    const driftX = Math.cos(direction) * 0.23;
    const driftY = Math.sin(direction) * 0.23;
    let particles = [];
    let width = 0;
    let height = 0;
    let previousTime = performance.now();
    let frameId = null;

    const createParticle = (randomY = true) => {
        const depth = 0.22 + Math.random() * 0.78;
        return {
            x: Math.random() * width,
            y: randomY ? Math.random() * height : -12,
            depth,
            radius: 0.45 + depth * 1.55,
            speed: (0.18 + depth * 0.52) * 0.7,
            phase: Math.random() * Math.PI * 2
        };
    };

    const resize = () => {
        const ratio = Math.min(window.devicePixelRatio || 1, 1.5);
        width = Math.max(window.innerWidth, 1);
        height = Math.max(window.innerHeight, 1);
        canvas.width = Math.round(width * ratio);
        canvas.height = Math.round(height * ratio);
        canvas.style.width = `${width}px`;
        canvas.style.height = `${height}px`;
        context.setTransform(ratio, 0, 0, ratio, 0, 0);
        const count = Math.min(190, Math.max(50, Math.round((width * height / 13000) * density)));
        particles = Array.from({ length: count }, () => createParticle());
    };

    const paint = (now) => {
        const delta = Math.min(32, now - previousTime);
        previousTime = now;
        context.clearRect(0, 0, width, height);

        particles.forEach(particle => {
            if (!reducedMotion) {
                particle.x += driftX * particle.speed * delta;
                particle.y += driftY * particle.speed * delta;
                particle.phase += delta * 0.0007;
                if (particle.y > height + 12 || particle.x < -12 || particle.x > width + 12) {
                    Object.assign(particle, createParticle(false), { x: Math.random() * width });
                }
            }

            const twinkle = 0.78 + Math.sin(particle.phase) * 0.22;
            const alpha = (0.06 + particle.depth * 0.20) * brightness * twinkle;
            context.beginPath();
            context.arc(particle.x, particle.y, particle.radius, 0, Math.PI * 2);
            context.fillStyle = `rgba(214, 198, 255, ${alpha.toFixed(3)})`;
            context.fill();
        });

        if (!reducedMotion && !document.hidden) frameId = window.requestAnimationFrame(paint);
    };

    const resume = () => {
        if (reducedMotion || !document.hidden || frameId !== null) return;
        previousTime = performance.now();
        frameId = window.requestAnimationFrame(paint);
    };

    const pause = () => {
        if (!document.hidden || frameId === null) return;
        window.cancelAnimationFrame(frameId);
        frameId = null;
    };

    resize();
    paint(previousTime);
    window.addEventListener('resize', resize, { passive: true });
    document.addEventListener('visibilitychange', () => {
        if (document.hidden) pause();
        else resume();
    });
}

function copyWalletAddress(address, btn) {
    navigator.clipboard.writeText(address);
    const originalText = btn.innerHTML;
    btn.innerHTML = '✅ OK!';
    setTimeout(() => { btn.innerHTML = originalText; }, 2000);
}

function setPaymentStatus(message, type = 'info') {
    const status = document.getElementById('paymentStatusContainer');
    if (!status) return;
    const color = type === 'error' ? '#fca5a5' : type === 'success' ? '#86efac' : '#c4b5fd';
    const line = document.createElement('div');
    line.style.cssText = `color:${color}; font-size:12px; line-height:1.5; margin-top:10px;`;
    line.textContent = String(message || '');
    status.replaceChildren(line);
}

function getPendingSubscriptionPayment() {
    try {
        const pending = JSON.parse(sessionStorage.getItem('ax_subscription_payment_pending') || 'null');
        if (pending?.client_session_id === clientSessionId && pending.payment_session_id && /^0x[0-9a-fA-F]{64}$/.test(pending.txid || '')) {
            return pending;
        }
    } catch (_) {}
    return null;
}

function setPendingSubscriptionPayment(pending) {
    sessionStorage.setItem('ax_subscription_payment_pending', JSON.stringify(pending));
}

function clearPendingSubscriptionPayment() {
    sessionStorage.removeItem('ax_subscription_payment_pending');
}

function parseUsdcAtomic(value) {
    const normalized = String(value || '').trim();
    if (!/^\d+(?:\.\d{1,6})?$/.test(normalized)) return null;
    const [whole, fraction = ''] = normalized.split('.');
    const atomic = BigInt(whole) * 1000000n + BigInt((fraction + '000000').slice(0, 6));
    return atomic > 0n ? atomic : null;
}

function buildErc20TransferData(receiver, amountAtomic) {
    if (!/^0x[0-9a-fA-F]{40}$/.test(receiver || '') || !amountAtomic || amountAtomic <= 0n) return null;
    const receiverWord = receiver.slice(2).toLowerCase().padStart(64, '0');
    const amountWord = amountAtomic.toString(16).padStart(64, '0');
    return `0xa9059cbb${receiverWord}${amountWord}`;
}

function restorePendingSubscriptionPayment() {
    const pending = getPendingSubscriptionPayment();
    if (!pending) return;
    setPaymentStatus(t('paySubmitted'), 'info');
    const button = document.getElementById('paymentActionBtn');
    restorePaymentActionButton(button, t('payCheckStatus'));
}

function restorePaymentActionButton(button, label) {
    if (!button) return;
    button.classList.remove('btn-loading');
    button.disabled = false;
    button.dataset.defaultText = label;
    button.textContent = label;
}

function getPaymentActionLabel() {
    const locale = translations[getActiveLang()] || translations.ru;
    const shownAmount = document.getElementById('paymentAmountValue')?.textContent?.trim();
    if (shownAmount) return `${locale.payWithWallet} · ${shownAmount}`;
    const chosenPlan = localStorage.getItem('selected_plan') || 'Standard';
    const amount = Number(PLAN_PRICES[chosenPlan] || PLAN_PRICES.Standard).toFixed(2);
    return `${locale.payWithWallet} · ${amount} USDC`;
}

async function confirmSubscriptionPayment() {
    const pending = getPendingSubscriptionPayment();
    if (!pending) return false;
    const button = document.getElementById('paymentActionBtn');
    try {
        setButtonLoading(button, true, t('payConfirming'));
        setPaymentStatus(t('payConfirming'), 'info');
        const response = await fetch(
            pending.purpose === 'subscription' ? '/api/subscription/confirm' : '/api/payment/confirm',
            {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(pending),
            },
        );
        const data = await response.json();
        if (!response.ok) {
            if (data.detail === 'Payment session not found' && pending.purpose !== 'subscription') {
                return await recoverTestnetSubscriptionPayment(pending);
            }
            const isWaitingForConfirmation = data.detail === 'USDC payment is waiting for Base confirmation';
            setPaymentStatus(
                isWaitingForConfirmation ? t('payWaitingConfirmation') : translateBackendDetail(data.detail, 'errors.paymentFailed'),
                isWaitingForConfirmation ? 'info' : 'error',
            );
            return false;
        }
        completeSubscriptionPayment(data);
        return true;
    } catch (_) {
        setPaymentStatus(t('errors.networkError'), 'error');
        return false;
    } finally {
        if (!paymentUnlocked) restorePaymentActionButton(button, t('payCheckStatus'));
    }
}

function completeSubscriptionPayment(data) {
    clearPendingSubscriptionPayment();
    if (data?.subscription_updated) {
        userPlan = data.plan || userPlan;
        subscriptionStatus = data.status || 'active';
        subscriptionDaysLeft = Number(data.days_left || 0);
        subscriptionGraceDaysLeft = Number(data.grace_days_left || 0);
        subscriptionExpiresAt = Number(data.expires_at || 0);
        subscriptionExpiryHandled = false;
        localStorage.setItem('selected_plan', userPlan);
        setPaymentStatus(t('subscriptionUpdated'), 'success');
        showNotification(t('subscriptionUpdated'), 'success');
        window.setTimeout(() => {
            closeAuthModal();
            renderDashboardContent('Account');
        }, 700);
        return;
    }
    storePaymentAccess(data);
    setPaymentStatus(t('payConfirmed'), 'success');
    showNotification(t('payConfirmed'));
    setTimeout(() => openModal('register'), 800);
}

function storePaymentAccess(data) {
    if (!data?.payment_token) return false;
    localStorage.removeItem(getPendingRegistrationDismissKey());
    paymentUnlocked = true;
    paymentAccessToken = data.payment_token;
    sessionStorage.setItem('ax_payment_token', paymentAccessToken);
    sessionStorage.setItem('ax_paid_session_id', clientSessionId);
    updateRegistrationContinueAction();
    return true;
}

async function restorePaidRegistrationAccess() {
    try {
        const response = await fetch('/api/payment/resume-registration', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ client_session_id: clientSessionId }),
        });
        if (!response.ok) return false;
        const data = await response.json();
        return storePaymentAccess(data);
    } catch (_) {
        return false;
    }
}

async function recoverTestnetSubscriptionPayment(pending) {
    try {
        setPaymentStatus(t('payConfirming'), 'info');
        const response = await fetch('/api/payment/recover', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                txid: pending.txid,
                client_session_id: clientSessionId,
                plan: localStorage.getItem('selected_plan') || 'Standard',
                onboarding: false,
            }),
        });
        const data = await response.json();
        if (!response.ok) {
            const isWaitingForConfirmation = data.detail === 'USDC payment is waiting for Base confirmation';
            setPaymentStatus(
                isWaitingForConfirmation ? t('payWaitingConfirmation') : translateBackendDetail(data.detail, 'errors.paymentFailed'),
                isWaitingForConfirmation ? 'info' : 'error',
            );
            return false;
        }
        completeSubscriptionPayment(data);
        return true;
    } catch (_) {
        setPaymentStatus(t('errors.networkError'), 'error');
        return false;
    }
}

async function startPlanPayment() {
    const locale = translations[getActiveLang()];
    const chosenPlan = localStorage.getItem('selected_plan') || 'Standard';
    const basePrice = PLAN_PRICES[chosenPlan] || PLAN_PRICES.Standard;
    const button = document.getElementById('paymentActionBtn');
    paymentInteractionInProgress = true;

    try {
        if (getPendingSubscriptionPayment()) {
            await confirmSubscriptionPayment();
            return;
        }
        setButtonLoading(button, true, locale.payPreparing);
        const createRes = await fetch(isLoggedIn ? '/api/subscription/create-session' : '/api/payment/create-session', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ plan: chosenPlan, amount: basePrice, onboarding: false, client_session_id: clientSessionId }),
        });
        const createData = await createRes.json();
        if (!createRes.ok) {
            setPaymentStatus(translateBackendDetail(createData.detail, 'errors.paymentFailed'), 'error');
            return;
        }

        const payment = createData.payment;
        updateSubscriptionPaymentSummary(payment, Boolean(createData.is_testnet));
        const provider = window.ethereum;
        if (!provider?.request || !payment) throw new Error('payment_wallet_unavailable');
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts[0]) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const from = accounts?.[0];
        if (!/^0x[0-9a-fA-F]{40}$/.test(from || '')) throw new Error('payment_wallet_unavailable');
        if (Number(payment.chain_id) === 84532) {
            await switchToBaseSepolia(provider);
        } else if (Number(payment.chain_id) === 8453) {
            await switchToBaseMainnet(provider);
        } else {
            throw new Error('payment_network_unavailable');
        }
        await requestPaymentAssetVisibility(provider, payment);

        const amountAtomic = parseUsdcAtomic(payment.amount);
        const data = buildErc20TransferData(payment.receiver, amountAtomic);
        if (!data || !/^0x[0-9a-fA-F]{40}$/.test(payment.contract || '')) throw new Error('payment_details_invalid');
        setButtonLoading(button, true, locale.payWalletSigning);
        setPaymentStatus(locale.payWalletSigning, 'info');
        const txid = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from, to: payment.contract, data, value: '0x0' }],
        });
        setPendingSubscriptionPayment({
            payment_session_id: createData.payment_session_id,
            client_session_id: clientSessionId,
            txid,
            purpose: isLoggedIn ? 'subscription' : 'registration',
        });
        setPaymentStatus(locale.paySubmitted, 'info');
        await confirmSubscriptionPayment();
    } catch (error) {
        const rejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        const errorMessage = String(error?.message || '');
        const message = rejected
            ? locale.payWalletRejected
            : (errorMessage.includes('payment_wallet_unavailable')
                ? locale.payWalletUnavailable
                : (errorMessage.includes('payment_network_unavailable')
                    ? locale.payNetworkUnavailable
                    : (errorMessage.includes('payment_details_invalid')
                        ? locale.payDetailsInvalid
                        : locale.errors.networkError)));
        setPaymentStatus(message, 'error');
    } finally {
        paymentInteractionInProgress = false;
        if (!paymentUnlocked) {
            restorePaymentActionButton(
                button,
                getPendingSubscriptionPayment() ? locale.payCheckStatus : getPaymentActionLabel(),
            );
        }
    }
}

async function requestPaymentAssetVisibility(provider, payment) {
    // This only asks the wallet to display the verified USDC token. It cannot
    // move funds and a wallet may safely decline or ignore the request.
    try {
        await provider.request({
            method: 'wallet_watchAsset',
            params: {
                type: 'ERC20',
                options: {
                    address: payment.contract,
                    symbol: payment.asset || 'USDC',
                    decimals: Number(payment.decimals) || 6,
                },
            },
        });
    } catch (_) {
        // Asset visibility is optional and must never block a signed payment.
    }
}

function updateSubscriptionPaymentSummary(payment, isTestnet) {
    const locale = translations[getActiveLang()];
    const amount = `${payment.amount} ${payment.asset || 'USDC'}`;
    const amountElement = document.getElementById('paymentAmountValue');
    const button = document.getElementById('paymentActionBtn');
    const testModeNotice = document.getElementById('paymentTestModeNotice');
    if (amountElement) amountElement.textContent = amount;
    if (button) button.textContent = `${locale.payWithWallet} · ${amount}`;
    if (testModeNotice) {
        testModeNotice.textContent = isTestnet ? locale.payTestMode : '';
        testModeNotice.style.display = isTestnet ? 'block' : 'none';
    }
}

async function validateRegister() {
    const username = document.getElementById('regUsername').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const pass = document.getElementById('regPass').value.trim();
    const code = document.getElementById('regCode').value.trim();
    const chosenPlan = localStorage.getItem('selected_plan') || 'Standard';
    const submitBtn = document.querySelector('#modalContainer .btn-modal-primary');

    if (!username) {
        setFormError('errorContainer', t('errors.fillAllFields'), 'error', 'regUsername');
        document.getElementById('regUsername')?.focus();
        return;
    }
    if (!email) {
        setFormError('errorContainer', t('errors.fillAllFields'), 'error', 'regEmail');
        document.getElementById('regEmail')?.focus();
        return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        setFormError('errorContainer', t('errors.invalidEmail'), 'error', 'regEmail');
        document.getElementById('regEmail')?.focus();
        return;
    }
    if (!pass) {
        setFormError('errorContainer', t('errors.fillAllFields'), 'error', 'regPass');
        document.getElementById('regPass')?.focus();
        return;
    }
    if (pass.length < 12) {
        setFormError('errorContainer', t('errors.registrationPasswordTooShort'), 'error', 'regPass');
        document.getElementById('regPass')?.focus();
        return;
    }
    if (!code) {
        setFormError('errorContainer', t('errors.fillAllFields'), 'error', 'regCode');
        document.getElementById('regCode')?.focus();
        return;
    }

    setButtonLoading(submitBtn, true, t('auth.register'));

    try {
        // The server owns the payment state. Refresh the one-use token here so
        // a harmless page/server restart can never make a confirmed payment disappear.
        const paymentRestored = await restorePaidRegistrationAccess();
        if (!paymentRestored) {
            setFormError('errorContainer', t('errors.paymentRegistrationUnavailable'));
            return;
        }
        const requestData = {
            username,
            email,
            password: pass,
            code,
            plan: chosenPlan,
            payment_token: paymentAccessToken,
            client_session_id: clientSessionId,
            fingerprint: deviceFingerprint
        };
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(requestData)
        });

        const result = await response.json();

        if (!response.ok) {
            let errMsg = t('errors.genericRequestFailed');
            if (result.detail) {
                errMsg = translateBackendDetail(result.detail);
            }
            setFormError('errorContainer', errMsg);
            return;
        }

        if (typeof clearPaymentAccess === 'function') {
            clearPaymentAccess();
        }
        sessionStorage.removeItem('ax_registration_email');
        sessionStorage.removeItem('ax_email_code_cooldown_until');
        setFormError('errorContainer', t('auth.registerSuccess'), 'success');
        showNotification(t('auth.registerSuccess'));
        setTimeout(() => openModal('login'), 1200);
    } catch (error) {
        setFormError('errorContainer', t('errors.networkError'));
    } finally {
        setButtonLoading(submitBtn, false, t('auth.register'));
    }
}

async function validateLogin() {
    if (loginRequestInFlight) return;
    if (Date.now() < loginRateLimitUntil) {
        renderLoginRateLimitState();
        return;
    }
    const username = document.getElementById('loginUsername').value.trim();
    const pass = document.getElementById('loginPass').value.trim();
    const err = document.getElementById('loginErrorContainer');
    const submitBtn = document.querySelector('#modalContainer .btn-modal-primary');

    if (!username) {
        setFormError('loginErrorContainer', t('errors.fillAllFields'), 'error', 'loginUsername');
        document.getElementById('loginUsername')?.focus();
        return;
    }
    if (!pass) {
        setFormError('loginErrorContainer', t('errors.fillAllFields'), 'error', 'loginPass');
        document.getElementById('loginPass')?.focus();
        return;
    }
    if (pass.length < 6) {
        setFormError('loginErrorContainer', t('errors.passwordTooShort'), 'error', 'loginPass');
        document.getElementById('loginPass')?.focus();
        return;
    }

    loginRequestInFlight = true;
    setButtonLoading(submitBtn, true, t('auth.login'));

    try {
        const res = await fetch('/api/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password: pass, fingerprint: deviceFingerprint })
        });
        const data = await res.json();

        if (res.ok) {
            localStorage.setItem('airdrop_username', data.username);
            sessionStorage.setItem('ax_access_token', data.access_token);
            userPlan = data.plan || 'Standard';
            subscriptionDaysLeft = data.days_left ?? 29;
            subscriptionStatus = data.subscription_status || 'active';
            subscriptionGraceDaysLeft = Number(data.grace_days_left || 0);
            subscriptionExpiresAt = Number(data.subscription_expires_at || 0);
            handleLoginSuccess();
        } else {
            let errMsg = t('errors.loginFailed');
            if (res.status === 429) {
                startLoginRateLimitCooldown(res.headers.get('Retry-After'));
            } else {
                if (data.detail) errMsg = translateBackendDetail(data.detail, 'errors.loginFailed');
                setFormError('loginErrorContainer', errMsg);
            }
        }
    } catch (error) {
        setFormError('loginErrorContainer', t('errors.networkError'));
    } finally {
        loginRequestInFlight = false;
        if (Date.now() < loginRateLimitUntil) {
            renderLoginRateLimitState();
        } else {
            setButtonLoading(submitBtn, false, t('auth.login'));
        }
    }
}

function handleLoginSuccess() {
    isLoggedIn = true;
    authExpiryHandled = false;
    subscriptionExpiryHandled = false;
    document.documentElement.classList.add('ax-dashboard-active');
    const loginBtn = document.getElementById('login-btn');
    if (loginBtn) loginBtn.style.display = 'none';
    hideAllAppModals();
    document.getElementById('main-content').style.display = 'none';
    document.getElementById('dashboard-content').style.display = 'flex';
    const mobileNav = document.getElementById('mobileNavBar');
    if(mobileNav) mobileNav.style.display = ''; 
    currentSection = 'Account';
    renderDashboardContent('Account');
    void initializeWalletSessionLifecycle();
    if (subscriptionStatus === 'grace') {
        showNotification(
            t('subscriptionGrace').replace('{days}', subscriptionGraceDaysLeft),
            'warning',
        );
    } else if (subscriptionStatus === 'expired') {
        window.setTimeout(handleSubscriptionExpired, 100);
    } else {
        showNotification("OK!");
    }
}

function handleExpiredAuthSession() {
    if (authExpiryHandled) return;
    authExpiryHandled = true;
    returnToMainSite();
    showNotification(t('sessionExpired'), 'error');
}

function closeWalletConnectModal() {
    hideAppModal('walletConnectModal');
}

function handleWalletConnectOverlayClick(event) {
    if (event.target.id === 'walletConnectModal' && mousedownOverlayTarget.id === 'walletConnectModal') {
        closeWalletConnectModal();
    }
}

let baseSwapConfirmationResolver = null;

function formatConfirmationUsd(amount, unitPrice) {
    const value = Number(amount);
    const price = Number(unitPrice);
    if (!Number.isFinite(value) || value <= 0 || !Number.isFinite(price) || price <= 0) return '';
    return `≈ $${(value * price).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function setBaseSwapConfirmationDetails(details) {
    const container = document.getElementById('baseSwapConfirmDetails');
    if (!container) return;
    const visibleDetails = (Array.isArray(details) ? details : []).filter((detail) => detail?.label && detail?.value);
    container.replaceChildren();
    if (!visibleDetails.length) {
        container.style.display = 'none';
        return;
    }
    for (const detail of visibleDetails) {
        const row = document.createElement('div');
        row.style.cssText = 'background:rgba(255,255,255,.025); border:1px solid var(--border-color); border-radius:9px; padding:8px 10px; min-width:0;';
        const label = document.createElement('div');
        label.textContent = detail.label;
        label.style.cssText = 'font-size:10px; color:var(--text-muted);';
        const value = document.createElement('div');
        value.textContent = detail.value;
        value.style.cssText = 'font-size:11px; color:#e9d5ff; font-weight:600; line-height:1.35; margin-top:3px; overflow-wrap:anywhere;';
        row.append(label, value);
        container.append(row);
    }
    container.style.display = 'grid';
}

function setBaseSwapConfirmationWarning(message = '') {
    const warning = document.getElementById('baseSwapConfirmWarning');
    if (!warning) return;
    warning.textContent = message;
    warning.style.display = message ? 'block' : 'none';
}

function getUniversalBridgeRouteWarning(quote) {
    const locale = translations[getActiveLang()];
    const fromToken = quote?.from_token || {};
    const toToken = quote?.to_token || {};
    const stableSymbols = new Set(['USDC', 'USDT', 'DAI']);
    const sourcePrice = Number(activeUniversalBridgeAsset?.unit_price_usd || fromToken.priceUSD || fromToken.price_usd);
    const sameAsset = String(fromToken.symbol || '').toUpperCase() === String(toToken.symbol || '').toUpperCase();
    const targetPrice = stableSymbols.has(String(toToken.symbol || '').toUpperCase())
        ? 1
        : Number(toToken.priceUSD || toToken.price_usd || (sameAsset ? sourcePrice : 0));
    const sourceValue = Number(quote?.amount_in) * sourcePrice;
    const minimumValue = Number(quote?.amount_out_min || quote?.amount_out) * targetPrice;
    if (!Number.isFinite(sourceValue) || !Number.isFinite(minimumValue) || sourceValue <= 0 || minimumValue <= 0) return '';
    const impactPercent = ((sourceValue - minimumValue) / sourceValue) * 100;
    if (!Number.isFinite(impactPercent) || impactPercent < 3) return '';
    return locale.universalBridgeCostWarning
        .replace('{percent}', impactPercent.toLocaleString(undefined, { maximumFractionDigits: 1 }))
        .replace('{loss}', `$${(sourceValue - minimumValue).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`);
}

function openBaseSwapConfirmation(amount, output) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('baseSwapConfirmModal');
    if (!modal) return Promise.resolve(false);
    if (baseSwapConfirmationResolver) baseSwapConfirmationResolver(false);
    document.getElementById('baseSwapConfirmTitle').textContent = locale.baseSwapModalTitle;
    document.getElementById('baseSwapConfirmNetwork').textContent = locale.baseSwapModalNetwork;
    document.getElementById('baseSwapConfirmPayLabel').textContent = locale.baseSwapYouPay;
    document.getElementById('baseSwapConfirmPayValue').textContent = `${amount} ETH`;
    document.getElementById('baseSwapConfirmReceiveLabel').textContent = locale.baseSwapYouReceive;
    document.getElementById('baseSwapConfirmReceiveValue').textContent = `≈ ${output} USDC`;
    setBaseSwapConfirmationDetails([
        { label: locale.confirmationAmountUsd, value: formatConfirmationUsd(amount, getSelectedOperationAssetData()?.unit_price_usd) },
        { label: locale.confirmationNetworkFee, value: locale.confirmationNetworkFeeWallet },
        { label: locale.confirmationWalletCheck, value: locale.confirmationWalletCheckValue },
    ]);
    setBaseSwapConfirmationWarning('');
    document.getElementById('baseSwapConfirmNotice').textContent = locale.baseSwapModalNotice;
    document.getElementById('baseSwapConfirmCancel').textContent = locale.baseSwapModalCancel;
    document.getElementById('baseSwapConfirmProceed').textContent = locale.baseSwapModalProceed;
    showAppModal('baseSwapConfirmModal');
    return new Promise((resolve) => {
        baseSwapConfirmationResolver = resolve;
    });
}

function openBaseTransferConfirmation(amount, recipientAddress, recipientName) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('baseSwapConfirmModal');
    if (!modal) return Promise.resolve(false);
    if (baseSwapConfirmationResolver) baseSwapConfirmationResolver(false);
    document.getElementById('baseSwapConfirmTitle').textContent = locale.directTransferModalTitle;
    document.getElementById('baseSwapConfirmNetwork').textContent = locale.directTransferModalNetwork;
    document.getElementById('baseSwapConfirmPayLabel').textContent = locale.directTransferModalPayLabel;
    document.getElementById('baseSwapConfirmPayValue').textContent = `${amount} ETH`;
    document.getElementById('baseSwapConfirmReceiveLabel').textContent = locale.directTransferModalReceiveLabel;
    document.getElementById('baseSwapConfirmReceiveValue').textContent = `${recipientName} · ${recipientAddress.slice(0, 6)}…${recipientAddress.slice(-4)}`;
    setBaseSwapConfirmationDetails([
        { label: locale.confirmationAmountUsd, value: formatConfirmationUsd(amount, getDirectTransferEthAsset()?.unit_price_usd) },
        { label: locale.confirmationNetworkFee, value: locale.confirmationNetworkFeeWallet },
        { label: locale.confirmationWalletCheck, value: locale.confirmationWalletCheckValue },
    ]);
    setBaseSwapConfirmationWarning('');
    document.getElementById('baseSwapConfirmNotice').textContent = locale.directTransferModalNotice;
    document.getElementById('baseSwapConfirmCancel').textContent = locale.baseSwapModalCancel;
    document.getElementById('baseSwapConfirmProceed').textContent = locale.directTransferModalProceed;
    showAppModal('baseSwapConfirmModal');
    return new Promise((resolve) => {
        baseSwapConfirmationResolver = resolve;
    });
}

function openUniversalBridgeConfirmation(quote, approval = false) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('baseSwapConfirmModal');
    if (!modal) return Promise.resolve(false);
    if (baseSwapConfirmationResolver) baseSwapConfirmationResolver(false);
    const fromToken = quote?.from_token || {};
    const toToken = quote?.to_token || {};
    const routeText = `${quote?.from_network || ''} → ${quote?.to_network || ''}`;
    document.getElementById('baseSwapConfirmTitle').textContent = approval
        ? locale.universalBridgeApprovalModalTitle
        : locale.universalBridgeModalTitle;
    document.getElementById('baseSwapConfirmNetwork').textContent = approval
        ? locale.universalBridgeApprovalModalNetwork.replace('{network}', quote?.from_network || '')
        : locale.universalBridgeModalNetwork.replace('{route}', routeText);
    document.getElementById('baseSwapConfirmPayLabel').textContent = approval
        ? locale.universalBridgeApprovalPayLabel
        : locale.baseSwapYouPay;
    document.getElementById('baseSwapConfirmPayValue').textContent = approval
        ? `${quote?.amount_in || ''} ${fromToken.symbol || ''}`
        : `${quote?.amount_in || ''} ${fromToken.symbol || ''}`;
    document.getElementById('baseSwapConfirmReceiveLabel').textContent = approval
        ? locale.universalBridgeApprovalReceiveLabel
        : locale.baseSwapYouReceive;
    document.getElementById('baseSwapConfirmReceiveValue').textContent = approval
        ? `${String(quote?.approval?.spender || '').slice(0, 6)}…${String(quote?.approval?.spender || '').slice(-4)}`
        : `≥ ${quote?.amount_out_min || quote?.amount_out || ''} ${toToken.symbol || ''}`;
    const contractAddress = approval ? quote?.approval?.spender : quote?.transaction?.to;
    setBaseSwapConfirmationDetails([
        { label: locale.confirmationAmountUsd, value: formatConfirmationUsd(quote?.amount_in, activeUniversalBridgeAsset?.unit_price_usd) },
        { label: approval ? locale.confirmationApproval : locale.confirmationRouteContract, value: contractAddress || '' },
        { label: approval ? locale.confirmationApprovalScope : locale.confirmationNetworkFee, value: approval ? locale.confirmationApprovalExact : locale.confirmationNetworkFeeWallet },
        { label: locale.confirmationWalletCheck, value: locale.confirmationWalletCheckValue },
    ]);
    setBaseSwapConfirmationWarning(approval ? '' : getUniversalBridgeRouteWarning(quote));
    document.getElementById('baseSwapConfirmNotice').textContent = approval
        ? locale.universalBridgeApprovalModalNotice
        : locale.universalBridgeModalNotice
            .replace('{tool}', quote?.tool || 'LI.FI')
            .replace('{amount}', quote?.amount_out || '—')
            .replace('{symbol}', toToken.symbol || '');
    document.getElementById('baseSwapConfirmCancel').textContent = locale.baseSwapModalCancel;
    document.getElementById('baseSwapConfirmProceed').textContent = approval
        ? locale.universalBridgeApprovalProceed
        : locale.universalBridgeModalProceed;
    showAppModal('baseSwapConfirmModal');
    return new Promise((resolve) => {
        baseSwapConfirmationResolver = resolve;
    });
}

function openAaveSupplyConfirmation(quote, approval = false) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('baseSwapConfirmModal');
    if (!modal) return Promise.resolve(false);
    if (baseSwapConfirmationResolver) baseSwapConfirmationResolver(false);
    const asset = quote?.asset || { symbol: 'USDC' };
    const pool = String(quote?.pool_address || '');
    document.getElementById('baseSwapConfirmTitle').textContent = approval
        ? locale.defiSupplyApprovalTitle
        : locale.defiSupplyModalTitle;
    document.getElementById('baseSwapConfirmNetwork').textContent = approval
        ? locale.defiSupplyApprovalNetwork
        : locale.defiSupplyModalNetwork;
    document.getElementById('baseSwapConfirmPayLabel').textContent = approval
        ? locale.defiSupplyApprovalPay
        : locale.defiSupplyPay;
    document.getElementById('baseSwapConfirmPayValue').textContent = `${quote?.amount || ''} ${asset.symbol || ''}`;
    document.getElementById('baseSwapConfirmReceiveLabel').textContent = approval
        ? locale.defiSupplyApprovalReceive
        : locale.defiSupplyReceive;
    document.getElementById('baseSwapConfirmReceiveValue').textContent = approval
        ? `${pool.slice(0, 6)}…${pool.slice(-4)}`
        : `a${asset.symbol || 'USDC'}`;
    setBaseSwapConfirmationDetails([
        { label: approval ? locale.confirmationApproval : locale.defiSupplyRate, value: approval ? pool : `${Number(quote?.annual_supply_rate_percent || 0).toLocaleString(undefined, { maximumFractionDigits: 4 })}%` },
        { label: approval ? locale.confirmationApprovalScope : locale.confirmationRouteContract, value: approval ? locale.confirmationApprovalExact : pool },
        { label: locale.confirmationNetworkFee, value: locale.confirmationNetworkFeeWallet },
        { label: locale.confirmationWalletCheck, value: locale.confirmationWalletCheckValue },
    ]);
    setBaseSwapConfirmationWarning(approval ? '' : locale.defiSupplyRateVariable);
    document.getElementById('baseSwapConfirmNotice').textContent = approval
        ? locale.defiSupplyApprovalNotice
        : locale.defiSupplyModalNotice;
    document.getElementById('baseSwapConfirmCancel').textContent = locale.baseSwapModalCancel;
    document.getElementById('baseSwapConfirmProceed').textContent = approval
        ? locale.defiSupplyApprovalProceed
        : locale.defiSupplyProceed;
    showAppModal('baseSwapConfirmModal');
    return new Promise((resolve) => {
        baseSwapConfirmationResolver = resolve;
    });
}

function openAaveWithdrawConfirmation(quote) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('baseSwapConfirmModal');
    if (!modal) return Promise.resolve(false);
    if (baseSwapConfirmationResolver) baseSwapConfirmationResolver(false);
    const asset = quote?.asset || { symbol: 'USDC' };
    const pool = String(quote?.pool_address || '');
    document.getElementById('baseSwapConfirmTitle').textContent = locale.defiWithdrawModalTitle;
    document.getElementById('baseSwapConfirmNetwork').textContent = locale.defiWithdrawModalNetwork;
    document.getElementById('baseSwapConfirmPayLabel').textContent = locale.defiWithdrawPay;
    document.getElementById('baseSwapConfirmPayValue').textContent = `${quote?.amount || ''} a${asset.symbol || 'USDC'}`;
    document.getElementById('baseSwapConfirmReceiveLabel').textContent = locale.defiWithdrawReceive;
    document.getElementById('baseSwapConfirmReceiveValue').textContent = `${quote?.amount || ''} ${asset.symbol || 'USDC'}`;
    setBaseSwapConfirmationDetails([
        { label: locale.confirmationRouteContract, value: pool },
        { label: locale.confirmationNetworkFee, value: locale.confirmationNetworkFeeWallet },
        { label: locale.confirmationWalletCheck, value: locale.confirmationWalletCheckValue },
    ]);
    setBaseSwapConfirmationWarning('');
    document.getElementById('baseSwapConfirmNotice').textContent = locale.defiWithdrawModalNotice;
    document.getElementById('baseSwapConfirmCancel').textContent = locale.baseSwapModalCancel;
    document.getElementById('baseSwapConfirmProceed').textContent = locale.defiWithdrawProceed;
    showAppModal('baseSwapConfirmModal');
    return new Promise((resolve) => {
        baseSwapConfirmationResolver = resolve;
    });
}

function finishBaseSwapConfirmation(confirmed) {
    hideAppModal('baseSwapConfirmModal');
    const resolve = baseSwapConfirmationResolver;
    baseSwapConfirmationResolver = null;
    if (resolve) resolve(Boolean(confirmed));
}

function handleBaseSwapConfirmOverlayClick(event) {
    if (event.target.id === 'baseSwapConfirmModal' && mousedownOverlayTarget?.id === 'baseSwapConfirmModal') {
        finishBaseSwapConfirmation(false);
    }
}

function openWalletConnectQr(uri) {
    const locale = translations[getActiveLang()];
    const modal = document.getElementById('walletConnectModal');
    const title = document.getElementById('walletConnectModalTitle');
    const desc = document.getElementById('walletConnectModalDesc');
    const close = document.getElementById('walletConnectModalClose');
    const qrContainer = document.getElementById('walletConnectQrCode');
    if (!modal || !qrContainer || !window.qrcode) {
        showNotification(locale.walletConnectQrUnavailable, 'error');
        return;
    }
    title.textContent = locale.walletConnectQrTitle;
    desc.textContent = locale.walletConnectQrDesc;
    close.textContent = locale.walletConnectClose;
    qrContainer.innerHTML = '';
    const qr = qrcode(0, 'M');
    qr.addData(uri);
    qr.make();
    qrContainer.innerHTML = qr.createSvgTag({ cellSize: 5, margin: 1 });
    showAppModal('walletConnectModal');
}

function switchMenu(element, sectionName) {
    currentSection = sectionName;
    localStorage.setItem('airdrop_current_section', sectionName);
    renderDashboardContent(sectionName);
}

function handleSubscriptionExpired() {
    subscriptionStatus = 'expired';
    subscriptionDaysLeft = 0;
    if (subscriptionExpiryHandled) return;
    subscriptionExpiryHandled = true;
    if (isLoggedIn) renderDashboardContent('Account');
    showNotification(t('subscriptionRequired'), 'warning');
    openPricingModal();
}

function syncMobileNavigation() {
    const navigation = document.getElementById('mobileNavBar');
    if (!navigation) return;
    const locale = translations[getActiveLang()] || translations.ru;
    const labels = {
        'mn-account': locale.menuAcc,
        'mn-farming': locale.menuFarm,
        'mn-wallets': locale.menuWallets,
        'mn-networks': locale.menuNet,
        'mn-more': locale.mobileNavMore
    };
    Object.entries(labels).forEach(([id, label]) => {
        const target = document.getElementById(id);
        if (target) target.textContent = label;
    });
    navigation.querySelectorAll('[data-mobile-section]').forEach((button) => {
        const section = button.dataset.mobileSection;
        const isMore = section === 'more';
        button.classList.toggle('active', isMore
            ? currentSection === 'Looter' || currentSection === 'Settings'
            : currentSection === section);
    });
}

function switchMobileNav(section, element) {
    closeBottomSheetMenu();
    switchMenu(element, section);
}

function openBottomSheetMenu(trigger) {
    const overlay = document.getElementById('bottomSheetOverlay');
    const items = document.getElementById('sheetMenuItemsContainer');
    if (!overlay || !items) return;
    const locale = translations[getActiveLang()] || translations.ru;
    items.innerHTML = `
        <div class="mobile-sheet-heading">${escapeHtml(locale.mobileNavMore)}</div>
        <button type="button" class="mobile-sheet-item ${currentSection === 'Looter' ? 'active' : ''}" onclick="switchMobileNav('Looter', this)">${escapeHtml(locale.menuLooter)}</button>
        <button type="button" class="mobile-sheet-item ${currentSection === 'Settings' ? 'active' : ''}" onclick="switchMobileNav('Settings', this)">${escapeHtml(locale.menuSet)}</button>
        <button type="button" class="mobile-sheet-item mobile-sheet-item--logout" onclick="closeBottomSheetMenu(); logoutUser()">${escapeHtml(locale.menuExit)}</button>
    `;
    overlay.classList.add('show');
    document.body.classList.add('mobile-sheet-open');
    if (trigger) trigger.setAttribute('aria-expanded', 'true');
}

function closeBottomSheetMenu() {
    const overlay = document.getElementById('bottomSheetOverlay');
    if (overlay) overlay.classList.remove('show');
    document.body.classList.remove('mobile-sheet-open');
    const moreButton = document.querySelector('#mobileNavBar [data-mobile-section="more"]');
    if (moreButton) moreButton.setAttribute('aria-expanded', 'false');
}

function handleSheetOverlayClick(event) {
    if (event.target?.id === 'bottomSheetOverlay') closeBottomSheetMenu();
}

function networkDomId(network) {
    return String(network || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

function formatNetworkBalance(value) {
    const number = Number(value);
    if (!Number.isFinite(number)) return '—';
    if (number === 0) return '0';
    if (Math.abs(number) < 0.000001) return '< 0.000001';
    return number.toLocaleString(undefined, { maximumFractionDigits: number < 1 ? 6 : 4 });
}

function setNetworkOverviewWallet(walletId) {
    localStorage.setItem('ax_network_overview_wallet_id', String(walletId || ''));
    loadNetworksOverview();
}

function openBridgeFromNetwork(network) {
    if (!UNIVERSAL_BRIDGE_NETWORKS[network]) return;
    localStorage.setItem('ax_activity_pane', 'bridges');
    localStorage.setItem('ax_bridge_source_network', network);
    switchMenu(null, 'Farming');
}

async function loadNetworksOverview() {
    const locale = translations[getActiveLang()];
    const selector = document.getElementById('networkOverviewWallet');
    const status = document.getElementById('networkOverviewStatus');
    if (!selector || !status) return;
    const username = getCurrentUsername();
    try {
        const response = await fetch(`/api/wallets/${encodeURIComponent(username)}`);
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.wallets)) throw new Error('wallets_unavailable');
        networksOverviewWallets = data.wallets;
        const activeAddress = getActiveBaseWalletAddress().toLowerCase();
        const rememberedId = String(localStorage.getItem('ax_network_overview_wallet_id') || '');
        const selected = data.wallets.find((wallet) => String(wallet.id) === rememberedId)
            || data.wallets.find((wallet) => wallet.wallet_address?.toLowerCase() === activeAddress)
            || data.wallets[0];
        selector.replaceChildren();
        if (!selected) {
            const option = document.createElement('option');
            option.value = '';
            option.textContent = locale.networkOverviewNoWallet;
            selector.append(option);
            selector.disabled = true;
            status.textContent = locale.networkOverviewNoWallet;
            status.style.color = 'var(--text-muted)';
            return;
        }
        data.wallets.forEach((wallet) => {
            const option = document.createElement('option');
            option.value = String(wallet.id);
            const label = wallet.label || `${locale.walletDefaultName} ${wallet.id}`;
            option.textContent = `${label} · ${String(wallet.wallet_address || '').slice(0, 6)}…${String(wallet.wallet_address || '').slice(-4)}`;
            selector.append(option);
        });
        selector.disabled = false;
        selector.value = String(selected.id);
        localStorage.setItem('ax_network_overview_wallet_id', String(selected.id));
        status.textContent = locale.networkOverviewLoading;
        status.style.color = 'var(--text-muted)';
        await Promise.all(NETWORKS_CONFIG.map((network) => loadNetworkOverviewCard(selected.id, network)));
        status.textContent = locale.networkOverviewLive;
        status.style.color = '#86efac';
    } catch (_) {
        status.textContent = locale.networkOverviewUnavailable;
        status.style.color = '#fca5a5';
        NETWORKS_CONFIG.forEach((network) => {
            const element = document.getElementById(`networkOverview-${networkDomId(network.key)}`);
            if (element) element.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(locale.networkOverviewUnavailable)}</span>`;
        });
    }
}

async function loadNetworkOverviewCard(walletId, network) {
    const locale = translations[getActiveLang()];
    const id = networkDomId(network.key);
    const balanceElement = document.getElementById(`networkOverview-${id}`);
    const gasElement = document.getElementById(`networkGas-${id}`);
    const statusElement = document.getElementById(`networkStatus-${id}`);
    if (!balanceElement || !gasElement || !statusElement) return;
    try {
        const [balanceResponse, gasResponse] = await Promise.all([
            fetch(`/api/wallets/${encodeURIComponent(walletId)}/network-balance/${encodeURIComponent(network.key)}`),
            fetch(`/api/gas/${encodeURIComponent(network.key)}`),
        ]);
        const balanceData = await balanceResponse.json();
        const gasData = await gasResponse.json();
        if (!balanceResponse.ok) throw new Error(balanceData.detail || 'balance_unavailable');
        const native = `${formatNetworkBalance(balanceData.native_balance)} ${escapeHtml(balanceData.native_symbol || network.symbol)}`;
        const usdc = balanceData.usdc_balance === null || balanceData.usdc_balance === undefined
            ? ''
            : `<span>USDC: <b>${formatNetworkBalance(balanceData.usdc_balance)}</b></span>`;
        const reserve = `${escapeHtml(locale.networkOverviewReserve)}: ${escapeHtml(String(balanceData.native_gas_reserve || '0'))} ${escapeHtml(balanceData.native_symbol || network.symbol)}`;
        const reserveColor = balanceData.native_gas_reserve_met ? '#86efac' : '#fca5a5';
        balanceElement.innerHTML = `<div class="network-overview-balance">${native}</div><div class="network-overview-assets">${usdc}<span style="color:${reserveColor};">${reserve}</span></div>`;
        const level = gasData.gas_level || 'unavailable';
        const levelKey = `gas${level.charAt(0).toUpperCase()}${level.slice(1)}`;
        const color = { low: '#86efac', medium: '#facc15', high: '#fca5a5', unavailable: '#a3a3a3' }[level] || '#a3a3a3';
        gasElement.textContent = gasResponse.ok && gasData.gas ? `${gasData.gas} · ${locale[levelKey] || locale.gasUnavailable}` : locale.gasUnavailable;
        gasElement.style.color = color;
        statusElement.textContent = locale.networkOverviewOnline;
        statusElement.style.color = '#86efac';
    } catch (_) {
        balanceElement.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(locale.networkOverviewBalanceUnavailable)}</span>`;
        gasElement.textContent = locale.gasUnavailable;
        gasElement.style.color = '#a3a3a3';
        statusElement.textContent = locale.networkOverviewOffline;
        statusElement.style.color = '#fca5a5';
    }
}

function switchActivityPane(pane) {
    const allowedPanes = new Set(['dex', 'bridges', 'lending', 'journal']);
    localStorage.setItem('ax_activity_pane', allowedPanes.has(pane) ? pane : 'dex');
    renderDashboardContent('Farming');
}

function getActiveBaseWalletAddress() {
    const username = getCurrentUsername();
    const persisted = walletSessionStateApi?.read(localStorage, username)?.activeAddress || '';
    const active = persisted || sessionStorage.getItem('ax_active_wallet_address') || '';
    if (active) sessionStorage.setItem('ax_active_wallet_address', active);
    return active;
}

function getConnectedBaseWalletAddress() {
    return sessionStorage.getItem('ax_base_wallet_address') || '';
}

function getWalletSessionPersistenceState() {
    return walletSessionStateApi?.read(localStorage, getCurrentUsername()) || {
        activeAddress: getActiveBaseWalletAddress(), connectedAddress: getConnectedBaseWalletAddress(), providerKind: '', chainId: '',
    };
}

function setActiveBaseWalletAddress(address) {
    const normalized = walletSessionStateApi?.normalizeAddress(address) || '';
    if (!normalized) return '';
    walletSessionStateApi?.setActive(localStorage, getCurrentUsername(), normalized);
    sessionStorage.setItem('ax_active_wallet_address', normalized);
    const connected = getConnectedBaseWalletAddress();
    if (connected && connected.toLowerCase() !== normalized.toLowerCase()) {
        sessionStorage.removeItem('ax_base_wallet_address');
    }
    return normalized;
}

function setConnectedBaseWalletAddress(address, providerKind = '', chainId = '') {
    const normalized = walletSessionStateApi?.normalizeAddress(address) || '';
    if (!normalized || !['metamask', 'walletconnect'].includes(providerKind)) return '';
    walletSessionStateApi?.setConnection(localStorage, getCurrentUsername(), {
        address: normalized, providerKind, chainId,
    });
    sessionStorage.setItem('ax_base_wallet_address', normalized);
    return normalized;
}

function rememberWalletProviderKind(providerKind, chainId = '') {
    if (!['metamask', 'walletconnect'].includes(providerKind)) return;
    walletSessionStateApi?.setConnection(localStorage, getCurrentUsername(), {
        address: '', providerKind, chainId,
    });
    sessionStorage.removeItem('ax_base_wallet_address');
}

function clearConnectedWalletState({ keepProvider = false } = {}) {
    const state = getWalletSessionPersistenceState();
    if (keepProvider && ['metamask', 'walletconnect'].includes(state.providerKind)) {
        rememberWalletProviderKind(state.providerKind, state.chainId);
    } else {
        walletSessionStateApi?.clearConnection(localStorage, getCurrentUsername());
        sessionStorage.removeItem('ax_base_wallet_address');
    }
}

function clearActiveWalletState() {
    const state = getWalletSessionPersistenceState();
    walletSessionStateApi?.write(localStorage, getCurrentUsername(), {
        ...state, activeAddress: '', connectedAddress: '',
    });
    sessionStorage.removeItem('ax_active_wallet_address');
    sessionStorage.removeItem('ax_base_wallet_address');
}

function restoreWalletStateMirrors() {
    const username = getCurrentUsername();
    if (!username) return;
    let state = walletSessionStateApi?.read(localStorage, username);
    const legacyActive = sessionStorage.getItem('ax_active_wallet_address') || '';
    const legacyConnected = sessionStorage.getItem('ax_base_wallet_address') || '';
    if (!state?.activeAddress && walletSessionStateApi?.normalizeAddress(legacyActive || legacyConnected)) {
        state = walletSessionStateApi.setActive(localStorage, username, legacyActive || legacyConnected);
    }
    if (!state?.providerKind && walletSessionStateApi?.normalizeAddress(legacyConnected)) {
        state = walletSessionStateApi.setConnection(localStorage, username, {
            address: legacyConnected,
            providerKind: 'metamask',
        });
    }
    if (state?.activeAddress) sessionStorage.setItem('ax_active_wallet_address', state.activeAddress);
    // A persisted address is only a hint. It becomes connected again after the
    // provider confirms its current accounts without requesting permissions.
    sessionStorage.removeItem('ax_base_wallet_address');
}

function selectedEvmWalletAddresses(accounts) {
    return walletSessionStateApi?.uniqueAddresses(accounts) || [];
}

let walletConfigResolve = null;
let currentConfiguringAddress = '';

function openWalletConfigModal(address, resolve) {
    currentConfiguringAddress = address;
    walletConfigResolve = resolve;
    
    const modal = document.getElementById('walletConfigModal');
    const display = document.getElementById('walletConfigAddressDisplay');
    const labelInput = document.getElementById('walletConfigLabelInput');
    const proxyInput = document.getElementById('walletConfigProxyInput');
    const saveBtn = document.getElementById('walletConfigSaveBtn');
    
    if (display) display.textContent = address;
    if (labelInput) labelInput.value = '';
    if (proxyInput) proxyInput.value = '';
    if (saveBtn) saveBtn.disabled = true;
    
    if (modal) showAppModal('walletConfigModal');
}

function validateWalletConfigInputs() {
    const label = document.getElementById('walletConfigLabelInput')?.value.trim() || '';
    const proxy = document.getElementById('walletConfigProxyInput')?.value.trim() || '';
    const saveBtn = document.getElementById('walletConfigSaveBtn');
    if (saveBtn) {
        const isValid = label.length > 0 && proxy.length > 0;
        saveBtn.disabled = !isValid;
    }
}

function cancelWalletConfigModal() {
    const modal = document.getElementById('walletConfigModal');
    if (modal) hideAppModal('walletConfigModal');
    
    const resolve = walletConfigResolve;
    const address = currentConfiguringAddress;
    walletConfigResolve = null;
    currentConfiguringAddress = '';
    if (resolve) resolve({ saved: false, address });
}

async function saveWalletConfigModal() {
    const label = document.getElementById('walletConfigLabelInput')?.value.trim() || '';
    const proxy = document.getElementById('walletConfigProxyInput')?.value.trim() || '';
    const address = currentConfiguringAddress;
    const saveBtn = document.getElementById('walletConfigSaveBtn');

    if (!label || !proxy || !address) return;
    
    if (saveBtn) setButtonLoading(saveBtn, true, 'Сохранение...');

    try {
        const username = getCurrentUsername();
        if (!username) throw new Error('wallet_session_missing');
        const res = await fetch('/api/wallets/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, wallet_address: address, label, proxy })
        });
        const data = await res.json();
        
        if (res.ok) {
            showNotification(translations[currentLang]?.walletAddSuccess || 'Кошелек успешно добавлен');
            const modal = document.getElementById('walletConfigModal');
            if (modal) hideAppModal('walletConfigModal');
            
            const resolve = walletConfigResolve;
            savedWalletAddressesCache.add(address.toLowerCase());
            savedWalletAddressesCacheUpdatedAt = Date.now();
            walletConfigResolve = null;
            currentConfiguringAddress = '';
            if (resolve) resolve({ saved: true, address });
        } else {
            const errText = translateBackendDetail(data.detail);
            showNotification(errText || 'Ошибка подключения кошелька', 'error');
        }
    } catch (e) {
        showNotification('Ошибка подключения кошелька', 'error');
    } finally {
        if (saveBtn) setButtonLoading(saveBtn, false, 'Сохранить');
    }
}

async function saveSelectedWalletAccounts(accounts) {
    const addresses = selectedEvmWalletAddresses(accounts);
    if (!addresses.length) return [];
    const savedAddresses = [];
    for (const address of addresses) {
        const result = await new Promise((resolve) => {
            openWalletConfigModal(address, resolve);
        });
        if (result?.saved) savedAddresses.push(address);
    }
    if (document.getElementById('walletsListContainer')) await loadWalletsFromDB();
    return savedAddresses;
}

function updateBaseWalletConnectionState(address = getConnectedBaseWalletAddress()) {
    const status = document.getElementById('baseWalletConnectionStatus');
    const addressInput = document.getElementById('newWalletAddress');
    const disconnectButton = document.getElementById('disconnectBaseWalletButton');
    if (addressInput && address) addressInput.value = address;
    if (status) {
        const t = translations[currentLang];
        status.innerText = address ? t.walletConnected.replace('{address}', `${address.slice(0, 6)}…${address.slice(-4)}`) : '';
        status.style.display = address ? 'block' : 'none';
    }
    if (disconnectButton) disconnectButton.style.display = address ? 'inline-flex' : 'none';
}

async function disconnectBaseWalletSession() {
    const t = translations[currentLang];
    const providerKind = getWalletSessionPersistenceState().providerKind;
    try {
        if (providerKind === 'walletconnect' && walletConnectProvider?.session) await walletConnectProvider.disconnect();
    } catch (error) {
        console.warn('WalletConnect session disconnect failed', error);
    } finally {
        walletConnectProvider = null;
        clearConnectedWalletState();
        updateBaseWalletConnectionState('');
        if (document.getElementById('walletsListContainer')) loadWalletsFromDB();
        showNotification(t.walletSessionDisconnected);
    }
}

async function connectBaseWallet(requestAccountPicker = true) {
    const t = translations[currentLang];
    const provider = window.ethereum;
    if (!provider || typeof provider.request !== 'function') {
        showNotification(t.walletConnectUnsupported, 'error');
        return;
    }
    try {
        walletConnectionFlowInProgress = true;
        // When the site is already connected, MetaMask otherwise returns the last
        // permitted account without showing a picker. This explicit request lets
        // the user decide which public addresses may be configured in AIRDROP-X.
        if (requestAccountPicker && provider.isMetaMask) {
            try {
                await provider.request({ method: 'wallet_requestPermissions', params: [{ eth_accounts: {} }] });
            } catch (permissionError) {
                const error = new Error('wallet_account_picker_unavailable');
                error.code = permissionError?.code === 4001
                    ? 'wallet_account_picker_cancelled'
                    : 'wallet_account_picker_unavailable';
                throw error;
            }
        }
        const accounts = await provider.request({ method: 'eth_requestAccounts' });
        const selectedAccounts = selectedEvmWalletAddresses(accounts);
        if (!selectedAccounts[0]) {
            const error = new Error('wallet_add_no_account');
            error.code = 'wallet_add_no_account';
            throw error;
        }
        await switchToBaseMainnet(provider);
        const savedAddresses = await saveSelectedWalletAccounts(selectedAccounts);
        const address = savedAddresses[0] || '';
        if (address) {
            setActiveBaseWalletAddress(address);
            const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => BASE_MAINNET_CHAIN_ID);
            setConnectedBaseWalletAddress(address, 'metamask', chainId);
            updateBaseWalletConnectionState(address);
            await refreshActiveWalletConnectionUi();
        } else {
            await reconcileWalletProviderAccounts('metamask', selectedAccounts, { notify: false });
        }
    } catch (error) {
        const message = error?.code === 4001
            ? t.walletConnectRejected
            : error?.code === 'wallet_account_picker_cancelled'
                ? t.walletAccountPickerCancelled
                : error?.code === 'wallet_account_picker_unavailable'
                    ? t.walletAccountPickerUnavailable
            : error?.code === 'wallet_add_no_account'
                ? t.operationWalletNoAccount
                : String(error?.message || '').includes('base_mainnet_not_selected')
                    ? t.walletBaseRequired
                    : t.walletAddConnectionFailed;
        console.warn('Wallet add connection failed', error);
        showNotification(message, 'error');
    } finally {
        walletConnectionFlowInProgress = false;
    }
}

function normalizeEthInput(value) {
    const input = String(value || '').trim();
    if (!/^\d+(?:\.\d{1,18})?$/.test(input)) return null;
    const [wholePart, fractionPart = ''] = input.split('.');
    const whole = wholePart.replace(/^0+(?=\d)/, '') || '0';
    const fraction = fractionPart.replace(/0+$/, '');
    const normalized = fraction ? `${whole}.${fraction}` : whole;
    return normalized === '0' ? null : normalized;
}

function parseTestEthAmount(value) {
    const normalized = normalizeEthInput(value);
    if (!normalized) return null;
    const [whole, fraction = ''] = normalized.split('.');
    const wei = BigInt(whole) * (10n ** 18n) + BigInt((fraction + '0'.repeat(18)).slice(0, 18));
    return wei > 0n ? wei : null;
}

async function switchToBaseSepolia(provider) {
    let chainId = await provider.request({ method: 'eth_chainId' });
    if (chainId === BASE_SEPOLIA_CHAIN_ID) return;
    try {
        await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: BASE_SEPOLIA_CHAIN_ID }] });
    } catch (switchError) {
        if (switchError?.code !== 4902) throw switchError;
        await provider.request({ method: 'wallet_addEthereumChain', params: [BASE_SEPOLIA_CONFIG] });
    }
    chainId = await provider.request({ method: 'eth_chainId' });
    if (chainId !== BASE_SEPOLIA_CHAIN_ID) throw new Error('test_network_not_selected');
}

async function switchToBaseMainnet(provider) {
    let chainId = await provider.request({ method: 'eth_chainId' });
    if (chainId === BASE_MAINNET_CHAIN_ID) return;
    try {
        await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: BASE_MAINNET_CHAIN_ID }] });
    } catch (switchError) {
        if (switchError?.code !== 4902) throw switchError;
        await provider.request({ method: 'wallet_addEthereumChain', params: [BASE_MAINNET_CONFIG] });
    }
    chainId = await provider.request({ method: 'eth_chainId' });
    if (chainId !== BASE_MAINNET_CHAIN_ID) throw new Error('base_mainnet_not_selected');
}

async function switchToUniversalBridgeNetwork(provider, network) {
    const config = UNIVERSAL_BRIDGE_NETWORKS[network];
    if (!provider?.request || !config) throw new Error('universal_bridge_network_unsupported');
    let chainId = await provider.request({ method: 'eth_chainId' });
    if (String(chainId).toLowerCase() === config.chainId.toLowerCase()) return;
    try {
        await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: config.chainId }] });
    } catch (switchError) {
        if (switchError?.code !== 4902) throw switchError;
        await provider.request({ method: 'wallet_addEthereumChain', params: [config] });
    }
    chainId = await provider.request({ method: 'eth_chainId' });
    if (String(chainId).toLowerCase() !== config.chainId.toLowerCase()) {
        throw new Error('universal_bridge_network_not_selected');
    }
}

async function sendBaseSepoliaTestTransfer() {
    const locale = translations[getActiveLang()];
    const provider = window.ethereum;
    const result = document.getElementById('baseSepoliaTestResult');
    const recipient = document.getElementById('baseSepoliaTestRecipient')?.value.trim();
    const amountWei = parseTestEthAmount(document.getElementById('baseSepoliaTestAmount')?.value);
    const button = document.getElementById('baseSepoliaTestButton');
    if (!provider?.request) {
        showNotification(locale.testTransferWalletRequired, 'error');
        return;
    }
    if (!/^0x[0-9a-fA-F]{40}$/.test(recipient) || !amountWei || amountWei > 50000000000000000n) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.testTransferInvalid}</span>`;
        return;
    }
    try {
        setButtonLoading(button, true, locale.testTransferSigning);
        const accounts = await provider.request({ method: 'eth_requestAccounts' });
        if (!Array.isArray(accounts) || !accounts[0]) throw new Error('test_wallet_not_connected');
        await switchToBaseSepolia(provider);
        const hash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: accounts[0], to: recipient, value: `0x${amountWei.toString(16)}` }],
        });
        if (result) {
            const txUrl = `${BASE_SEPOLIA_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(hash)}`;
            result.innerHTML = `<span style="color:#86efac;">${locale.testTransferSent}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${locale.testTransferOpenExplorer}</a>`;
        }
    } catch (error) {
        const isRejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${isRejected ? locale.testTransferRejected : locale.testTransferFailed}</span>`;
    } finally {
        setButtonLoading(button, false, locale.testTransferButton);
    }
}

let savedTransferTemplates = [];

function transferTemplateWalletName(wallet) {
    const locale = translations[getActiveLang()];
    return wallet.label || `${locale.walletDefaultName} ${wallet.id}`;
}

async function loadTransferCenter() {
    const container = document.getElementById('walletTransferCenter');
    if (!container) return;
    const locale = translations[getActiveLang()];
    try {
        const response = await fetch('/api/transfer-center');
        if (response.status === 401) return;
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.wallets) || !Array.isArray(data.templates)) throw new Error('transfer_center_unavailable');
        savedTransferTemplates = data.templates;
        const walletById = new Map(data.wallets.map((wallet) => [wallet.id, wallet]));
        const recipients = data.wallets.length
            ? data.wallets.map((wallet) => `<option value="${Number(wallet.id)}">${escapeHtml(transferTemplateWalletName(wallet))} — ${escapeHtml(`${wallet.address.slice(0, 6)}…${wallet.address.slice(-4)}`)}</option>`).join('')
            : '';
        const createForm = data.wallets.length >= 2
            ? `<div style="display:grid; grid-template-columns:1.1fr 1.6fr .8fr; gap:10px;">
                    <input id="transferTemplateName" maxlength="60" class="auth-input" placeholder="${locale.transferTemplateName}" style="font-size:13px; padding:10px 12px;">
                    <select id="transferTemplateRecipient" class="auth-input" style="font-size:13px; padding:10px 12px;">${recipients}</select>
                    <input id="transferTemplateAmount" inputmode="decimal" class="auth-input" placeholder="0.001" oninput="sanitizeDecimalInput(this, 18)" style="font-size:13px; padding:10px 12px;">
               </div>
               <button type="button" onclick="createTransferTemplate()" class="btn-dark-sm" style="margin-top:10px; width:auto; padding:10px 14px; border-color:#7c3aed;">${locale.transferTemplateSave}</button>`
            : `<div style="color:var(--text-muted); font-size:13px; line-height:1.5;">${locale.transferNeedTwoWallets}</div>`;
        const templates = data.templates.length
            ? data.templates.map((template) => {
                const wallet = walletById.get(template.recipient_wallet_id);
                const recipientName = wallet ? transferTemplateWalletName(wallet) : `${template.recipient_address.slice(0, 6)}…${template.recipient_address.slice(-4)}`;
                return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:12px; padding:13px; display:flex; justify-content:space-between; gap:12px; align-items:center;">
                    <div>
                        <div style="color:#fff; font-weight:700; font-size:13px;">${escapeHtml(template.name)}</div>
                        <div style="color:var(--text-muted); font-size:12px; margin-top:4px;">${escapeHtml(recipientName)} · ${escapeHtml(template.recipient_address.slice(0, 6))}…${escapeHtml(template.recipient_address.slice(-4))}</div>
                    </div>
                    <div style="display:flex; gap:7px; align-items:center; flex-wrap:wrap; justify-content:flex-end;">
                        <input id="transferTemplateAmount-${Number(template.id)}" inputmode="decimal" value="${escapeHtml(template.default_amount)}" oninput="sanitizeDecimalInput(this, 18)" class="auth-input" style="width:88px; padding:7px 9px; font-size:12px;">
                        <button type="button" id="transferTemplateSend-${Number(template.id)}" onclick="sendTransferTemplate(${Number(template.id)})" class="btn-dark-sm" style="padding:7px 10px; border-color:#7c3aed;">${locale.transferSend}</button>
                        <button type="button" onclick="deleteTransferTemplate(${Number(template.id)})" class="btn-dark-sm" style="padding:7px 10px; color:#fca5a5;">${locale.transferDelete}</button>
                    </div>
                </div>`;
            }).join('')
            : `<div style="color:var(--text-muted); font-size:13px;">${locale.transferNoTemplates}</div>`;
        const history = Array.isArray(data.history) && data.history.length
            ? data.history.map((record) => `<div style="display:flex; justify-content:space-between; gap:10px; font-size:12px; padding:9px 0; border-top:1px solid var(--border-color);">
                    <span style="color:var(--text-muted);">${escapeHtml(record.amount)} ETH · ${escapeHtml(`${record.to_address.slice(0, 6)}…${record.to_address.slice(-4)}`)}</span>
                    <a href="${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(record.tx_hash)}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd; text-decoration:none;">${locale.transferOpenTx}</a>
                </div>`).join('')
            : `<div style="color:var(--text-muted); font-size:12px;">${locale.transferNoHistory}</div>`;
        container.innerHTML = `<div style="margin-bottom:14px;">${createForm}</div><div style="display:flex; flex-direction:column; gap:9px;">${templates}</div><div style="margin-top:16px; color:#fff; font-weight:700; font-size:13px;">${locale.transferHistoryTitle}</div><div>${history}</div><div id="transferCenterResult" style="margin-top:10px; font-size:12px;"></div>`;
    } catch (error) {
        container.innerHTML = `<div style="color:#fca5a5; font-size:13px;">${locale.transferLoadError}</div>`;
    }
}

async function createTransferTemplate() {
    const locale = translations[getActiveLang()];
    const payload = {
        name: document.getElementById('transferTemplateName')?.value || '',
        recipient_wallet_id: Number(document.getElementById('transferTemplateRecipient')?.value),
        default_amount: document.getElementById('transferTemplateAmount')?.value || '',
    };
    try {
        const response = await fetch('/api/transfer-templates', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'transfer_template_failed');
        showNotification(locale.transferTemplateSaved, 'success');
        await loadTransferCenter();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || locale.transferTemplateError, 'error');
    }
}

async function deleteTransferTemplate(templateId) {
    const locale = translations[getActiveLang()];
    if (!window.confirm(locale.transferDeleteConfirm)) return;
    try {
        const response = await fetch(`/api/transfer-templates/${templateId}`, { method: 'DELETE' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'transfer_template_failed');
        await loadTransferCenter();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || locale.transferTemplateError, 'error');
    }
}

async function sendTransferTemplate(templateId) {
    const locale = translations[getActiveLang()];
    const template = savedTransferTemplates.find((item) => item.id === templateId);
    const amount = document.getElementById(`transferTemplateAmount-${templateId}`)?.value || '';
    const amountWei = parseTestEthAmount(amount);
    const result = document.getElementById('transferCenterResult');
    const button = document.getElementById(`transferTemplateSend-${templateId}`);
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    if (!template || !amountWei || !provider?.request) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.transferInvalid}</span>`;
        return;
    }
    try {
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts[0]) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const fromAddress = accounts?.[0];
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '') || fromAddress.toLowerCase() === template.recipient_address.toLowerCase()) {
            throw new Error('invalid_transfer_wallet');
        }
        if (!window.confirm(locale.transferConfirm.replace('{amount}', amount).replace('{recipient}', `${template.recipient_address.slice(0, 6)}…${template.recipient_address.slice(-4)}`))) return;
        setButtonLoading(button, true, locale.transferSigning);
        await switchToBaseMainnet(provider);
        const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: fromAddress, to: template.recipient_address, value: `0x${amountWei.toString(16)}` }],
        });
        const recordResponse = await fetch('/api/transfer-records', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ template_id: template.id, from_address: fromAddress, to_address: template.recipient_address, amount, tx_hash: txHash }),
        });
        const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(txHash)}`;
        if (result) result.innerHTML = `<span style="color:#86efac;">${locale.transferSubmitted}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${locale.transferOpenTx}</a>`;
        if (recordResponse.ok) await loadTransferCenter();
    } catch (error) {
        const isRejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${isRejected ? locale.transferRejected : locale.transferFailed}</span>`;
    } finally {
        setButtonLoading(button, false, locale.transferSend);
    }
}

function getDirectTransferEthAsset() {
    const assets = Array.isArray(directTransferBalanceData?.visible_assets)
        ? directTransferBalanceData.visible_assets
        : [];
    return assets.find((asset) => asset.symbol === 'ETH') || null;
}

function updateDirectTransferAmount() {
    const availability = document.getElementById('directTransferAvailability');
    const amountUsd = document.getElementById('directTransferUsd');
    const input = document.getElementById('directTransferAmount');
    const locale = translations[getActiveLang()];
    const asset = getDirectTransferEthAsset();
    if (!availability || !amountUsd || !input || !asset) return false;
    const amount = Number(input.value);
    const available = Number(asset.available_to_send);
    if (!Number.isFinite(amount) || amount <= 0) {
        amountUsd.textContent = '';
        availability.textContent = locale.directTransferAvailable
            .replace('{amount}', asset.available_to_send)
            .replace('{reserve}', asset.gas_reserve || '0');
        availability.style.color = '#bfdbfe';
        return false;
    }
    amountUsd.textContent = locale.directTransferUsd.replace('{usd}', (amount * Number(asset.unit_price_usd)).toLocaleString(undefined, {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
    }));
    if (amount > available) {
        availability.textContent = locale.directTransferExceeds.replace('{amount}', asset.available_to_send);
        availability.style.color = '#fca5a5';
        return false;
    }
    availability.textContent = locale.directTransferAvailable
        .replace('{amount}', asset.available_to_send)
        .replace('{reserve}', asset.gas_reserve || '0');
    availability.style.color = '#86efac';
    return true;
}

function useDirectTransferMax() {
    const input = document.getElementById('directTransferAmount');
    const asset = getDirectTransferEthAsset();
    if (!input || !asset) return;
    input.value = asset.available_to_send;
    updateDirectTransferAmount();
}

async function loadDirectTransferPanel() {
    const container = document.getElementById('directTransferPanel');
    if (!container) return;
    const locale = translations[getActiveLang()];
    const activeAddress = getActiveBaseWalletAddress();
    if (!/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        container.textContent = locale.directTransferWalletRequired;
        container.style.color = '#fbbf24';
        return;
    }
    try {
        const transferResponse = await fetch('/api/transfer-center');
        const transferData = await transferResponse.json();
        if (!transferResponse.ok || !Array.isArray(transferData.wallets)) throw new Error('transfer_center_unavailable');
        const sender = transferData.wallets.find((wallet) => wallet.address?.toLowerCase() === activeAddress.toLowerCase());
        const recipients = transferData.wallets.filter((wallet) => wallet.address?.toLowerCase() !== activeAddress.toLowerCase());
        if (!sender || !recipients.length) {
            container.textContent = locale.directTransferNeedRecipient;
            container.style.color = 'var(--text-muted)';
            return;
        }
        const balanceResponse = await fetch(`/api/wallets/${sender.id}/network-balance/Base`);
        const balanceData = await balanceResponse.json();
        if (!balanceResponse.ok) throw new Error('base_balance_unavailable');
        const ethAsset = (balanceData.visible_assets || []).find((asset) => asset.symbol === 'ETH');
        if (!ethAsset || Number(ethAsset.available_to_send) <= 0) {
            container.textContent = locale.directTransferInsufficientEth;
            container.style.color = '#fbbf24';
            return;
        }
        directTransferWallets = transferData.wallets;
        directTransferBalanceData = balanceData;
        const recipientOptions = recipients.map((wallet) => `<option value="${Number(wallet.id)}">${escapeHtml(transferTemplateWalletName(wallet))} · ${escapeHtml(wallet.address.slice(0, 6))}…${escapeHtml(wallet.address.slice(-4))}</option>`).join('');
        const history = Array.isArray(transferData.history) && transferData.history.length
            ? transferData.history.slice(0, 5).map((record) => `<div style="display:flex; justify-content:space-between; gap:10px; font-size:12px; padding:8px 0; border-top:1px solid var(--border-color);"><span style="color:var(--text-muted);">${escapeHtml(record.amount)} ETH → ${escapeHtml(`${record.to_address.slice(0, 6)}…${record.to_address.slice(-4)}`)}</span><a href="${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(record.tx_hash)}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd; text-decoration:none;">${locale.directTransferOpenTx}</a></div>`).join('')
            : `<div style="color:var(--text-muted); font-size:12px;">${locale.directTransferNoHistory}</div>`;
        container.style.color = '';
        container.innerHTML = `
            <div style="display:grid; grid-template-columns:1.4fr 1fr; gap:10px;">
                <label style="color:var(--text-muted); font-size:12px;">${locale.directTransferRecipient}<select id="directTransferRecipient" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">${recipientOptions}</select></label>
                <label style="color:var(--text-muted); font-size:12px;">${locale.directTransferAmount}<input id="directTransferAmount" inputmode="decimal" placeholder="0.001" oninput="sanitizeDecimalInput(this, 18); updateDirectTransferAmount()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;"><div id="directTransferUsd" style="color:#c4b5fd; font-size:14px; font-weight:700; margin-top:6px;"></div></label>
            </div>
            <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:8px;">
                <div id="directTransferAvailability" style="font-size:12px;"></div>
                <button type="button" onclick="useDirectTransferMax()" class="btn-dark-sm" style="padding:6px 10px; font-size:11px; white-space:nowrap;">${locale.directTransferMax}</button>
            </div>
            <button type="button" id="directTransferSendButton" onclick="sendDirectBaseTransfer()" class="btn-purple-lg" style="font-size:13px; padding:11px 16px; width:auto; margin-top:14px;">${locale.directTransferReview}</button>
            <div id="directTransferResult" style="font-size:12px; line-height:1.5; margin-top:10px;"></div>
            <details style="border-top:1px solid var(--border-color); margin-top:16px; padding-top:13px;"><summary style="color:var(--text-muted); cursor:pointer; font-size:12px;">${locale.directTransferHistory}</summary><div style="margin-top:9px;">${history}</div></details>`;
        updateDirectTransferAmount();
    } catch (_) {
        container.textContent = locale.directTransferLoadError;
        container.style.color = '#fca5a5';
    }
}

async function sendDirectBaseTransfer() {
    const locale = translations[getActiveLang()];
    const recipientId = Number(document.getElementById('directTransferRecipient')?.value);
    const recipient = directTransferWallets.find((wallet) => wallet.id === recipientId);
    const amount = document.getElementById('directTransferAmount')?.value.trim() || '';
    const amountWei = parseTestEthAmount(amount);
    const result = document.getElementById('directTransferResult');
    const button = document.getElementById('directTransferSendButton');
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    if (!recipient || !amountWei || !provider?.request || !updateDirectTransferAmount()) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.directTransferInvalid}</span>`;
        return;
    }
    try {
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts[0]) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const fromAddress = accounts?.[0];
        const activeAddress = getActiveBaseWalletAddress();
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '') || fromAddress.toLowerCase() !== activeAddress.toLowerCase() || fromAddress.toLowerCase() === recipient.address.toLowerCase()) {
            throw new Error('invalid_transfer_wallet');
        }
        if (!await openBaseTransferConfirmation(amount, recipient.address, transferTemplateWalletName(recipient))) return;
        setButtonLoading(button, true, locale.directTransferSigning);
        await switchToBaseMainnet(provider);
        const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: fromAddress, to: recipient.address, value: `0x${amountWei.toString(16)}` }],
        });
        try {
            await fetch('/api/transfer-records/direct', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ recipient_wallet_id: recipient.id, from_address: fromAddress, to_address: recipient.address, amount, tx_hash: txHash }),
            });
        } catch (_) {
            // The wallet submitted the transaction; history can be refreshed later.
        }
        const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(txHash)}`;
        if (result) result.innerHTML = `<span style="color:#86efac;">${locale.directTransferSubmitted}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${locale.directTransferOpenTx}</a>`;
    } catch (error) {
        const isRejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${isRejected ? locale.directTransferRejected : locale.directTransferFailed}</span>`;
    } finally {
        setButtonLoading(button, false, locale.directTransferReview);
    }
}

let activeBaseSwapQuote = null;
let activeAaveSupplyQuote = null;
let activeAaveWithdrawQuote = null;

function setAaveQuoteExpiry(quote) {
    if (!quote || typeof quote !== 'object') return quote;
    quote.expires_at = Date.now() + Math.max(1, Number(quote.expires_in || 0)) * 1000;
    return quote;
}

function isAaveQuoteFresh(quote) {
    return Boolean(quote && Number(quote.expires_at || 0) > Date.now());
}

function formatUsdcAmount(rawAmount) {
    try {
        const raw = BigInt(String(rawAmount || '0'));
        const whole = raw / 1000000n;
        const fraction = (raw % 1000000n).toString().padStart(6, '0').slice(0, 4).replace(/0+$/, '');
        return `${whole.toString()}${fraction ? `.${fraction}` : ''}`;
    } catch (_) {
        return '';
    }
}

async function loadBaseSwapHistory() {
    const locale = translations[getActiveLang()];
    const container = document.getElementById('baseSwapHistory');
    if (!container) return;
    try {
        const response = await fetch('/api/base-swap/history');
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.records)) throw new Error('base_swap_history_unavailable');
        if (!data.records.length) {
            container.innerHTML = `<div style="color:var(--text-muted); font-size:12px;">${locale.baseSwapNoHistory}</div>`;
            return;
        }
        container.innerHTML = data.records.map((record) => {
            const output = formatUsdcAmount(record.amount_out);
            const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(record.tx_hash)}`;
            const date = new Date(Number(record.created_at) * 1000).toLocaleString();
            return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:9px; padding:9px 10px; display:flex; justify-content:space-between; gap:10px; align-items:center; margin-top:7px;"><div><div style="color:#fff; font-size:12px;">${escapeHtml(record.amount_in)} ETH → ${escapeHtml(output || '—')} USDC</div><div style="color:var(--text-muted); font-size:11px; margin-top:3px;">${escapeHtml(date)} • ${locale.baseSwapStatusSubmitted}</div></div><a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd; font-size:12px; white-space:nowrap;">${locale.baseSwapOpenTx}</a></div>`;
        }).join('');
    } catch (_) {
        container.innerHTML = `<div style="color:#fca5a5; font-size:12px;">${locale.baseSwapHistoryUnavailable}</div>`;
    }
}

async function requestBaseSwapQuote() {
    const locale = translations[getActiveLang()];
    const amount = normalizeEthInput(document.getElementById('operationAmount')?.value || document.getElementById('baseSwapAmount')?.value);
    const requestedSlippage = Number(document.getElementById('dexSlippage')?.value || 0.5);
    const slippage = Number.isFinite(requestedSlippage) && requestedSlippage >= 0.1 && requestedSlippage <= 1
        ? requestedSlippage
        : 0.5;
    const connectedAddress = getActiveBaseWalletAddress();
    const result = document.getElementById('baseSwapResult');
    const button = document.getElementById('baseSwapQuoteButton');
    if (!validateOperationAmount()) return;
    if (!/^0x[0-9a-fA-F]{40}$/.test(connectedAddress)) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.baseSwapWalletRequired}</span>`;
        return;
    }
    if (!amount || !parseTestEthAmount(amount)) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.baseSwapInvalidAmount}</span>`;
        return;
    }
    const connectionState = await getActiveWalletSessionState(connectedAddress);
    if (!connectionState.matches) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(activeWalletConnectionMessage(connectionState, locale, connectedAddress))}</span>`;
        return;
    }
    try {
        setButtonLoading(button, true, locale.baseSwapQuoting);
        const response = await fetch('/api/base-swap/quote', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ wallet_address: connectedAddress, amount, slippage }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'base_swap_quote_failed');
        activeBaseSwapQuote = data;
        const amountOut = formatUsdcAmount(data.amount_out);
        if (result) {
            result.innerHTML = `<div style="color:#86efac; font-weight:600;">${locale.baseSwapQuoteReady.replace('{amount}', amountOut || '—')}</div><div style="color:var(--text-muted); margin-top:4px;">${locale.baseSwapQuoteExpiry.replace('{seconds}', data.expires_in)}</div><button type="button" id="baseSwapSubmitButton" onclick="submitBaseSwap()" class="btn-purple-lg" style="font-size:13px; padding:10px 14px; width:auto; margin-top:10px;">${locale.baseSwapReview}</button>`;
        }
    } catch (error) {
        activeBaseSwapQuote = null;
        const errorMessage = String(error?.message || '');
        const displayMessage = errorMessage.includes('not configured')
            ? locale.baseSwapNotConfigured
            : operationErrorMessage(error, locale, locale.baseSwapQuoteError);
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(displayMessage)}</span>`;
    } finally {
        setButtonLoading(button, false, locale.baseSwapGetQuote);
    }
}

async function submitBaseSwap() {
    const locale = translations[getActiveLang()];
    const quote = activeBaseSwapQuote;
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    const result = document.getElementById('baseSwapResult');
    const button = document.getElementById('baseSwapSubmitButton');
    if (!quote || !provider?.request) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.baseSwapExpired}</span>`;
        return;
    }
    try {
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts[0]) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const fromAddress = accounts?.[0];
        const connectedAddress = getActiveBaseWalletAddress();
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '') || fromAddress.toLowerCase() !== connectedAddress.toLowerCase()) {
            if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.baseSwapActiveWalletMismatch}</span>`;
            return;
        }
        const expectedOutput = formatUsdcAmount(quote.amount_out) || '—';
        if (!await openBaseSwapConfirmation(quote.amount_in, expectedOutput)) return;
        setButtonLoading(button, true, locale.baseSwapPreparing);
        const response = await fetch('/api/base-swap/build', {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ quote_id: quote.quote_id }),
        });
        const data = await response.json();
        if (!response.ok || !data.transaction) throw new Error(data.detail || 'base_swap_build_failed');
        const tx = data.transaction;
        if (tx.chain_id !== 8453 || tx.from.toLowerCase() !== fromAddress.toLowerCase() || !/^0x[0-9a-fA-F]{40}$/.test(tx.to) || !/^0x[0-9a-fA-F]+$/.test(tx.data) || !/^(?:0|[1-9]\d*|0x[0-9a-fA-F]+)$/.test(String(tx.value))) {
            throw new Error('base_swap_transaction_invalid');
        }
        await switchToBaseMainnet(provider);
        setButtonLoading(button, true, locale.baseSwapSigning);
        const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: fromAddress, to: tx.to, data: tx.data, value: `0x${BigInt(tx.value).toString(16)}` }],
        });
        activeBaseSwapQuote = null;
        if (data.submission_id) {
            try {
                await fetch('/api/base-swap/submissions', {
                    method: 'POST', headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ submission_id: data.submission_id, tx_hash: txHash }),
                });
                await loadBaseSwapHistory();
            } catch (_) {
                // The wallet already submitted the transaction; history can be refreshed later.
            }
        }
        const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(txHash)}`;
        if (result) result.innerHTML = `<span style="color:#86efac;">${locale.baseSwapSubmitted}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${locale.baseSwapOpenTx}</a>`;
    } catch (error) {
        const rejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        const errorMessage = String(error?.message || '');
        const displayMessage = errorMessage.includes('Base Swap quote expired')
            ? locale.baseSwapExpired
            : operationErrorMessage(error, locale, locale.baseSwapFailed);
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(rejected ? locale.baseSwapRejected : displayMessage)}</span>`;
    } finally {
        setButtonLoading(button, false, locale.baseSwapReview);
    }
}

function updateSavedWalletAddressesCache(wallets) {
    savedWalletAddressesCache = new Set((Array.isArray(wallets) ? wallets : [])
        .map((wallet) => String(wallet?.wallet_address || '').toLowerCase())
        .filter((address) => /^0x[0-9a-f]{40}$/.test(address)));
    savedWalletAddressesCacheOwner = getCurrentUsername().toLowerCase();
    savedWalletAddressesCacheUpdatedAt = Date.now();
}

async function getSavedWalletAddressSet({ force = false } = {}) {
    const username = getCurrentUsername();
    if (!username) return new Set();
    const owner = username.toLowerCase();
    if (!force && savedWalletAddressesCacheOwner === owner && Date.now() - savedWalletAddressesCacheUpdatedAt < 15_000) {
        return new Set(savedWalletAddressesCache);
    }
    try {
        const response = await fetch(`/api/wallets/${encodeURIComponent(username)}`);
        const data = await response.json().catch(() => ({}));
        if (!response.ok || !Array.isArray(data.wallets)) return null;
        updateSavedWalletAddressesCache(data.wallets);
        return new Set(savedWalletAddressesCache);
    } catch (_) {
        return null;
    }
}

function walletProviderForKind(providerKind) {
    if (providerKind === 'walletconnect') return walletConnectProvider?.session ? walletConnectProvider : null;
    if (providerKind === 'metamask') return window.ethereum?.request ? window.ethereum : null;
    return null;
}

function walletNetworkLabel(chainId) {
    const normalized = walletSessionStateApi?.normalizeChainId(chainId) || String(chainId || '');
    const match = Object.values(UNIVERSAL_BRIDGE_NETWORKS).find((network) => network.chainId.toLowerCase() === normalized.toLowerCase());
    return match?.chainName || normalized || '—';
}

async function reconcileWalletProviderAccounts(providerKind, accounts, { notify = false, chainId = '' } = {}) {
    if (!['metamask', 'walletconnect'].includes(providerKind)) return { matches: false, reason: 'provider-unavailable' };
    if (!isLoggedIn || !getCurrentUsername()) return { matches: false, reason: 'session-unavailable' };
    const locale = translations[getActiveLang()];
    const activeAddress = getActiveBaseWalletAddress();
    const savedAddresses = await getSavedWalletAddressSet();
    const accountState = savedAddresses
        ? walletSessionStateApi?.reconcileSavedAccounts(accounts, activeAddress, Array.from(savedAddresses))
        : walletSessionStateApi?.resolveAccounts(accounts, activeAddress);
    const resolvedState = accountState || { matches: false, reason: 'no-account', accounts: [] };

    if (!activeAddress) {
        rememberWalletProviderKind(providerKind, chainId);
        updateBaseWalletConnectionState('');
        if (notify && !walletConnectionFlowInProgress && resolvedState.accounts?.length) {
            showNotification(locale.walletSessionSelectSavedWallet, 'error');
        }
        return { ...resolvedState, reason: 'missing-active-address' };
    }

    if (resolvedState.reason === 'unsaved-active-address') {
        clearActiveWalletState();
        rememberWalletProviderKind(providerKind, chainId);
        updateBaseWalletConnectionState('');
        if (notify && !walletConnectionFlowInProgress) showNotification(locale.walletSessionUnsavedAccount, 'error');
        await refreshActiveWalletConnectionUi();
        return { matches: false, reason: 'unsaved-active-address', accounts: resolvedState.accounts || [] };
    }

    if (resolvedState.matches) {
        setConnectedBaseWalletAddress(resolvedState.address, providerKind, chainId);
        updateBaseWalletConnectionState(resolvedState.address);
        await refreshActiveWalletConnectionUi();
        if (notify && !walletConnectionFlowInProgress) showNotification(locale.walletSessionAccountRestored, 'success');
        return { ...resolvedState, providerKind };
    }

    rememberWalletProviderKind(providerKind, chainId);
    updateBaseWalletConnectionState('');
    await refreshActiveWalletConnectionUi();
    if (notify && !walletConnectionFlowInProgress) {
        const message = resolvedState.reason === 'no-account'
            ? locale.operationWalletNoAccount
            : locale.operationWalletWrongAccount.replace('{address}', `${activeAddress.slice(0, 6)}…${activeAddress.slice(-4)}`);
        showNotification(message, 'error');
    }
    return { ...resolvedState, providerKind };
}

async function handleWalletProviderChainChanged(providerKind, chainId) {
    if (!isLoggedIn || !getCurrentUsername()) return;
    const state = getWalletSessionPersistenceState();
    if (state.providerKind && state.providerKind !== providerKind) return;
    const normalizedChainId = walletSessionStateApi?.normalizeChainId(chainId) || '';
    if (state.connectedAddress) {
        setConnectedBaseWalletAddress(state.connectedAddress, providerKind, normalizedChainId);
    } else {
        rememberWalletProviderKind(providerKind, normalizedChainId);
    }
    await refreshActiveWalletConnectionUi();
    if (!walletConnectionFlowInProgress && getActiveBaseWalletAddress()) {
        showNotification(translations[getActiveLang()].walletSessionNetworkChanged.replace('{network}', walletNetworkLabel(normalizedChainId)));
    }
}

function bindInjectedWalletProviderListeners() {
    const provider = window.ethereum;
    if (!provider?.on || injectedWalletListenersProvider === provider) return;
    injectedWalletListenersProvider = provider;
    provider.on('accountsChanged', (accounts) => {
        void reconcileWalletProviderAccounts('metamask', accounts, { notify: true });
    });
    provider.on('chainChanged', (chainId) => {
        void handleWalletProviderChainChanged('metamask', chainId);
    });
    provider.on('disconnect', () => {
        if (!isLoggedIn || !getCurrentUsername()) return;
        if (getWalletSessionPersistenceState().providerKind !== 'metamask') return;
        clearConnectedWalletState();
        updateBaseWalletConnectionState('');
        void refreshActiveWalletConnectionUi();
        if (!walletConnectionFlowInProgress) showNotification(translations[getActiveLang()].walletSessionDisconnected);
    });
}

function bindWalletConnectProviderListeners(provider) {
    if (!provider?.on || walletConnectListenersProvider === provider) return;
    walletConnectListenersProvider = provider;
    provider.on('accountsChanged', (accounts) => {
        void reconcileWalletProviderAccounts('walletconnect', accounts, { notify: true });
    });
    provider.on('chainChanged', (chainId) => {
        void handleWalletProviderChainChanged('walletconnect', chainId);
    });
    provider.on('display_uri', openWalletConnectQr);
    provider.on('connect', closeWalletConnectModal);
    provider.on('disconnect', () => {
        if (walletConnectProvider === provider) walletConnectProvider = null;
        walletConnectListenersProvider = null;
        if (!isLoggedIn || !getCurrentUsername()) return;
        if (getWalletSessionPersistenceState().providerKind === 'walletconnect') {
            clearConnectedWalletState();
            updateBaseWalletConnectionState('');
            void refreshActiveWalletConnectionUi();
            if (!walletConnectionFlowInProgress) showNotification(translations[getActiveLang()].walletSessionDisconnected);
        }
    });
}

async function initializeWalletSessionLifecycle() {
    restoreWalletStateMirrors();
    bindInjectedWalletProviderListeners();
    const state = getWalletSessionPersistenceState();
    try {
        if (state.providerKind === 'walletconnect') {
            const provider = await getWalletConnectProvider();
            if (!provider?.session) {
                clearConnectedWalletState();
                updateBaseWalletConnectionState('');
                return;
            }
            const accounts = await provider.request({ method: 'eth_accounts' });
            const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => state.chainId);
            await reconcileWalletProviderAccounts('walletconnect', accounts, { notify: false, chainId });
            return;
        }
        const provider = window.ethereum;
        let injectedState = { matches: false, reason: 'provider-unavailable' };
        if (provider?.request) {
            const accounts = await provider.request({ method: 'eth_accounts' });
            const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => state.chainId);
            injectedState = await reconcileWalletProviderAccounts('metamask', accounts, { notify: false, chainId });
            if (injectedState.matches) return;
        }
        // Older versions did not persist the provider kind. Initialising the SDK
        // does not request accounts or show a QR code; it only exposes an already
        // approved WalletConnect session, if one exists.
        if (state.activeAddress) {
            const provider = await getWalletConnectProvider();
            if (provider?.session) {
                const accounts = await provider.request({ method: 'eth_accounts' });
                const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => state.chainId);
                await reconcileWalletProviderAccounts('walletconnect', accounts, { notify: false, chainId });
            }
        }
    } catch (error) {
        console.warn('Wallet session restore failed', error);
        clearConnectedWalletState();
        updateBaseWalletConnectionState('');
    }
}

async function getWalletConnectProvider() {
    if (walletConnectProvider) {
        bindWalletConnectProviderListeners(walletConnectProvider);
        return walletConnectProvider;
    }
    const configResponse = await fetch('/api/walletconnect/config');
    const config = await configResponse.json();
    if (!configResponse.ok || !config.project_id) throw new Error('walletconnect_config_missing');

    if (!walletConnectModulePromise) {
        walletConnectModulePromise = import(WALLETCONNECT_PROVIDER_MODULE_URL);
    }
    const walletConnectModule = await walletConnectModulePromise;
    const EthereumProvider = walletConnectModule.EthereumProvider || walletConnectModule.default?.EthereumProvider || walletConnectModule.default;
    if (!EthereumProvider?.init) throw new Error('walletconnect_provider_unavailable');

    walletConnectProvider = await EthereumProvider.init({
        projectId: config.project_id,
        showQrModal: false,
        optionalChains: Object.values(UNIVERSAL_BRIDGE_NETWORKS).map((network) => parseInt(network.chainId, 16)),
        optionalMethods: ['eth_requestAccounts', 'eth_accounts', 'eth_chainId', 'eth_sendTransaction', 'wallet_switchEthereumChain', 'wallet_addEthereumChain', 'eth_call', 'eth_getTransactionReceipt'],
        optionalEvents: ['accountsChanged', 'chainChanged'],
        rpcMap: Object.fromEntries(Object.values(UNIVERSAL_BRIDGE_NETWORKS).map((network) => [parseInt(network.chainId, 16), network.rpcUrls[0]])),
        metadata: {
            name: 'AIRDROP-X',
            description: 'Non-custodial Base wallet connection',
            url: window.location.origin,
            icons: []
        }
    });
    bindWalletConnectProviderListeners(walletConnectProvider);
    return walletConnectProvider;
}

async function connectWalletConnectBase() {
    const locale = translations[getActiveLang()];
    try {
        walletConnectionFlowInProgress = true;
        showNotification(locale.walletConnectLoading);
        const provider = await getWalletConnectProvider();
        const accounts = await provider.enable();
        let chainId = await provider.request({ method: 'eth_chainId' });
        if (chainId !== BASE_MAINNET_CHAIN_ID) {
            await provider.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: BASE_MAINNET_CHAIN_ID }] });
            chainId = await provider.request({ method: 'eth_chainId' }).catch(() => BASE_MAINNET_CHAIN_ID);
        }
        const selectedAccounts = selectedEvmWalletAddresses(accounts);
        const address = selectedAccounts[0] || '';
        if (!address) throw new Error('walletconnect_no_address');
        const savedAddresses = await saveSelectedWalletAccounts(selectedAccounts);
        const savedAddress = savedAddresses[0] || '';
        if (savedAddress) {
            setActiveBaseWalletAddress(savedAddress);
            setConnectedBaseWalletAddress(savedAddress, 'walletconnect', chainId);
            updateBaseWalletConnectionState(savedAddress);
            await refreshActiveWalletConnectionUi();
        } else {
            await reconcileWalletProviderAccounts('walletconnect', selectedAccounts, { notify: false, chainId });
        }
    } catch (error) {
        closeWalletConnectModal();
        console.error('WalletConnect connection failed', error);
        const reason = String(error?.message || '').toLowerCase();
        const message = error?.message === 'walletconnect_config_missing'
            ? locale.walletConnectConfigMissing
            : reason.includes('project') || reason.includes('origin') || reason.includes('allowlist')
                ? locale.walletConnectProjectError
                : reason.includes('relay') || reason.includes('websocket') || reason.includes('network')
                    ? locale.walletConnectNetworkError
                    : locale.walletConnectRejected;
        showNotification(message, 'error');
    } finally {
        walletConnectionFlowInProgress = false;
    }
}

async function getActiveWalletSessionState(address = getActiveBaseWalletAddress()) {
    const expectedAddress = String(address || '').trim().toLowerCase();
    if (!/^0x[0-9a-f]{40}$/.test(expectedAddress)) return { matches: false, reason: 'missing-active-address' };
    const persistenceState = getWalletSessionPersistenceState();
    let providerKind = persistenceState.providerKind;
    let provider = walletProviderForKind(providerKind);
    if (providerKind === 'walletconnect' && !provider) {
        try {
            const restoredProvider = await getWalletConnectProvider();
            provider = restoredProvider?.session ? restoredProvider : null;
        } catch (_) {
            provider = null;
        }
    }
    if (!provider) {
        providerKind = walletConnectProvider?.session ? 'walletconnect' : 'metamask';
        provider = walletProviderForKind(providerKind);
    }
    if (!provider || typeof provider.request !== 'function') return { matches: false, reason: 'provider-unavailable' };
    try {
        const accounts = await provider.request({ method: 'eth_accounts' });
        const accountState = walletSessionStateApi?.resolveAccounts(accounts, expectedAddress) || { matches: false, reason: 'no-account' };
        return { ...accountState, providerKind };
    } catch (_) {
        return { matches: false, reason: 'request-failed' };
    }
}

async function switchToOperationNetwork(provider, network = 'Base') {
    // DEX and lending operate on Base; Bridges must connect on the selected
    // source network so the wallet is ready for the final, user-confirmed step.
    if (network === 'Base') return switchToBaseMainnet(provider);
    return switchToUniversalBridgeNetwork(provider, network);
}

async function activeWalletSessionMatches(address = getActiveBaseWalletAddress()) {
    return (await getActiveWalletSessionState(address)).matches;
}

function activeWalletConnectionMessage(state, locale, address = getActiveBaseWalletAddress()) {
    const shortAddress = /^0x[0-9a-fA-F]{40}$/.test(address || '')
        ? `${address.slice(0, 6)}…${address.slice(-4)}`
        : '';
    if (state?.reason === 'different-account') {
        return locale.operationWalletWrongAccount.replace('{address}', shortAddress);
    }
    if (state?.reason === 'no-account') return locale.operationWalletNoAccount;
    return locale.baseSwapActiveWalletMismatch;
}

async function refreshActiveWalletConnectionUi() {
    updateBaseWalletConnectionState();
    if (document.getElementById('walletsListContainer')) await loadWalletsFromDB();
    await loadOperationBuilderWalletStatus();
    await loadLendingWalletConnectionStatus();
}

async function connectActiveWalletForActions(button, network = 'Base') {
    const locale = translations[getActiveLang()];
    const expectedAddress = getActiveBaseWalletAddress();
    const provider = window.ethereum;
    if (!/^0x[0-9a-fA-F]{40}$/.test(expectedAddress)) {
        showNotification(locale.baseSwapWalletRequired, 'error');
        return;
    }
    if (!provider || typeof provider.request !== 'function') {
        showNotification(locale.walletConnectUnsupported, 'error');
        return;
    }
    try {
        walletConnectionFlowInProgress = true;
        if (button) setButtonLoading(button, true, locale.operationWalletConnecting);
        if (provider.isMetaMask) {
            try {
                await provider.request({ method: 'wallet_requestPermissions', params: [{ eth_accounts: {} }] });
            } catch (permissionError) {
                if (permissionError?.code === 4001) throw permissionError;
                if (permissionError?.code !== -32601) throw permissionError;
            }
        }
        const accounts = await provider.request({ method: 'eth_requestAccounts' });
        const selectedAccounts = selectedEvmWalletAddresses(accounts);
        if (!selectedAccounts.length) {
            const error = new Error('active_wallet_no_account');
            error.code = 'active_wallet_no_account';
            throw error;
        }
        const selectedAddress = selectedAccounts.find((address) => address.toLowerCase() === expectedAddress.toLowerCase());
        if (!selectedAddress) {
            const error = new Error('active_wallet_wrong_account');
            error.code = 'active_wallet_wrong_account';
            throw error;
        }
        await switchToOperationNetwork(provider, network);
        const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => '');
        setConnectedBaseWalletAddress(selectedAddress, 'metamask', chainId);
        updateBaseWalletConnectionState(selectedAddress);
        await refreshActiveWalletConnectionUi();
        showNotification(locale.operationWalletConnected);
    } catch (error) {
        const message = error?.code === 4001
            ? locale.walletConnectRejected
            : error?.code === 'active_wallet_no_account'
                ? locale.operationWalletNoAccount
                : error?.code === 'active_wallet_wrong_account'
                    ? locale.operationWalletWrongAccount.replace('{address}', `${expectedAddress.slice(0, 6)}…${expectedAddress.slice(-4)}`)
                    : /(?:base_mainnet_not_selected|universal_bridge_network_not_selected)/.test(String(error?.message || ''))
                        ? locale.operationWalletNetworkRequired
                        : locale.operationWalletConnectionFailed;
        console.warn('Active wallet connection failed', error);
        showNotification(message, 'error');
    } finally {
        walletConnectionFlowInProgress = false;
        if (button) setButtonLoading(button, false, locale.operationConnectActiveWallet);
    }
}

async function connectSavedWalletForActions(walletAddress, button) {
    if (!/^0x[0-9a-fA-F]{40}$/.test(walletAddress || '')) return;
    // This only chooses an already saved public address for the current session.
    // It never creates another wallet record or imports a private key.
    const savedAddresses = await getSavedWalletAddressSet({ force: true });
    if (!savedAddresses?.has(walletAddress.toLowerCase())) {
        showNotification(translations[getActiveLang()].walletSessionUnsavedAccount, 'error');
        return;
    }
    setActiveBaseWalletAddress(walletAddress);
    await connectActiveWalletForActions(button);
}

async function connectActiveWalletWithWalletConnect(button, network = 'Base') {
    const locale = translations[getActiveLang()];
    const expectedAddress = getActiveBaseWalletAddress();
    if (!/^0x[0-9a-fA-F]{40}$/.test(expectedAddress)) {
        showNotification(locale.baseSwapWalletRequired, 'error');
        return;
    }
    try {
        walletConnectionFlowInProgress = true;
        if (button) setButtonLoading(button, true, locale.operationWalletConnecting);
        const provider = await getWalletConnectProvider();
        const accounts = await provider.enable();
        const selectedAccounts = selectedEvmWalletAddresses(accounts);
        if (!selectedAccounts.length) {
            const error = new Error('active_wallet_no_account');
            error.code = 'active_wallet_no_account';
            throw error;
        }
        const selectedAddress = selectedAccounts.find((address) => address.toLowerCase() === expectedAddress.toLowerCase());
        if (!selectedAddress) {
            try { await provider.disconnect(); } catch (_) { /* No session to close. */ }
            walletConnectProvider = null;
            const error = new Error('active_wallet_wrong_account');
            error.code = 'active_wallet_wrong_account';
            throw error;
        }
        await switchToOperationNetwork(provider, network);
        const chainId = await provider.request({ method: 'eth_chainId' }).catch(() => '');
        setConnectedBaseWalletAddress(selectedAddress, 'walletconnect', chainId);
        updateBaseWalletConnectionState(selectedAddress);
        await refreshActiveWalletConnectionUi();
        showNotification(locale.operationWalletConnected);
    } catch (error) {
        closeWalletConnectModal();
        const message = error?.code === 'active_wallet_no_account'
            ? locale.operationWalletNoAccount
            : error?.code === 'active_wallet_wrong_account'
                ? locale.operationWalletWrongAccount.replace('{address}', `${expectedAddress.slice(0, 6)}…${expectedAddress.slice(-4)}`)
                : error?.code === 4001
                    ? locale.walletConnectRejected
                    : /(?:base_mainnet_not_selected|universal_bridge_network_not_selected)/.test(String(error?.message || ''))
                        ? locale.operationWalletNetworkRequired
                    : locale.operationWalletConnectionFailed;
        console.warn('WalletConnect active wallet connection failed', error);
        showNotification(message, 'error');
    } finally {
        walletConnectionFlowInProgress = false;
        if (button) setButtonLoading(button, false, locale.btnConnectWalletConnect);
    }
}

function getWalletScheduleActionLabel(actionType, locale) {
    return {
        dex: locale.walletScheduleActionSwap,
        bridge: locale.walletScheduleActionBridge,
        lending: locale.walletScheduleActionDefi,
    }[actionType] || actionType || '—';
}

function getScheduleClockInTimezone(timezone) {
    try {
        const parts = new Intl.DateTimeFormat('en-US', {
            weekday: 'short', hour: '2-digit', minute: '2-digit', hour12: false, timeZone: timezone,
        }).formatToParts(new Date());
        const values = Object.fromEntries(parts.map(part => [part.type, part.value]));
        return { day: values.weekday, minutes: (Number(values.hour) % 24) * 60 + Number(values.minute) };
    } catch (_) {
        const now = new Date();
        return { day: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][now.getDay()], minutes: now.getHours() * 60 + now.getMinutes() };
    }
}

function getWalletScheduleNextSlot(schedule) {
    const source = schedule.schedule_mode === 'custom'
        ? (Array.isArray(schedule.custom_slots) ? schedule.custom_slots : [])
        : schedule.schedule_mode === 'flexible'
            ? (Array.isArray(schedule.generated_slots) ? schedule.generated_slots : [])
            : [{ day: schedule.day_of_week, time: schedule.time_of_day }];
    const slots = source.map(slot => ({ day: slot.day || slot.day_of_week, time: slot.time || slot.time_of_day }))
        .filter(slot => /^[A-Z][a-z]{2}$/.test(slot.day || '') && /^\d{2}:\d{2}$/.test(slot.time || ''));
    if (!slots.length) return null;
    const dayOrder = { Sun: 0, Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6 };
    const clock = getScheduleClockInTimezone(schedule.timezone || 'UTC');
    const currentDay = dayOrder[clock.day] ?? 0;
    return slots.map(slot => {
        const [hour, minute] = slot.time.split(':').map(Number);
        let daysAhead = (dayOrder[slot.day] - currentDay + 7) % 7;
        if (daysAhead === 0 && hour * 60 + minute <= clock.minutes) daysAhead = 7;
        return { ...slot, total: daysAhead * 1440 + hour * 60 + minute };
    }).sort((a, b) => a.total - b.total)[0];
}

function renderWalletScheduleSummary(walletId, schedules) {
    const element = document.getElementById(`walletScheduleSummary-${walletId}`);
    if (!element) return;
    const locale = translations[getActiveLang()];
    const enabled = (schedules || []).filter(schedule => schedule.enabled);
    if (!enabled.length) {
        element.className = 'wallet-schedule-summary is-muted';
        element.textContent = locale.walletScheduleStatusInactive;
        return;
    }
    const candidates = enabled.map(schedule => ({ schedule, slot: getWalletScheduleNextSlot(schedule) })).filter(item => item.slot);
    const next = candidates.sort((a, b) => a.slot.total - b.slot.total)[0];
    const schedule = next?.schedule || enabled[0];
    const slot = next?.slot;
    const action = escapeHtml(getWalletScheduleActionLabel(schedule.action_type, locale));
    const status = escapeHtml(locale.walletScheduleStatusActive);
    const dayLabels = Object.fromEntries(walletScheduleDayOptions(locale));
    const nextText = slot
        ? `${escapeHtml(locale.walletScheduleNext)}: ${escapeHtml(dayLabels[slot.day] || slot.day)} ${escapeHtml(slot.time)}`
        : escapeHtml(locale.walletScheduleNextUnavailable);
    element.className = 'wallet-schedule-summary is-active';
    element.innerHTML = `<span class="wallet-schedule-summary-dot" aria-hidden="true"></span><span>${status} · ${action} · ${nextText}</span>`;
}

async function loadWalletScheduleSummaries(wallets) {
    await Promise.all((wallets || []).map(async wallet => {
        const element = document.getElementById(`walletScheduleSummary-${wallet.id}`);
        if (!element) return;
        try {
            const response = await fetch(`/api/wallets/${wallet.id}/schedules`);
            const data = await response.json();
            if (!response.ok) throw new Error('wallet_schedule_load_failed');
            renderWalletScheduleSummary(wallet.id, data.schedules || []);
        } catch (_) {
            element.className = 'wallet-schedule-summary is-muted';
            element.textContent = translations[getActiveLang()].walletScheduleStatusUnavailable;
        }
    }));
}

let accountOverviewActiveWalletId = null;

function openAccountWalletSchedule() {
    if (!accountOverviewActiveWalletId) {
        showNotification(translations[getActiveLang()].accountOverviewNoActiveWallet, 'warning');
        return;
    }
    openWalletScheduleModal(accountOverviewActiveWalletId);
}

async function loadAccountScheduleOverview(activeWallet) {
    const locale = translations[getActiveLang()];
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };

    if (!activeWallet?.id) {
        setText('accountOverviewSchedule', locale.accountOverviewScheduleNoWallet);
        setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
        return;
    }

    setText('accountOverviewSchedule', locale.loading);
    setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
    try {
        const response = await fetch(`/api/wallets/${activeWallet.id}/schedules`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_schedule_load_failed');

        const enabled = (data.schedules || []).filter(schedule => schedule.enabled);
        if (!enabled.length) {
            setText('accountOverviewSchedule', locale.accountOverviewScheduleNoRule);
            setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
            return;
        }

        const candidates = enabled
            .map(schedule => ({ schedule, slot: getWalletScheduleNextSlot(schedule) }))
            .filter(item => item.slot)
            .sort((a, b) => a.slot.total - b.slot.total);
        const next = candidates[0];
        const schedule = next?.schedule || enabled[0];
        const dayLabels = Object.fromEntries(walletScheduleDayOptions(locale));
        const action = getWalletScheduleActionLabel(schedule.action_type, locale);
        const slotText = next?.slot
            ? `${dayLabels[next.slot.day] || next.slot.day} · ${next.slot.time}`
            : locale.walletScheduleNextUnavailable;

        setText('accountOverviewSchedule', `${action} · ${slotText}`);
        setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
    } catch (_) {
        setText('accountOverviewSchedule', locale.accountOverviewScheduleUnavailable);
        setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
    }
}

function accountReadinessRow({ title, detail, tone = 'muted', actionLabel = '', action = '' }) {
    const actionButton = action && actionLabel
        ? `<button type="button" class="account-readiness-action" onclick="${action}">${escapeHtml(actionLabel)}</button>`
        : '';
    return `<div class="account-readiness-row">
        <span class="account-readiness-dot is-${tone}" aria-hidden="true"></span>
        <div class="account-readiness-copy"><strong>${escapeHtml(title)}</strong><span>${escapeHtml(detail)}</span></div>
        ${actionButton}
    </div>`;
}

async function loadAccountReadiness(activeWallet, security, telegram) {
    const container = document.getElementById('accountReadinessContent');
    const summary = document.getElementById('accountReadinessSummary');
    if (!container || !summary) return;
    const locale = translations[getActiveLang()];
    container.innerHTML = `<div class="account-empty-state">${escapeHtml(locale.accountReadinessLoading)}</div>`;

    let schedules = [];
    let scheduleAvailable = Boolean(activeWallet?.id);
    const network = await getWalletSecurityNetwork();
    if (activeWallet?.id) {
        try {
            const response = await fetch(`/api/wallets/${activeWallet.id}/schedules`);
            const data = await response.json();
            if (!response.ok || !Array.isArray(data.schedules)) throw new Error('schedule_unavailable');
            schedules = data.schedules;
        } catch (_) {
            scheduleAvailable = false;
        }
    }

    const hasActiveWallet = Boolean(activeWallet?.id);
    const hasProxy = Boolean(activeWallet?.has_proxy);
    const enabledSchedules = schedules.filter((schedule) => schedule.enabled);
    const networkReady = network.tone === 'success';
    const readyRequired = [hasActiveWallet, hasProxy, networkReady].filter(Boolean).length;
    summary.textContent = readyRequired === 3
        ? locale.accountReadinessReady
        : locale.accountReadinessAttention.replace('{ready}', String(readyRequired));

    const rows = [
        accountReadinessRow({
            title: locale.accountReadinessWallet,
            detail: hasActiveWallet ? locale.accountReadinessWalletReady : locale.accountReadinessWalletMissing,
            tone: hasActiveWallet ? 'ready' : 'attention',
            actionLabel: hasActiveWallet ? locale.accountReadinessOpen : locale.accountReadinessConfigure,
            action: "switchMenu(null, 'Wallets')",
        }),
        accountReadinessRow({
            title: locale.accountReadinessProxy,
            detail: hasActiveWallet
                ? (hasProxy ? locale.accountReadinessProxyReady : locale.accountReadinessProxyMissing)
                : locale.accountReadinessProxyNoWallet,
            tone: hasProxy ? 'ready' : 'attention',
            actionLabel: locale.accountReadinessConfigure,
            action: "switchMenu(null, 'Wallets')",
        }),
        accountReadinessRow({
            title: locale.accountReadinessSchedule,
            detail: !hasActiveWallet
                ? locale.accountReadinessScheduleNoWallet
                : !scheduleAvailable
                    ? locale.accountOverviewScheduleUnavailable
                    : enabledSchedules.length
                        ? locale.accountReadinessScheduleReady.replace('{count}', String(enabledSchedules.length))
                        : locale.accountReadinessScheduleMissing,
            tone: enabledSchedules.length ? 'ready' : 'muted',
            actionLabel: hasActiveWallet ? locale.accountReadinessOpen : locale.accountReadinessConfigure,
            action: hasActiveWallet ? 'openAccountWalletSchedule()' : "switchMenu(null, 'Wallets')",
        }),
        accountReadinessRow({
            title: locale.accountReadinessTelegram,
            detail: telegram?.linked ? locale.accountReadinessTelegramReady : locale.accountReadinessTelegramMissing,
            tone: telegram?.linked ? 'ready' : 'muted',
            actionLabel: telegram?.linked ? locale.accountReadinessOpen : locale.accountReadinessConfigure,
            action: "switchMenu(null, 'Settings')",
        }),
        accountReadinessRow({
            title: locale.accountReadinessNetwork,
            detail: network.text,
            tone: networkReady ? 'ready' : network.tone === 'warning' ? 'attention' : 'muted',
            actionLabel: locale.accountReadinessOpen,
            action: "switchMenu(null, 'Farming')",
        }),
        accountReadinessRow({
            title: locale.accountReadinessSession,
            detail: security?.session_active ? locale.accountReadinessSessionReady : locale.securityUnavailable,
            tone: security?.session_active ? 'ready' : 'attention',
            actionLabel: locale.accountReadinessOpen,
            action: "switchMenu(null, 'Settings')",
        }),
    ];
    container.innerHTML = rows.join('');
}

async function loadWalletsFromDB() {
    const username = getCurrentUsername();
    const container = document.getElementById('walletsListContainer');
    const t = translations[currentLang];
    if(!container) return;
    try {
        const res = await fetch(`/api/wallets/${username}`);
        if (res.status === 401) return;
        const data = await res.json();
        if (!res.ok || !Array.isArray(data.wallets)) throw new Error('wallet_load_failed');
    updateSavedWalletAddressesCache(data.wallets);
    const persistedActiveAddress = getActiveBaseWalletAddress();
    if (persistedActiveAddress && !savedWalletAddressesCache.has(persistedActiveAddress.toLowerCase())) {
        clearActiveWalletState();
    }
    userPlan = data.plan;
    const badge = document.getElementById('slot-info-badge');
    if(badge) badge.innerText = `${t.slotsLabel}: ${data.wallets.length} / ${data.max_slots} (${data.plan})`;
    
    if(data.wallets.length > 0) {
        const activeAddress = getActiveBaseWalletAddress().toLowerCase();
        const connectedAddress = getConnectedBaseWalletAddress().toLowerCase();
        container.innerHTML = data.wallets.map(w => {
            const isActive = activeAddress && w.wallet_address.toLowerCase() === activeAddress;
            const isConnectedForActions = isActive && connectedAddress === w.wallet_address.toLowerCase();
            const walletName = escapeHtml(w.label || `${t.walletDefaultName} ${w.id}`);
            const address = escapeHtml(w.wallet_address);
            const shortAddress = `${w.wallet_address.slice(0, 6)}…${w.wallet_address.slice(-4)}`;
            const proxyStatus = w.has_proxy ? t.walletProxyConfigured : t.walletNoProxy;
            const profileReady = Boolean(w.profile_id && w.profile_status === 'active');
            const profileStatus = profileReady ? t.walletProfileReady : t.walletProfilePending;
            return `
                <div class="wallet-list-item">
                    <div class="wallet-list-info">
                        <div style="color: #fff; font-weight: 600; font-size: 13px;">${walletName}</div>
                        <div class="wallet-list-address">${address}</div>
                        <div style="color: ${isActive ? '#86efac' : 'var(--text-muted)'}; font-size: 12px; margin-top:5px;">${isActive ? (isConnectedForActions ? t.walletSessionActive : t.walletActiveNeedsConnection) : t.walletBaseMonitoring}</div>
                        <div style="color: var(--text-muted); font-size: 12px; margin-top:3px;">${proxyStatus}</div>
                        <div style="color:${profileReady ? '#86efac' : '#fbbf24'}; font-size:12px; margin-top:3px;">${profileReady ? '✓' : '◌'} ${profileStatus}</div>
                        <div id="walletScheduleSummary-${w.id}" class="wallet-schedule-summary is-loading">${t.walletScheduleStatusLoading}</div>
                        <div id="walletHealthResult-${w.id}" style="font-size:12px; line-height:1.45; margin-top:7px;"></div>
                        <div id="walletEditPanel-${w.id}" style="display:none; margin-top:9px; max-width:390px;">
                            <label for="walletEditLabel-${w.id}" style="display:block; margin-bottom:4px; color:var(--text-muted); font-size:11px;">${t.walletEditLabel}</label>
                            <input id="walletEditLabel-${w.id}" value="${walletName}" maxlength="40" class="auth-input" style="font-size:12px; padding:8px 10px;" aria-label="${t.walletEditLabel}">
                            <label for="walletEditProxy-${w.id}" style="display:block; margin:8px 0 4px; color:var(--text-muted); font-size:11px;">${t.walletEditProxy}</label>
                            <input id="walletEditProxy-${w.id}" maxlength="512" class="auth-input" style="font-size:12px; padding:8px 10px;" placeholder="${t.walletEditProxyPlaceholder}" aria-describedby="walletEditProxyNote-${w.id}">
                            <div id="walletEditProxyNote-${w.id}" style="margin-top:4px; color:var(--text-muted); font-size:10px; line-height:1.35;">${t.walletEditProxyNote}</div>
                            <button type="button" onclick="saveWalletDetails(${w.id})" class="btn-dark-sm" style="margin-top:8px; padding:7px 10px; border-color:#7c3aed;">${t.walletEditSave}</button>
                        </div>
                    </div>
                    <div class="wallet-list-actions">
                        <button type="button" onclick="activateSavedWallet(${w.id}, '${w.wallet_address}')" ${isActive ? 'disabled' : ''} style="background:${isActive ? 'rgba(34,197,94,0.12)' : 'rgba(124,58,237,0.12)'}; color:${isActive ? '#86efac' : '#c4b5fd'}; border:1px solid ${isActive ? 'rgba(34,197,94,0.28)' : 'rgba(124,58,237,0.32)'}; padding:6px 10px; border-radius:8px; font-size:12px; cursor:${isActive ? 'default' : 'pointer'};">${isActive ? t.walletActive : t.walletActivate}</button>
                        ${isActive && !isConnectedForActions ? `<button type="button" onclick="connectSavedWalletForActions('${w.wallet_address}', this)" style="background:rgba(34,197,94,.10); color:#86efac; border:1px solid rgba(34,197,94,.30); padding:6px 10px; border-radius:8px; font-size:12px; cursor:pointer;">${t.walletConnectActive.replace('{address}', shortAddress)}</button>` : ''}
                        <button type="button" onclick="toggleWalletEditor(${w.id})" style="background:rgba(255,255,255,.06); color:#e5e7eb; border:1px solid var(--border-color); padding:6px 10px; border-radius:8px; font-size:12px; cursor:pointer;">${t.walletEdit}</button>
                        <button type="button" onclick="openWalletScheduleModal(${w.id})" style="background:rgba(124,58,237,.12); color:#ddd6fe; border:1px solid rgba(139,92,246,.38); padding:6px 10px; border-radius:8px; font-size:12px; cursor:pointer;">${t.walletScheduleButton}</button>
                        <button type="button" onclick="checkWalletHealth(${w.id}, this)" style="background:rgba(59,130,246,0.1); color:#93c5fd; border:1px solid rgba(59,130,246,0.28); padding:6px 10px; border-radius:8px; font-size:12px; cursor:pointer;">${t.walletHealthCheck}</button>
                        ${w.has_proxy ? `<button type="button" onclick="testWalletProxy(${w.id}, this)" style="background: rgba(34,197,94,0.1); color: #22c55e; border: 1px solid rgba(34,197,94,0.2); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor:pointer;">${t.walletProxyTest}</button>` : ''}
                        ${!profileReady ? `<button type="button" onclick="createWalletProfile(${w.id}, this)" style="background:rgba(124,58,237,.12); color:#d8b4fe; border:1px solid rgba(124,58,237,.35); padding:6px 10px; border-radius:8px; font-size:12px; cursor:pointer;">${t.walletProfileCreate}</button>` : ''}
                        <button type="button" onclick="deleteWallet(${w.id})" style="background: rgba(239,68,68,0.1); color: #ef4444; border: 1px solid rgba(239,68,68,0.2); padding: 6px 10px; border-radius: 8px; font-size: 12px; cursor:pointer;">${t.walletRemove}</button>
                    </div>
                </div>
            `;
        }).join('');
    } else {
        container.innerHTML = renderAppEmptyState(
            t.emptyStateWalletsTitle,
            t.noWal,
            t.emptyStateWalletsAction,
            'connectBaseWallet(true)'
        );
    }
    loadWalletScheduleSummaries(data.wallets);
    } catch (_) {
        container.innerHTML = `<div style="color:#fca5a5; font-size:13px;">${t.walletLoadError}</div>`;
    }
}

async function activateSavedWallet(walletId, walletAddress) {
    const locale = translations[getActiveLang()];
    if (!/^0x[0-9a-fA-F]{40}$/.test(walletAddress || '')) return;
    setActiveBaseWalletAddress(walletAddress);
    await loadWalletsFromDB();
    showNotification(locale.walletActivated, 'success');
}

function toggleWalletEditor(walletId) {
    const panel = document.getElementById(`walletEditPanel-${walletId}`);
    if (panel) panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
}

async function saveWalletDetails(walletId) {
    const locale = translations[getActiveLang()];
    const label = document.getElementById(`walletEditLabel-${walletId}`)?.value.trim() || '';
    const proxyInput = document.getElementById(`walletEditProxy-${walletId}`);
    const proxy = proxyInput?.value.trim() || '';
    if (!label) {
        showNotification(locale.walletEditInvalid, 'error');
        return;
    }
    // An empty proxy field means “keep the current proxy”. This prevents a
    // harmless name edit from accidentally disabling the wallet's network
    // isolation and invalidating its schedule.
    const payload = { label };
    if (proxy) payload.proxy = proxy;
    try {
        const response = await fetch(`/api/wallets/${walletId}`, {
            method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_label_update_failed');
        showNotification(locale.walletEditSaved, 'success');
        await loadWalletsFromDB();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || locale.walletEditInvalid, 'error');
    }
}

async function createWalletProfile(walletId, button) {
    const locale = translations[getActiveLang()];
    const originalText = button?.innerText || locale.walletProfileCreate;
    try {
        if (button) {
            button.disabled = true;
            button.innerText = locale.walletHealthChecking;
        }
        const response = await fetch(`/api/wallets/${walletId}/profile`, { method: 'POST' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_profile_create_failed');
        showNotification(locale.walletProfileCreated, 'success');
        await loadWalletsFromDB();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || locale.walletLoadError, 'error');
    } finally {
        if (button) {
            button.disabled = false;
            button.innerText = originalText;
        }
    }
}

async function checkWalletHealth(walletId, button) {
    const locale = translations[getActiveLang()];
    const result = document.getElementById(`walletHealthResult-${walletId}`);
    const defaultText = button?.innerText || locale.walletHealthCheck;
    try {
        if (button) {
            button.disabled = true;
            button.innerText = locale.walletHealthChecking;
        }
        const response = await fetch(`/api/wallets/${walletId}/health`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_health_unavailable');
        if (result) {
            const summary = locale.walletHealthSummary
                .replace('{network}', escapeHtml(data.network))
                .replace('{balance}', escapeHtml(data.balance_eth))
                .replace('{count}', escapeHtml(String(data.transaction_count)));
            result.innerHTML = `<div style="color:#86efac;">${summary}</div><div style="color:var(--text-muted); margin-top:3px;">${locale.walletHealthNotice}</div>`;
        }
    } catch (error) {
        if (result) result.innerHTML = `<span style="color:#fca5a5;">${locale.walletHealthUnavailable}</span>`;
    } finally {
        if (button) {
            button.disabled = false;
            button.innerText = defaultText;
        }
    }
}

async function testWalletProxy(walletId, btn) {
    const locale = translations[getActiveLang()] || translations.ru;
    btn.textContent = locale.walletProxyChecking || locale.loading;
    btn.disabled = true;
    btn.style.background = 'rgba(255, 255, 255, 0.1)';
    btn.style.color = '#fff';
    btn.style.borderColor = 'rgba(255, 255, 255, 0.2)';

    try {
        const res = await fetch(`/api/wallets/test-proxy/${walletId}`, { method: 'POST' });
        const data = await res.json();
        
        if (res.ok && data.status === 'success') {
            const match = String(data.message || '').match(/(\d+)\s*ms/);
            const ping = match ? parseInt(match[1]) : 0;
            if (ping >= 1000) {
                btn.style.background = 'rgba(234, 179, 8, 0.1)';
                btn.style.color = '#eab308';
                btn.style.borderColor = 'rgba(234, 179, 8, 0.2)';
                btn.textContent = (locale.walletProxySlow || 'Proxy is slow: {ping} ms').replace('{ping}', String(ping));
            } else {
                btn.style.background = 'rgba(34, 197, 94, 0.1)';
                btn.style.color = '#22c55e';
                btn.style.borderColor = 'rgba(34, 197, 94, 0.2)';
                btn.textContent = (locale.walletProxyOk || 'Proxy works: {ping} ms').replace('{ping}', String(ping));
            }
        } else {
            btn.style.background = 'rgba(239, 68, 68, 0.1)';
            btn.style.color = '#ef4444';
            btn.style.borderColor = 'rgba(239, 68, 68, 0.2)';
            btn.textContent = locale.walletProxyFailed || locale.walletProxyTest;
        }
    } catch (e) {
        btn.style.background = 'rgba(239, 68, 68, 0.1)';
        btn.style.color = '#ef4444';
        btn.style.borderColor = 'rgba(239, 68, 68, 0.2)';
        btn.textContent = locale.walletProxyFailed || locale.walletProxyTest;
    }
    btn.disabled = false;
}

async function deleteWallet(id) {
    const locale = translations[getActiveLang()] || translations.ru;
    const approved = await openAppConfirm({
        title: locale.walletRemoveTitle,
        message: locale.walletRemoveConfirm,
        confirmText: locale.walletRemoveAction,
    });
    if (!approved) return;
    try {
        const response = await fetch(`/api/wallets/delete/${id}`, { method: 'DELETE' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_delete_failed');
        showNotification(locale.walletRemoved, 'success');
        await loadWalletsFromDB();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || locale.walletLoadError, 'error');
    }
}

async function buyExtraSlot() {
    const username = getCurrentUsername();
    const res = await fetch('/api/wallets/buy-slot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username })
    });
    const data = await res.json();
    if (res.ok) {
        showNotification("OK!");
        loadWalletsFromDB();
        const balEl = document.getElementById('userBalanceValue');
        if (balEl && data.balance !== undefined) balEl.innerText = `$${data.balance.toFixed(2)}`;
    } else {
        showNotification(translateBackendDetail(data.detail), "error");
    }
}

// --- Общие настройки и уведомления ---
function toggleSchedulerState(checkbox) {
    const wrapper = document.getElementById('schedulerSettingsWrapper');
    if (!wrapper) return;
    if (checkbox.checked) {
        wrapper.style.opacity = '1';
        wrapper.style.pointerEvents = 'auto';
    } else {
        wrapper.style.opacity = '0.35';
        wrapper.style.pointerEvents = 'none';
    }
}

function handleCalendarDayClick(element) {
    element.classList.toggle('active');
    updateDailyConfigsUI();
}

function updateDailyConfigsUI() {
    const container = document.getElementById('dailyTimeConfigsContainer');
    if (!container) return;
    const t = translations[currentLang];
    
    const activeDays = [];
    document.querySelectorAll('#globalCalendarGrid .calendar-day.active').forEach(el => {
        activeDays.push(el.getAttribute('data-raw-day'));
    });

    if (activeDays.length === 0) {
        container.innerHTML = `<div style="font-size: 13px; color: var(--text-muted); font-style: italic; padding: 6px;">-</div>`;
        return;
    }

    let htmlContent = renderInterfaceHint('scheduler-time-alert', t.timeAlert, 'purple', '', '◷');

    htmlContent += activeDays.map(day => {
        const savedTime = localStorage.getItem(`day_time_${day}`) || `${String(Math.floor(Math.random()*15)+8).padStart(2,'0')}:${String(Math.floor(Math.random()*60)).padStart(2,'0')}`;
        const savedMinDelay = localStorage.getItem(`day_min_delay_${day}`) || 60;
        const savedMaxDelay = localStorage.getItem(`day_max_delay_${day}`) || 300;
        const displayDay = t.calDays[day] || day;

        return `
            <div style="display: flex; justify-content: space-between; align-items: center; background: var(--bg-main); padding: 10px 14px; border-radius: 10px; border: 1px solid var(--border-color); margin-bottom: 6px; gap: 10px;" data-day="${day}">
                <div style="color: #fff; font-weight: bold; font-size: 13px; width: 35px;">${displayDay}</div>
                <div style="display: flex; gap: 10px; align-items: center; flex: 1; justify-content: flex-end; flex-wrap: wrap;">
                    
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <span style="font-size: 12px; color: var(--text-muted);">${t.tTime}</span>
                        <input type="text" class="auth-input day-time-val" value="${savedTime}" placeholder="15:30" maxlength="5" inputmode="numeric" pattern="[0-2][0-9]:[0-5][0-9]"
                            style="padding: 6px; width: 60px; font-size: 13px; background: var(--bg-card); text-align: center;"
                            oninput="format24HourTimeInput(this)" onblur="normalize24HourTimeInput(this)">
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <span style="font-size: 12px; color: var(--text-muted);">${t.tMin}</span>
                        <input type="number" inputmode="numeric" class="auth-input day-min-delay-val" value="${savedMinDelay}" min="15" max="7200" oninput="sanitizeIntegerInput(this, 4); checkInputLimit(this, 7200)" style="padding: 6px; width: 65px; font-size: 13px; background: var(--bg-card);">
                    </div>
                    
                    <div style="display: flex; align-items: center; gap: 6px;">
                        <span style="font-size: 12px; color: var(--text-muted);">${t.tMax}</span>
                        <input type="number" inputmode="numeric" class="auth-input day-max-delay-val" value="${savedMaxDelay}" min="15" max="7200" oninput="sanitizeIntegerInput(this, 4); checkInputLimit(this, 7200)" style="padding: 6px; width: 65px; font-size: 13px; background: var(--bg-card);">
                    </div>
                </div>
            </div>
        `;
    }).join('');
    container.innerHTML = htmlContent;
}

function randomizeGlobalSettings() {
    const now = Date.now();
    if (now - lastRandomizeTimestamp < 2500) return;
    lastRandomizeTimestamp = now;
    
    if (shouldRotateProxy()) {
        rotateProxyIndex();
    }

    const allDays = ['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Вс'];
    const targetCount = Math.floor(Math.random() * 4) + 1;
    const shuffledDays = [...allDays].sort(() => 0.5 - Math.random());
    const selectedDays = shuffledDays.slice(0, targetCount);

    const dayElements = document.querySelectorAll('#globalCalendarGrid .calendar-day');
    dayElements.forEach(el => {
        if (selectedDays.includes(el.getAttribute('data-raw-day'))) el.classList.add('active');
        else el.classList.remove('active');
    });
    updateDailyConfigsUI();

    document.querySelectorAll('#dailyTimeConfigsContainer > div[data-day]').forEach(row => {
        const randHour = String(Math.floor(Math.random() * 15) + 8).padStart(2, '0');
        const randMin = String(Math.floor(Math.random() * 60)).padStart(2, '0');
        row.querySelector('.day-time-val').value = `${randHour}:${randMin}`;
        
const minDelay = Math.floor(getRandomDelay(15, 90));
        const maxDelay = minDelay + Math.floor(getRandomDelay(60, 300));
        
        row.querySelector('.day-min-delay-val').value = minDelay;
        const maxField = row.querySelector('.day-max-delay-val');
        maxField.value = maxDelay;
        checkInputLimit(maxField, 7200);
    });

    const gweiInput = document.getElementById('globalGweiInput');
    if(gweiInput) {
        gweiInput.value = Math.floor(Math.random() * 120) + 25;
        checkInputLimit(gweiInput, 300);
    }
}

async function saveGlobalProfileSettings() {
    let gwei = parseInt(document.getElementById('globalGweiInput')?.value || 30);
    if (isNaN(gwei) || gwei < 5 || gwei > 300) return;

    const now = Date.now();
    if (now - lastSaveTimestamp < 1500) return;
    lastSaveTimestamp = now;

    const notifyTransactionSubmitted = document.getElementById('notifTransactionSubmittedToggle')?.checked ?? false;
    const notifyTransactionFinal = document.getElementById('notifTransactionFinalToggle')?.checked ?? true;
    const notifyReminders = document.getElementById('notifRemindersToggle')?.checked ?? true;
    const notifyErrors = document.getElementById('notifErrorsToggle')?.checked ?? true;
    const notifyDefiSupplySubmitted = document.getElementById('notifDefiSupplySubmittedToggle')?.checked ?? false;
    const notifyDefiWithdrawSubmitted = document.getElementById('notifDefiWithdrawSubmittedToggle')?.checked ?? false;
    const notifyDefiFinal = document.getElementById('notifDefiFinalToggle')?.checked ?? false;
    const notifyDefiErrors = document.getElementById('notifDefiErrorsToggle')?.checked ?? false;
    const notifySettings = true;
    const notifyStart = notifyTransactionSubmitted;
    const notifySuccess = notifyTransactionFinal;
    const notifyError = notifyErrors;
    const interfaceHints = areInterfaceHintsEnabled();

    localStorage.setItem('ax_notify_transactions_submitted', notifyTransactionSubmitted);
    localStorage.setItem('ax_notify_transactions_final', notifyTransactionFinal);
    localStorage.setItem('ax_notify_reminders', notifyReminders);
    localStorage.setItem('ax_notify_errors', notifyErrors);
    localStorage.setItem('ax_notify_defi_supply_submitted', notifyDefiSupplySubmitted);
    localStorage.setItem('ax_notify_defi_withdraw_submitted', notifyDefiWithdrawSubmitted);
    localStorage.setItem('ax_notify_defi_final', notifyDefiFinal);
    localStorage.setItem('ax_notify_defi_errors', notifyDefiErrors);

    const username = getCurrentUsername();
    const profileConfig = { 
        username,
        // Scheduling is configured per wallet in the Wallets section. Keep the
        // legacy fields explicit for backwards-compatible API validation, but
        // never let the profile settings page create or overwrite a schedule.
        schedulerEnabled: false,
        days: [],
        schedule: {},
        gwei, 
        telegram: null,
        notifySettings,
        notifyStart,
        notifySuccess,
        notifyError,
        notifyTransactionSubmitted,
        notifyTransactionFinal,
        notifyReminders,
        notifyErrors,
        notifyDefiSupplySubmitted,
        notifyDefiWithdrawSubmitted,
        notifyDefiFinal,
        notifyDefiErrors,
        interfaceHints,
        language: currentLang
    };
    
    try {
        const response = await fetch('/api/settings/save', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(profileConfig)
        });
        const result = await response.json();
        if (response.ok && result.status === 'success') {
            showNotification("OK!");
        } else {
            showNotification(translateBackendDetail(result.detail), "error");
        }
    } catch (err) {
        showNotification("Error", "error");
    }
}

// A new visitor should see the contextual explanations at least once.  We only
// create the preference when no current or legacy choice exists, so a user's
// later decision is never overwritten on subsequent visits.
function initializeInterfaceHintsPreference() {
    const hasCurrentChoice = localStorage.getItem('ax_interface_hints_enabled') !== null;
    const hasLegacyChoice = localStorage.getItem('hide_security_banner') !== null
        || localStorage.getItem('hide_all_banners') !== null;

    if (!hasCurrentChoice && !hasLegacyChoice) {
        localStorage.setItem('ax_interface_hints_enabled', 'true');
    }
}

let activeWalletScheduleId = null;
let activeWalletScheduleHasProxy = false;
let walletSchedulePreviewVersion = 0;
let walletScheduleMode = 'flexible';
let walletScheduleCustomSlots = [];
let walletScheduleMutationInFlight = false;

function walletScheduleDayOptions(locale) {
    return [
        ['Mon', locale.planReminderMonday], ['Tue', locale.planReminderTuesday],
        ['Wed', locale.planReminderWednesday], ['Thu', locale.planReminderThursday],
        ['Fri', locale.planReminderFriday], ['Sat', locale.planReminderSaturday],
        ['Sun', locale.planReminderSunday],
    ];
}

function renderWalletScheduleInlineHint(elementId, hintId, message, tone = 'info') {
    const element = document.getElementById(elementId);
    if (!element) return;

    element.dataset.interfaceHint = hintId;
    element.classList.toggle('missing', tone === 'warning');

    if (!isInterfaceHintVisible(hintId)) {
        element.hidden = true;
        return;
    }

    element.hidden = false;
    element.innerHTML = `
        <span>${escapeHtml(message)}</span>
        <button type="button" class="wallet-schedule-hint-close" onclick="dismissInterfaceHint('${hintId}')" aria-label="${escapeHtml(t('interfaceHintClose'))}" title="${escapeHtml(t('interfaceHintClose'))}">×</button>
    `;
}

function renderWalletScheduleProxyNotice(message, hasProxy) {
    const element = document.getElementById('walletScheduleProxyNotice');
    if (!element) return;

    // A missing proxy prevents a schedule from being saved, so that warning must remain visible.
    if (!hasProxy) {
        element.hidden = false;
        element.removeAttribute('data-interface-hint');
        element.classList.add('missing');
        element.textContent = message;
        return;
    }

    renderWalletScheduleInlineHint('walletScheduleProxyNotice', 'wallet-schedule-proxy-ready', message, 'success');
}

function populateWalletScheduleText() {
    const locale = translations[getActiveLang()];
    const textMap = {
        walletScheduleTitle: locale.walletScheduleTitle,
        walletScheduleActionLabel: locale.walletScheduleActionLabel,
        walletScheduleActionSwap: locale.walletScheduleActionSwap,
        walletScheduleActionBridge: locale.walletScheduleActionBridge,
        walletScheduleActionDefi: locale.walletScheduleActionDefi,
        walletScheduleDayLabel: locale.walletScheduleDayLabel,
        walletScheduleTimeLabel: locale.walletScheduleTimeLabel,
        walletScheduleTimezoneLabel: locale.walletScheduleTimezoneLabel,
        walletScheduleTelegramLabel: locale.walletScheduleTelegramLabel,
        walletScheduleAcknowledgementLabel: locale.walletScheduleAcknowledgementLabel,
        walletScheduleSave: locale.walletScheduleSave,
        walletScheduleListTitle: locale.walletScheduleListTitle,
        walletScheduleFlexibleDescription: locale.walletScheduleFlexibleDescription,
        walletScheduleWeeklyMinLabel: locale.walletScheduleWeeklyMinLabel,
        walletScheduleWeeklyMaxLabel: locale.walletScheduleWeeklyMaxLabel,
        walletScheduleWindowStartLabel: locale.walletScheduleWindowStartLabel,
        walletScheduleWindowEndLabel: locale.walletScheduleWindowEndLabel,
        walletSchedulePreviewTitle: locale.walletSchedulePreviewTitle,
        walletSchedulePreviewDesc: locale.walletSchedulePreviewDesc,
        walletSchedulePreviewRefresh: locale.walletSchedulePreviewRefresh,
        walletScheduleAutoMode: locale.walletScheduleAutoMode,
        walletScheduleCustomMode: locale.walletScheduleCustomMode,
    };
    Object.entries(textMap).forEach(([id, value]) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    });
    renderWalletScheduleInlineHint('walletScheduleSafety', 'wallet-schedule-safety', locale.walletScheduleSafety);
    renderWalletSchedulePreview();
}

function getWalletSchedulePreviewSlots() {
    if (walletScheduleMode === 'custom') {
        return walletScheduleCustomSlots.map(slot => ({
            day: walletScheduleDayOptions(translations[getActiveLang()]).findIndex(([code]) => code === slot.day),
            time: slot.time,
        })).filter(slot => slot.day >= 0);
    }
    const weeklyMin = Number(document.getElementById('walletScheduleWeeklyMin')?.value || 3);
    const weeklyMax = Number(document.getElementById('walletScheduleWeeklyMax')?.value || 4);
    const start = normalize24HourTime(document.getElementById('walletScheduleWindowStart')?.value);
    const end = normalize24HourTime(document.getElementById('walletScheduleWindowEnd')?.value);
    if (!Number.isInteger(weeklyMin) || !Number.isInteger(weeklyMax) || weeklyMin < 1 || weeklyMax > 7 || weeklyMin > weeklyMax || !start || !end || start >= end) {
        return [];
    }
    const [startHour, startMinute] = start.split(':').map(Number);
    const [endHour, endMinute] = end.split(':').map(Number);
    const startTotal = startHour * 60 + startMinute;
    const duration = endHour * 60 + endMinute - startTotal;
    const count = weeklyMin + (walletSchedulePreviewVersion % (weeklyMax - weeklyMin + 1));
    const dayOrder = [0, 3, 5, 1, 6, 2, 4];
    const offset = walletSchedulePreviewVersion % dayOrder.length;
    return Array.from({ length: count }, (_, index) => {
        const day = dayOrder[(index + offset) % dayOrder.length];
        const fraction = (index + 1) / (count + 1);
        const minuteOffset = Math.min(duration - 1, Math.max(0, Math.round(duration * fraction)));
        const total = startTotal + minuteOffset;
        return { day, time: `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}` };
    });
}

function renderWalletSchedulePreview() {
    const preview = document.getElementById('walletScheduleGeneratedPreview');
    if (!preview) return;
    const locale = translations[getActiveLang()];
    const days = walletScheduleDayOptions(locale);
    const slots = getWalletSchedulePreviewSlots();
    const autoButton = document.getElementById('walletScheduleAutoMode');
    const customButton = document.getElementById('walletScheduleCustomMode');
    const description = document.getElementById('walletScheduleFlexibleDescription');
    const refreshButton = document.getElementById('walletSchedulePreviewRefresh');
    if (autoButton) autoButton.classList.toggle('is-active', walletScheduleMode === 'flexible');
    if (customButton) customButton.classList.toggle('is-active', walletScheduleMode === 'custom');
    if (description) description.textContent = walletScheduleMode === 'custom'
        ? locale.walletScheduleCustomDescription
        : locale.walletScheduleFlexibleDescription;
    if (refreshButton) refreshButton.textContent = walletScheduleMode === 'custom'
        ? locale.walletScheduleUseAuto
        : locale.walletSchedulePreviewRefresh;
    if (!slots.length && walletScheduleMode !== 'custom') {
        preview.innerHTML = `<div class="wallet-schedule-preview-empty">${escapeHtml(walletScheduleMode === 'custom' ? locale.walletScheduleCustomEmpty : locale.walletScheduleFlexibleInvalid)}</div>`;
        return;
    }
    const slotByDay = new Map(slots.map(slot => [slot.day, slot.time]));
    const customHint = walletScheduleMode === 'custom' && !slots.length
        ? `<div class="wallet-schedule-custom-hint">${escapeHtml(locale.walletScheduleCustomEmpty)}</div>`
        : '';
    preview.innerHTML = `${customHint}<div class="wallet-schedule-calendar">${days.map(([, label], day) => {
        const time = slotByDay.get(day);
        const code = days[day][0];
        if (walletScheduleMode === 'custom') {
            return `<button type="button" class="wallet-schedule-calendar-day wallet-schedule-calendar-button${time ? ' active' : ''}" onclick="toggleWalletScheduleCustomDay('${code}')" aria-pressed="${time ? 'true' : 'false'}"><span>${escapeHtml(label)}</span>${time ? `<input data-schedule-time="${code}" type="time" value="${escapeHtml(time)}" aria-label="${escapeHtml(label)}" onclick="event.stopPropagation()" onchange="setWalletScheduleCustomTime('${code}', this.value)">` : `<b>+</b>`}</button>`;
        }
        return `<div class="wallet-schedule-calendar-day${time ? ' active' : ''}"><span>${escapeHtml(label)}</span><b>${time ? escapeHtml(time) : '—'}</b></div>`;
    }).join('')}</div>`;
}

function refreshWalletSchedulePreview() {
    if (walletScheduleMode === 'custom') {
        setWalletScheduleMode('flexible');
        return;
    }
    walletSchedulePreviewVersion += 1;
    renderWalletSchedulePreview();
}

function setWalletScheduleMode(mode) {
    walletScheduleMode = mode === 'custom' ? 'custom' : 'flexible';
    renderWalletSchedulePreview();
}

function toggleWalletScheduleCustomDay(day) {
    const index = walletScheduleCustomSlots.findIndex(slot => slot.day === day);
    if (index >= 0) {
        walletScheduleCustomSlots.splice(index, 1);
        renderWalletSchedulePreview();
        return;
    }
    walletScheduleCustomSlots.push({ day, time: '18:00' });
    walletScheduleCustomSlots.sort((a, b) => walletScheduleDayOptions(translations[getActiveLang()]).findIndex(([code]) => code === a.day) - walletScheduleDayOptions(translations[getActiveLang()]).findIndex(([code]) => code === b.day));
    renderWalletSchedulePreview();
    window.setTimeout(() => document.querySelector(`[data-schedule-time="${day}"]`)?.focus(), 0);
}

function setWalletScheduleCustomTime(day, value) {
    const normalized = normalize24HourTime(value);
    if (!normalized) return;
    const slot = walletScheduleCustomSlots.find(item => item.day === day);
    if (slot) slot.time = normalized;
}

function populateWalletScheduleForm(schedule) {
    if (!schedule) return;
    const action = document.getElementById('walletScheduleAction');
    const timezone = document.getElementById('walletScheduleTimezone');
    const telegram = document.getElementById('walletScheduleTelegram');
    if (action && ['dex', 'bridge', 'lending'].includes(schedule.action_type)) action.value = schedule.action_type;
    if (timezone && schedule.timezone) timezone.value = schedule.timezone;
    if (telegram) telegram.checked = schedule.telegram_enabled !== false;

    const mode = schedule.schedule_mode === 'custom' || schedule.schedule_mode === 'fixed' ? 'custom' : 'flexible';
    walletScheduleMode = mode;
    if (mode === 'flexible') {
        const min = document.getElementById('walletScheduleWeeklyMin');
        const max = document.getElementById('walletScheduleWeeklyMax');
        const start = document.getElementById('walletScheduleWindowStart');
        const end = document.getElementById('walletScheduleWindowEnd');
        if (min && Number.isInteger(Number(schedule.weekly_min))) min.value = schedule.weekly_min;
        if (max && Number.isInteger(Number(schedule.weekly_max))) max.value = schedule.weekly_max;
        if (start && schedule.window_start) start.value = schedule.window_start;
        if (end && schedule.window_end) end.value = schedule.window_end;
        walletScheduleCustomSlots = [];
        return;
    }

    const source = schedule.schedule_mode === 'custom'
        ? (Array.isArray(schedule.custom_slots) ? schedule.custom_slots : [])
        : [{ day_of_week: schedule.day_of_week, time_of_day: schedule.time_of_day }];
    walletScheduleCustomSlots = source.map(slot => ({
        day: slot.day || slot.day_of_week,
        time: normalize24HourTime(slot.time || slot.time_of_day) || '18:00',
    })).filter(slot => /^[A-Z][a-z]{2}$/.test(slot.day));
}

async function openWalletScheduleModal(walletId) {
    activeWalletScheduleId = Number(walletId);
    walletSchedulePreviewVersion = 0;
    walletScheduleMode = 'flexible';
    walletScheduleCustomSlots = [];
    populateWalletScheduleText();
    const timezoneInput = document.getElementById('walletScheduleTimezone');
    if (timezoneInput) timezoneInput.value = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
    const acknowledgement = document.getElementById('walletScheduleAcknowledgement');
    if (acknowledgement) acknowledgement.checked = false;
    ['walletScheduleWeeklyMin', 'walletScheduleWeeklyMax', 'walletScheduleWindowStart', 'walletScheduleWindowEnd'].forEach(id => {
        const input = document.getElementById(id);
        if (input && input.dataset.schedulePreviewBound !== 'true') {
            input.addEventListener('input', renderWalletSchedulePreview);
            input.dataset.schedulePreviewBound = 'true';
        }
    });
    const status = document.getElementById('walletScheduleStatus');
    if (status) status.textContent = '';
    showAppModal('walletScheduleModal');
    await loadWalletSchedules();
}

function closeWalletScheduleModal() {
    activeWalletScheduleId = null;
    hideAppModal('walletScheduleModal');
}

function handleWalletScheduleOverlayClick(event) {
    if (event.target.id === 'walletScheduleModal' && mousedownOverlayTarget?.id === 'walletScheduleModal') {
        closeWalletScheduleModal();
    }
}

async function loadWalletSchedules() {
    if (!activeWalletScheduleId) return;
    const locale = translations[getActiveLang()];
    const list = document.getElementById('walletScheduleList');
    const status = document.getElementById('walletScheduleStatus');
    if (list) list.textContent = locale.loading;
    try {
        const response = await fetch(`/api/wallets/${activeWalletScheduleId}/schedules`);
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_schedule_load_failed');
        activeWalletScheduleHasProxy = Boolean(data.wallet?.has_proxy);
        const schedules = Array.isArray(data.schedules) ? data.schedules : [];
        populateWalletScheduleForm(schedules.find(item => item.enabled) || schedules[0]);
        const walletDisplay = document.getElementById('walletScheduleWallet');
        if (walletDisplay) {
            const label = data.wallet?.label || `${locale.walletDefaultName} ${activeWalletScheduleId}`;
            const address = data.wallet?.wallet_address || '';
            walletDisplay.textContent = `${label} · ${address.slice(0, 8)}…${address.slice(-6)}`;
        }
        renderWalletScheduleProxyNotice(
            activeWalletScheduleHasProxy ? locale.walletScheduleProxyReady : locale.walletScheduleProxyRequired,
            activeWalletScheduleHasProxy,
        );
        const saveButton = document.getElementById('walletScheduleSave');
        if (saveButton) saveButton.disabled = !activeWalletScheduleHasProxy;
        renderWalletSchedulePreview();
        renderWalletSchedules(schedules);
        loadWalletScheduleSummaries([{ id: activeWalletScheduleId }]);
        if (status && !data.telegram_linked) status.textContent = locale.walletScheduleTelegramMissing;
    } catch (error) {
        if (list) list.textContent = locale.walletScheduleLoadError;
        if (status) status.textContent = translateBackendDetail(error.message) || locale.walletScheduleLoadError;
    }
}

function renderWalletSchedules(schedules) {
    const locale = translations[getActiveLang()];
    const list = document.getElementById('walletScheduleList');
    if (!list) return;
    if (!schedules.length) {
        list.innerHTML = `<div style="color:var(--text-muted);font-size:12px;">${escapeHtml(locale.walletScheduleEmpty)}</div>`;
        return;
    }
    const actionNames = {
        dex: locale.walletScheduleActionSwap,
        bridge: locale.walletScheduleActionBridge,
        lending: locale.walletScheduleActionDefi,
    };
    const dayNames = Object.fromEntries(walletScheduleDayOptions(locale));
    list.innerHTML = schedules.map(item => {
        const generatedSlots = Array.isArray(item.generated_slots) ? item.generated_slots : [];
        const customSlots = Array.isArray(item.custom_slots) ? item.custom_slots : [];
        const flexibleSummary = item.schedule_mode === 'flexible'
            ? `${escapeHtml(locale.walletScheduleFlexibleShort
                .replace('{min}', item.weekly_min)
                .replace('{max}', item.weekly_max))} · ${escapeHtml(item.window_start)}–${escapeHtml(item.window_end)}`
            : item.schedule_mode === 'custom'
                ? customSlots.map(slot => `${escapeHtml(dayNames[slot.day] || slot.day)} ${escapeHtml(slot.time)}`).join(' · ')
            : `${escapeHtml(dayNames[item.day_of_week] || item.day_of_week)} · ${escapeHtml(item.time_of_day)}`;
        const preview = generatedSlots.length
            ? `<small>${escapeHtml(locale.walletScheduleGeneratedLabel)}: ${generatedSlots.map(slot => `${escapeHtml(dayNames[slot.day] || slot.day)} ${escapeHtml(slot.time)}`).join(' · ')}</small>`
            : '';
        const rerollButton = item.schedule_mode === 'flexible'
            ? `<button type="button" class="wallet-schedule-reroll" onclick="rerollWalletSchedule(${Number(item.id)}, this)">${escapeHtml(locale.walletScheduleReroll)}</button>`
            : '';
        return `
        <div class="wallet-schedule-item">
            <div>
                <b>${escapeHtml(actionNames[item.action_type] || item.action_type)}</b>
                <small>${flexibleSummary} · ${escapeHtml(item.timezone)}${item.enabled ? '' : ` · ${escapeHtml(locale.walletScheduleDisabled)}`}</small>
                ${preview}
            </div>
            <div class="wallet-schedule-actions">
                ${rerollButton}
                <button type="button" class="wallet-schedule-delete" onclick="deleteWalletSchedule(${Number(item.id)}, this)">${escapeHtml(locale.walletScheduleDelete)}</button>
            </div>
        </div>`;
    }).join('');
}

async function rerollWalletSchedule(scheduleId, button) {
    if (!activeWalletScheduleId || walletScheduleMutationInFlight) return;
    const locale = translations[getActiveLang()];
    const status = document.getElementById('walletScheduleStatus');
    walletScheduleMutationInFlight = true;
    if (button) { button.disabled = true; button.textContent = locale.loading; }
    try {
        if (status) status.textContent = locale.walletScheduleRerolling;
        const response = await fetch(`/api/wallets/${activeWalletScheduleId}/schedules/${scheduleId}/reroll`, {
            method: 'POST',
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_schedule_reroll_failed');
        if (status) status.textContent = locale.walletScheduleRerolled;
        await loadWalletSchedules();
    } catch (error) {
        if (status) status.textContent = translateBackendDetail(error.message) || locale.walletScheduleSaveError;
    } finally {
        walletScheduleMutationInFlight = false;
        if (button) { button.disabled = false; button.textContent = locale.walletScheduleReroll; }
    }
}

async function saveWalletSchedule() {
    if (!activeWalletScheduleId || walletScheduleMutationInFlight) return;
    const locale = translations[getActiveLang()];
    const status = document.getElementById('walletScheduleStatus');
    const button = document.getElementById('walletScheduleSave');
    if (!activeWalletScheduleHasProxy) {
        if (status) status.textContent = locale.walletScheduleProxyRequired;
        return;
    }
    const windowStartInput = document.getElementById('walletScheduleWindowStart');
    const windowEndInput = document.getElementById('walletScheduleWindowEnd');
    const windowStart = normalize24HourTime(windowStartInput?.value);
    const windowEnd = normalize24HourTime(windowEndInput?.value);
    const weeklyMin = Number(document.getElementById('walletScheduleWeeklyMin')?.value || 3);
    const weeklyMax = Number(document.getElementById('walletScheduleWeeklyMax')?.value || 4);
    if (walletScheduleMode === 'flexible' && (
        !windowStart || !windowEnd || windowStart >= windowEnd
        || !Number.isInteger(weeklyMin) || !Number.isInteger(weeklyMax)
        || weeklyMin < 1 || weeklyMax > 7 || weeklyMin > weeklyMax
    )) {
        if (status) status.textContent = locale.walletScheduleFlexibleInvalid;
        return;
    }
    if (walletScheduleMode === 'custom' && !walletScheduleCustomSlots.length) {
        if (status) status.textContent = locale.walletScheduleCustomEmpty;
        return;
    }
    const acknowledgement = Boolean(document.getElementById('walletScheduleAcknowledgement')?.checked);
    if (!acknowledgement) {
        if (status) status.textContent = locale.walletScheduleAcknowledgementRequired;
        return;
    }
    const payload = {
        action_type: document.getElementById('walletScheduleAction')?.value || 'dex',
        // Legacy values keep the API compatible. Flexible plans use generated
        // weekly slots; custom plans use the selected reminder slots below.
        day_of_week: 'Mon',
        time_of_day: '18:00',
        timezone: document.getElementById('walletScheduleTimezone')?.value || 'UTC',
        enabled: true,
        telegram_enabled: Boolean(document.getElementById('walletScheduleTelegram')?.checked),
        acknowledgement,
        schedule_mode: walletScheduleMode,
        weekly_min: weeklyMin,
        weekly_max: weeklyMax,
        window_start: windowStart || '10:00',
        window_end: windowEnd || '21:00',
        custom_slots: walletScheduleMode === 'custom'
            ? walletScheduleCustomSlots.map(slot => ({ day_of_week: slot.day, time_of_day: slot.time }))
            : [],
        reroll: true,
    };
    try {
        walletScheduleMutationInFlight = true;
        if (button) { button.disabled = true; button.textContent = locale.loading; }
        const response = await fetch(`/api/wallets/${activeWalletScheduleId}/schedules`, {
            method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_schedule_save_failed');
        if (status) status.textContent = locale.walletScheduleSaved;
        const consent = document.getElementById('walletScheduleAcknowledgement');
        if (consent) consent.checked = false;
        await loadWalletSchedules();
    } catch (error) {
        if (status) status.textContent = translateBackendDetail(error.message) || locale.walletScheduleSaveError;
    } finally {
        walletScheduleMutationInFlight = false;
        if (button) { button.disabled = !activeWalletScheduleHasProxy; button.textContent = locale.walletScheduleSave; }
    }
}

async function deleteWalletSchedule(scheduleId, button) {
    if (!activeWalletScheduleId || walletScheduleMutationInFlight) return;
    const locale = translations[getActiveLang()];
    const status = document.getElementById('walletScheduleStatus');
    walletScheduleMutationInFlight = true;
    if (button) { button.disabled = true; button.textContent = locale.loading; }
    try {
        const response = await fetch(`/api/wallets/${activeWalletScheduleId}/schedules/${scheduleId}`, {method: 'DELETE'});
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'wallet_schedule_delete_failed');
        if (status) status.textContent = locale.walletScheduleDeleted;
        await loadWalletSchedules();
    } catch (error) {
        if (status) status.textContent = translateBackendDetail(error.message) || locale.walletScheduleSaveError;
    } finally {
        walletScheduleMutationInFlight = false;
        if (button) { button.disabled = false; button.textContent = locale.walletScheduleDelete; }
    }
}

function areInterfaceHintsEnabled() {
    const value = localStorage.getItem('ax_interface_hints_enabled');
    if (value !== null) return value !== 'false';

    const securityBannerSetting = localStorage.getItem('hide_security_banner');
    if (securityBannerSetting !== null) return securityBannerSetting !== 'true';

    // Migrate the previous inverse setting without changing the user's choice.
    return localStorage.getItem('hide_all_banners') !== 'true';
}

function getDismissedInterfaceHints() {
    try {
        return JSON.parse(localStorage.getItem('ax_dismissed_interface_hints') || '{}');
    } catch (error) {
        return {};
    }
}

function isInterfaceHintVisible(hintId) {
    return areInterfaceHintsEnabled() && !getDismissedInterfaceHints()[hintId];
}

function dismissInterfaceHint(hintId) {
    const dismissed = getDismissedInterfaceHints();
    dismissed[hintId] = true;
    localStorage.setItem('ax_dismissed_interface_hints', JSON.stringify(dismissed));
    document.getElementById(`interfaceHint-${hintId}`)?.remove();
    document.querySelectorAll(`[data-interface-hint="${hintId}"]`).forEach((element) => {
        element.hidden = true;
    });
}

function renderInterfaceHint(hintId, message, tone = 'info', contentId = '', icon = 'ℹ') {
    if (!isInterfaceHintVisible(hintId)) return '';

    const tones = {
        info: { background: 'rgba(59,130,246,.08)', border: 'rgba(59,130,246,.34)', color: '#bfdbfe' },
        purple: { background: 'rgba(124,58,237,.10)', border: 'rgba(167,139,250,.34)', color: '#ddd6fe' },
        warning: { background: 'rgba(234,179,8,.09)', border: 'rgba(234,179,8,.38)', color: '#fde68a' },
        success: { background: 'rgba(34,197,94,.08)', border: 'rgba(34,197,94,.32)', color: '#bbf7d0' },
    };
    const style = tones[tone] || tones.info;
    const content = contentId
        ? `<span id="${contentId}">${escapeHtml(message)}</span>`
        : `<span>${escapeHtml(message)}</span>`;

    const iconHtml = icon ? `<span aria-hidden="true" style="font-size:15px; line-height:18px;">${icon}</span>` : '';
    return `<div id="interfaceHint-${hintId}" style="background:${style.background}; border:1px solid ${style.border}; color:${style.color}; padding:11px 12px; border-radius:11px; font-size:12px; line-height:1.5; margin:12px 0; display:flex; align-items:flex-start; gap:9px;">
        ${iconHtml}
        <div style="flex:1; min-width:0;">${content}</div>
        <button type="button" onclick="dismissInterfaceHint('${hintId}')" aria-label="${escapeHtml(t('interfaceHintClose'))}" title="${escapeHtml(t('interfaceHintClose'))}" style="appearance:none; border:0; background:transparent; color:inherit; cursor:pointer; font-size:18px; line-height:16px; padding:0 1px; opacity:.78;">×</button>
    </div>`;
}

function renderOperationGuide(hintId, title, message, tone = 'info') {
    if (!isInterfaceHintVisible(hintId)) return '';
    const closeLabel = (translations[getActiveLang()] || translations.ru).interfaceHintClose || 'Close';
    return `<aside id="interfaceHint-${hintId}" data-interface-hint="${hintId}" class="operation-explainer operation-explainer--${tone}" role="note">
        <b>${escapeHtml(title)}</b>
        <span>${escapeHtml(message)}</span>
        <button type="button" class="operation-explainer__close" onclick="dismissInterfaceHint('${hintId}')" aria-label="${escapeHtml(closeLabel)}" title="${escapeHtml(closeLabel)}">×</button>
    </aside>`;
}

function toggleInterfaceHints(checkbox) {
    const enabled = Boolean(checkbox.checked);
    localStorage.setItem('ax_interface_hints_enabled', String(enabled));
    localStorage.setItem('hide_security_banner', String(!enabled));
    localStorage.removeItem('hide_all_banners');
    if (enabled) localStorage.removeItem('ax_dismissed_interface_hints');

    showNotification(enabled ? t('setInterfaceHintsOn') : t('setInterfaceHintsOff'), 'success');
    renderDashboardContent(currentSection);
}

// Kept as a compatibility alias for older inline markup.
function toggleHideBanners(checkbox) {
    toggleInterfaceHints({ checked: !checkbox.checked });
}

// --- Планирование расходов и сканирование ---
function getBudgetPlanInputValue(id, fallback = 0) {
    const input = document.getElementById(id);
    const value = Number.parseFloat(input?.value);
    return Number.isFinite(value) ? value : fallback;
}

async function refreshTelegramConnectionState() {
    const statusEl = document.getElementById('telegramConnectionState');
    const testButton = document.getElementById('telegramTestButton');
    if (!statusEl) return;
    try {
        const response = await fetch('/api/telegram/status');
        const data = await response.json();
        if (!response.ok) throw new Error('status unavailable');
        statusEl.textContent = data.linked ? t('tgLinked') : t('tgNotLinked');
        statusEl.style.color = data.linked ? '#22c55e' : 'var(--text-muted)';
        if (testButton) testButton.style.display = data.linked ? 'inline-flex' : 'none';
        if (data.linked && data.filters) applyTelegramNotificationFilters(data.filters);
    } catch (error) {
        statusEl.textContent = t('tgUnavailable');
        statusEl.style.color = '#eab308';
    }
}

function applyTelegramNotificationFilters(filters) {
    const controls = {
        transactionSubmitted: ['notifTransactionSubmittedToggle', 'ax_notify_transactions_submitted'],
        transactionFinal: ['notifTransactionFinalToggle', 'ax_notify_transactions_final'],
        reminders: ['notifRemindersToggle', 'ax_notify_reminders'],
        errors: ['notifErrorsToggle', 'ax_notify_errors'],
        defiSupplySubmitted: ['notifDefiSupplySubmittedToggle', 'ax_notify_defi_supply_submitted'],
        defiWithdrawSubmitted: ['notifDefiWithdrawSubmittedToggle', 'ax_notify_defi_withdraw_submitted'],
        defiFinal: ['notifDefiFinalToggle', 'ax_notify_defi_final'],
        defiErrors: ['notifDefiErrorsToggle', 'ax_notify_defi_errors'],
    };
    Object.entries(controls).forEach(([key, [elementId, storageKey]]) => {
        if (typeof filters[key] !== 'boolean') return;
        const enabled = filters[key];
        localStorage.setItem(storageKey, String(enabled));
        const control = document.getElementById(elementId);
        if (control) control.checked = enabled;
    });
}

function applyTelegramNotificationPreset(preset) {
    const presets = {
        important: {
            transactionSubmitted: false, transactionFinal: true, reminders: true, errors: true,
            defiSupplySubmitted: false, defiWithdrawSubmitted: false, defiFinal: false, defiErrors: false,
        },
        all: {
            transactionSubmitted: true, transactionFinal: true, reminders: true, errors: true,
            defiSupplySubmitted: true, defiWithdrawSubmitted: true, defiFinal: true, defiErrors: true,
        },
        errors: {
            transactionSubmitted: false, transactionFinal: false, reminders: false, errors: true,
            defiSupplySubmitted: false, defiWithdrawSubmitted: false, defiFinal: false, defiErrors: true,
        },
    };
    const selected = presets[preset];
    if (!selected) return;
    applyTelegramNotificationFilters(selected);
    showNotification(t('notifPresetApplied'));
}

async function getWalletSecurityNetwork() {
    if (!window.ethereum?.request) return { tone: 'muted', text: t('securityNetworkUnknown') };
    try {
        const chainId = (await window.ethereum.request({ method: 'eth_chainId' }) || '').toLowerCase();
        if (chainId === '0x2105') return { tone: 'success', text: t('securityNetworkMain') };
        if (['0x14a34', '0xaa36a7'].includes(chainId)) return { tone: 'warning', text: t('securityNetworkTest') };
        return { tone: 'warning', text: t('securityNetworkOther') };
    } catch (error) {
        return { tone: 'muted', text: t('securityNetworkUnknown') };
    }
}

async function loadSecurityOverview() {
    const container = document.getElementById('securityOverviewContent');
    if (!container) return;
    container.textContent = t('loading');
    try {
        const [response, network] = await Promise.all([
            fetch('/api/security/overview'),
            getWalletSecurityNetwork(),
        ]);
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'security_overview_unavailable');
        const selectedWallet = getActiveBaseWalletAddress();
        const walletText = selectedWallet
            ? `${t('securityWalletChosen')}: ${escapeHtml(getShortOperationAddress(selectedWallet))}`
            : data.wallet_count > 0
                ? `${t('securityWalletSaved')}: ${data.wallet_count}`
                : t('securityWalletNone');
        const telegramText = data.telegram_linked ? t('securityTelegramLinked') : t('securityTelegramNone');
        const rows = [
            ['🛡️', t('securitySession'), data.session_active ? t('securitySessionActive') : t('securityUnavailable'), data.session_active ? '#86efac' : '#fca5a5'],
            ['👛', t('securityWallet'), walletText, selectedWallet || data.wallet_count > 0 ? '#86efac' : '#facc15'],
            ['✈️', t('securityTelegram'), telegramText, data.telegram_linked ? '#86efac' : 'var(--text-muted)'],
            ['🌐', t('securityNetwork'), network.text, network.tone === 'success' ? '#86efac' : network.tone === 'warning' ? '#facc15' : 'var(--text-muted)'],
        ];
        container.innerHTML = rows.map(([icon, title, value, color]) => `
            <div style="display:flex; align-items:center; gap:10px; padding:10px 0; border-bottom:1px solid var(--border-color);">
                <span style="width:22px; text-align:center;">${icon}</span>
                <span style="color:#fff; font-size:13px; flex:1;">${title}</span>
                <span style="color:${color}; font-size:12px; text-align:right;">${value}</span>
            </div>
        `).join('');
    } catch (error) {
        container.textContent = t('securityUnavailable');
        container.style.color = '#facc15';
    }
}

async function createTelegramLink() {
    const resultEl = document.getElementById('telegramLinkResult');
    if (!resultEl) return;
    resultEl.textContent = t('tgPreparingLink');
    try {
        const response = await fetch('/api/telegram/link-code', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ language: getActiveLang() })
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'link unavailable');
        resultEl.innerHTML = '';
        const instruction = document.createElement('div');
        instruction.textContent = t('tgLinkReady');
        const link = document.createElement('a');
        link.href = data.bot_link;
        link.target = '_blank';
        link.rel = 'noopener noreferrer';
        link.textContent = t('tgOpenBot');
        link.style.cssText = 'display:inline-flex; margin-top:8px; color:#c4b5fd; font-weight:600;';
        resultEl.append(instruction, link);
        showNotification(t('tgLinkReady'));
    } catch (error) {
        resultEl.textContent = t('tgUnavailable');
        showNotification(t('tgUnavailable'), 'error');
    }
}

async function sendTelegramTest() {
    try {
        const response = await fetch('/api/telegram/test', { method: 'POST' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'test failed');
        showNotification(t('tgTestSent'));
    } catch (error) {
        showNotification(translateBackendDetail(error.message, 'errors.genericRequestFailed'), 'error');
    }
}

function updateTransactionPlanEstimate() {
    const operations = Math.max(1, Math.floor(getBudgetPlanInputValue('planOperations', 1)));
    const maxCost = Math.max(0, getBudgetPlanInputValue('planMaxCost', 0));
    const reserve = Math.max(0, getBudgetPlanInputValue('planReserve', 0));
    const dailyCap = Math.max(0, getBudgetPlanInputValue('planDailyCap', 0));
    const monthlyCap = Math.max(0, getBudgetPlanInputValue('planMonthlyCap', 0));
    const plannedTotal = operations * maxCost + reserve;
    const isInvalid = maxCost > dailyCap || dailyCap > monthlyCap || plannedTotal > monthlyCap;
    const estimate = document.getElementById('planEstimateValue');
    const riskCap = document.getElementById('planRiskCapValue');
    const warning = document.getElementById('planBudgetWarning');
    const t = translations[currentLang];

    if (estimate) estimate.innerText = `$${plannedTotal.toFixed(2)}`;
    if (riskCap) riskCap.innerText = `$${monthlyCap.toFixed(2)}`;
    if (warning) {
        warning.innerText = isInvalid ? t.planInvalid : '';
        warning.style.display = isInvalid ? 'block' : 'none';
    }
    return !isInvalid;
}

async function loadTransactionPlan() {
    try {
        const response = await fetch('/api/budget-plan');
        const data = await response.json();
        if (!response.ok || !data.plan) return;
        const plan = data.plan;
        const fieldMap = {
            planNetwork: plan.network,
            planOperations: plan.planned_operations,
            planMaxCost: plan.max_cost_per_operation,
            planReserve: plan.extra_cost_reserve,
            planDailyCap: plan.daily_cap,
            planMonthlyCap: plan.monthly_cap,
        };
        Object.entries(fieldMap).forEach(([id, value]) => {
            const input = document.getElementById(id);
            if (input && value !== undefined) input.value = value;
        });
        updateTransactionPlanEstimate();
    } catch (error) {
        updateTransactionPlanEstimate();
    }
}

async function saveTransactionPlan() {
    if (!updateTransactionPlanEstimate()) {
        showNotification(translations[currentLang].planInvalid, 'error');
        return;
    }
    const payload = {
        network: document.getElementById('planNetwork')?.value || 'Base',
        planned_operations: Math.max(1, Math.floor(getBudgetPlanInputValue('planOperations', 1))),
        max_cost_per_operation: Math.max(0, getBudgetPlanInputValue('planMaxCost', 0)),
        extra_cost_reserve: Math.max(0, getBudgetPlanInputValue('planReserve', 0)),
        daily_cap: Math.max(0, getBudgetPlanInputValue('planDailyCap', 0)),
        monthly_cap: Math.max(0, getBudgetPlanInputValue('planMonthlyCap', 0)),
    };
    try {
        const response = await fetch('/api/budget-plan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        if (!response.ok) {
            showNotification(translations[currentLang].planInvalid, 'error');
            return;
        }
        showNotification(translations[currentLang].planSaved, 'success');
    } catch (error) {
        showNotification(translations[currentLang].planInvalid, 'error');
    }
}

function normalize24HourTime(value) {
    const match = String(value || '').trim().match(/^([01]?\d|2[0-3]):([0-5]\d)$/);
    if (!match) return null;
    return `${match[1].padStart(2, '0')}:${match[2]}`;
}

function format24HourTimeInput(input) {
    if (!input) return;
    const digits = input.value.replace(/\D/g, '').slice(0, 4);
    const hours = digits.slice(0, 2);
    const minutes = digits.slice(2, 4);
    input.value = minutes ? `${hours}:${minutes}` : hours;
}

function normalize24HourTimeInput(input) {
    const normalized = normalize24HourTime(input?.value);
    if (normalized) input.value = normalized;
    return Boolean(normalized);
}

function toggleActionReminderFields() {
    const enabled = document.getElementById('actionReminderEnabled')?.checked;
    const fields = document.getElementById('actionReminderFields');
    if (!fields) return;
    fields.style.opacity = enabled ? '1' : '.5';
    fields.style.pointerEvents = enabled ? 'auto' : 'none';
}

async function loadActionReminder() {
    const status = document.getElementById('actionReminderStatus');
    if (!status) return;
    const locale = translations[currentLang];
    try {
        const response = await fetch('/api/action-reminder');
        const data = await response.json();
        if (!response.ok || !data.reminder) throw new Error('action_reminder_unavailable');
        const reminder = data.reminder;
        const fieldMap = {
            actionReminderDay: reminder.day_of_week,
            actionReminderTime: reminder.time_of_day,
        };
        Object.entries(fieldMap).forEach(([id, value]) => {
            const input = document.getElementById(id);
            if (input && value !== undefined) input.value = value;
        });
        const enabled = document.getElementById('actionReminderEnabled');
        const telegram = document.getElementById('actionReminderTelegram');
        if (enabled) enabled.checked = Boolean(reminder.enabled);
        if (telegram) telegram.checked = Boolean(reminder.telegram_enabled);
        status.textContent = data.telegram_linked ? locale.planReminderTelegramLinked : locale.planReminderTelegramNotLinked;
        status.style.color = data.telegram_linked ? '#86efac' : '#fbbf24';
        toggleActionReminderFields();
    } catch (error) {
        status.textContent = locale.planReminderLoadError;
        status.style.color = '#fca5a5';
        toggleActionReminderFields();
    }
}

async function saveActionReminder() {
    const locale = translations[currentLang];
    const status = document.getElementById('actionReminderStatus');
    const timeInput = document.getElementById('actionReminderTime');
    const normalizedTime = normalize24HourTime(timeInput?.value);
    if (!normalizedTime) {
        if (status) {
            status.textContent = locale.planReminderTimeInvalid;
            status.style.color = '#fca5a5';
        }
        showNotification(locale.planReminderTimeInvalid, 'error');
        return;
    }
    timeInput.value = normalizedTime;
    const payload = {
        network: document.getElementById('planNetwork')?.value || 'Base',
        day_of_week: document.getElementById('actionReminderDay')?.value || 'Mon',
        time_of_day: normalizedTime,
        enabled: Boolean(document.getElementById('actionReminderEnabled')?.checked),
        telegram_enabled: Boolean(document.getElementById('actionReminderTelegram')?.checked),
    };
    try {
        const response = await fetch('/api/action-reminder', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'action_reminder_unavailable');
        if (status) {
            status.textContent = data.telegram_linked ? locale.planReminderSaved : locale.planReminderSavedNoTelegram;
            status.style.color = data.telegram_linked ? '#86efac' : '#fbbf24';
        }
        showNotification(locale.planReminderSaved, 'success');
    } catch (error) {
        if (status) {
            status.textContent = locale.planReminderLoadError;
            status.style.color = '#fca5a5';
        }
        showNotification(locale.planReminderLoadError, 'error');
    }
}

function getBridgeGasText(data) {
    const locale = translations[getActiveLang()];
    const level = data?.gas_level || 'unavailable';
    const levelKey = `gas${level.charAt(0).toUpperCase()}${level.slice(1)}`;
    return `${data?.gas || 'N/A'} · ${locale[levelKey] || locale.gasUnavailable}`;
}

function getOperationBuilderAmount() {
    return normalizeEthInput(document.getElementById('operationAmount')?.value || document.getElementById('bridgePlanAmount')?.value);
}

function getOperationBuilderDestination() {
    return document.getElementById('operationDestinationNetwork')?.value || document.getElementById('bridgePlanDestination')?.value || '';
}

function getOperationBuilderSource() {
    return document.getElementById('operationSourceNetwork')?.value || 'Base';
}

function formatOperationVisibleAssets(data) {
    const assets = Array.isArray(data?.visible_assets) ? data.visible_assets : [];
    return assets.map((asset) => {
        const usd = Number(asset.estimated_usd);
        const usdText = Number.isFinite(usd)
            ? ` (≈$${usd.toLocaleString(undefined, { maximumFractionDigits: 2 })})`
            : '';
        return `${asset.amount} ${asset.symbol}${usdText}`;
    }).join(' · ');
}

function getSelectedOperationAssetData() {
    const address = document.getElementById('operationSourceAsset')?.value || '';
    if (activeUniversalBridgeAsset?.token?.address?.toLowerCase() === address.toLowerCase()) {
        return activeUniversalBridgeAsset;
    }
    const assets = Array.isArray(activeOperationBalanceData?.visible_assets) ? activeOperationBalanceData.visible_assets : [];
    return assets.find((asset) => (asset.address || asset.symbol).toLowerCase() === address.toLowerCase()) || null;
}

function updateOperationSourceAssetOptions(data) {
    const select = document.getElementById('operationSourceAsset');
    if (!select) return;
    const locale = translations[getActiveLang()];
    const previousValue = select.value;
    const assets = Array.isArray(data?.visible_assets) ? data.visible_assets : [];
    if (!assets.length) {
        select.innerHTML = `<option value="">${locale.operationNoEligibleAssets}</option>`;
        select.disabled = true;
        return;
    }
    select.innerHTML = assets.map((asset) => {
        const usd = Number(asset.estimated_usd);
        const usdText = Number.isFinite(usd) ? ` · ≈$${usd.toLocaleString(undefined, { maximumFractionDigits: 2 })}` : '';
        return `<option value="${asset.symbol}">${asset.symbol}${usdText}</option>`;
    }).join('');
    select.disabled = false;
    select.value = assets.some((asset) => asset.symbol === previousValue) ? previousValue : assets[0].symbol;
}

function getUniversalBridgeToken(network, address) {
    return (universalBridgeTokensByNetwork[network] || []).find((token) => token.address?.toLowerCase() === String(address || '').toLowerCase()) || null;
}

function populateUniversalBridgeTokenSelect(elementId, network, preferredAddress = '') {
    const select = document.getElementById(elementId);
    if (!select) return null;
    const allTokens = universalBridgeTokensByNetwork[network] || [];
    const search = String(document.getElementById(`${elementId}Search`)?.value || '').trim().toLowerCase();
    const tokens = search
        ? allTokens.filter((token) => `${token.symbol} ${token.name} ${token.address}`.toLowerCase().includes(search)).slice(0, 100)
        : allTokens.filter((token) => token.is_core);
    const previous = preferredAddress || select.value;
    select.replaceChildren();
    if (!tokens.length) {
        const option = document.createElement('option');
        option.value = '';
        option.textContent = translations[getActiveLang()].universalBridgeTokensLoading;
        select.append(option);
        select.disabled = true;
        return null;
    }
    for (const token of tokens) {
        const option = document.createElement('option');
        option.value = token.address;
        const shortAddress = token.address === UNIVERSAL_BRIDGE_NATIVE_TOKEN ? '' : ` · ${token.address.slice(0, 6)}…${token.address.slice(-4)}`;
        option.textContent = `${token.symbol} · ${token.name}${shortAddress}`;
        select.append(option);
    }
    const stable = tokens.find((token) => token.symbol?.toUpperCase() === 'USDC');
    const native = tokens.find((token) => token.address?.toLowerCase() === UNIVERSAL_BRIDGE_NATIVE_TOKEN);
    const next = tokens.some((token) => token.address?.toLowerCase() === String(previous).toLowerCase())
        ? previous
        : (elementId === 'operationReceiveAsset' ? (stable || native || tokens[0])?.address : (native || stable || tokens[0])?.address);
    select.value = next || '';
    select.disabled = false;
    return getUniversalBridgeToken(network, select.value);
}

function filterUniversalBridgeTokenSelect(elementId) {
    const network = elementId === 'operationSourceAsset' ? getOperationBuilderSource() : getOperationBuilderDestination();
    populateUniversalBridgeTokenSelect(elementId, network || getOperationBuilderSource());
    activeUniversalBridgeQuote = null;
    if (elementId === 'operationSourceAsset') activeUniversalBridgeAsset = null;
    updateOperationBuilder();
}

async function loadUniversalBridgeTokens(network) {
    if (universalBridgeTokensByNetwork[network]) return universalBridgeTokensByNetwork[network];
    const response = await fetch(`/api/universal-bridge/tokens/${encodeURIComponent(network)}`);
    const data = await response.json();
    if (!response.ok || !Array.isArray(data.tokens)) throw new Error(data.detail || 'universal_bridge_tokens_unavailable');
    universalBridgeTokensByNetwork[network] = data.tokens;
    return data.tokens;
}

async function loadSelectedUniversalBridgeSourceBalance() {
    const locale = translations[getActiveLang()];
    const availability = document.getElementById('operationAmountAvailability');
    const sourceNetwork = getOperationBuilderSource();
    const address = document.getElementById('operationSourceAsset')?.value || '';
    const token = getUniversalBridgeToken(sourceNetwork, address);
    activeUniversalBridgeAsset = null;
    if (!token || !activeOperationWalletId) {
        validateOperationAmount();
        return;
    }
    if (availability) {
        availability.textContent = locale.operationAmountBalanceLoading;
        availability.style.color = 'var(--text-muted)';
    }
    try {
        const response = await fetch(`/api/wallets/${activeOperationWalletId}/universal-bridge-balance/${encodeURIComponent(sourceNetwork)}/${encodeURIComponent(token.address)}`);
        const data = await response.json();
        if (!response.ok || !data.token) throw new Error(data.detail || 'universal_bridge_balance_unavailable');
        if (sourceNetwork !== getOperationBuilderSource() || String(document.getElementById('operationSourceAsset')?.value || '').toLowerCase() !== token.address.toLowerCase()) return;
        activeUniversalBridgeAsset = {
            ...data,
            token: data.token,
            address: data.token.address,
            symbol: data.token.symbol,
            decimals: data.token.decimals,
        };
        validateOperationAmount();
    } catch (_) {
        activeUniversalBridgeAsset = null;
        if (availability) {
            availability.textContent = locale.universalBridgeBalanceUnavailable;
            availability.style.color = '#fca5a5';
        }
    }
}

async function loadUniversalBridgeTokenSelectors() {
    const locale = translations[getActiveLang()];
    const sourceNetwork = getOperationBuilderSource();
    const destinationNetwork = getOperationBuilderDestination() || sourceNetwork;
    const catalogStatus = document.getElementById('universalBridgeCatalogStatus');
    if (catalogStatus) {
        catalogStatus.textContent = locale.universalBridgeTokensLoading;
        catalogStatus.style.color = 'var(--text-muted)';
    }
    try {
        const isBaseSwapPane = localStorage.getItem('ax_activity_pane') === 'dex'
            && sourceNetwork === 'Base'
            && !document.getElementById('operationReceiveAsset');
        if (isBaseSwapPane) {
            await loadUniversalBridgeTokens('Base');
            const nativeToken = (universalBridgeTokensByNetwork.Base || []).find(
                token => token.address?.toLowerCase() === UNIVERSAL_BRIDGE_NATIVE_TOKEN
            );
            const sourceSelect = document.getElementById('operationSourceAsset');
            if (!nativeToken || !sourceSelect) throw new Error('base_native_token_unavailable');
            sourceSelect.replaceChildren();
            const option = document.createElement('option');
            option.value = nativeToken.address;
            option.textContent = `${nativeToken.symbol} · ${nativeToken.name}`;
            sourceSelect.append(option);
            sourceSelect.value = nativeToken.address;
            sourceSelect.disabled = true;
            await loadSelectedUniversalBridgeSourceBalance();
            return;
        }
        await Promise.all([loadUniversalBridgeTokens(sourceNetwork), loadUniversalBridgeTokens(destinationNetwork)]);
        populateUniversalBridgeTokenSelect('operationSourceAsset', sourceNetwork);
        populateUniversalBridgeTokenSelect('operationReceiveAsset', destinationNetwork);
        if (catalogStatus) {
            catalogStatus.textContent = locale.universalBridgeCoreTokensReady;
            catalogStatus.style.color = '#86efac';
        }
        await loadSelectedUniversalBridgeSourceBalance();
        updateOperationBuilder();
    } catch (_) {
        if (catalogStatus) {
            catalogStatus.textContent = locale.universalBridgeCatalogUnavailable;
            catalogStatus.style.color = '#fca5a5';
        }
    }
}

async function handleOperationSourceTokenChange() {
    activeUniversalBridgeQuote = null;
    await loadSelectedUniversalBridgeSourceBalance();
    updateOperationBuilder();
}

async function handleOperationDestinationNetworkChange() {
    activeUniversalBridgeQuote = null;
    const destination = getOperationBuilderDestination();
    const search = document.getElementById('operationReceiveAssetSearch');
    if (search) search.value = '';
    try {
        await loadUniversalBridgeTokens(destination);
        populateUniversalBridgeTokenSelect('operationReceiveAsset', destination);
        updateOperationBuilder();
    } catch (_) {
        const status = document.getElementById('universalBridgeCatalogStatus');
        if (status) {
            status.textContent = translations[getActiveLang()].universalBridgeCatalogUnavailable;
            status.style.color = '#fca5a5';
        }
    }
}

function handleOperationDestinationTokenChange() {
    activeUniversalBridgeQuote = null;
    updateOperationBuilder();
}

function updateOperationAmountUsd(asset = getSelectedOperationAssetData()) {
    const amountUsd = document.getElementById('operationAmountUsd');
    const amountInput = document.getElementById('operationAmount');
    if (!amountUsd || !amountInput || !asset) {
        if (amountUsd) amountUsd.textContent = '';
        return;
    }
    const amount = Number(amountInput.value);
    const unitPrice = Number(asset.unit_price_usd);
    if (!Number.isFinite(amount) || amount <= 0 || !Number.isFinite(unitPrice) || unitPrice <= 0) {
        amountUsd.textContent = '';
        return;
    }
    amountUsd.textContent = translations[getActiveLang()].operationAmountUsd
        .replace('{usd}', (amount * unitPrice).toLocaleString(undefined, {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2,
        }));
}

function hideBridgePlanSaveButton() {
    const saveButton = document.getElementById('bridgePlanSaveButton');
    if (saveButton) saveButton.style.display = 'none';
}

function validateOperationAmount() {
    const availability = document.getElementById('operationAmountAvailability');
    const amountInput = document.getElementById('operationAmount');
    if (!availability || !amountInput) return false;
    hideBridgePlanSaveButton();
    const locale = translations[getActiveLang()];
    const asset = getSelectedOperationAssetData();
    if (!asset) {
        updateOperationAmountUsd(null);
        availability.textContent = locale.operationAmountBalanceLoading;
        availability.style.color = 'var(--text-muted)';
        return false;
    }
    const available = Number(asset.available_to_send);
    const amount = Number(amountInput.value);
    updateOperationAmountUsd(asset);
    const reserve = Number(asset.gas_reserve) > 0
        ? locale.operationGasReserve.replace('{reserve}', asset.gas_reserve).replace('{symbol}', asset.symbol)
        : '';
    if (!Number.isFinite(amount) || amount <= 0) {
        availability.textContent = locale.operationAmountAvailable
            .replace('{available}', asset.available_to_send)
            .replace('{symbol}', asset.symbol)
            .replace('{reserve}', reserve);
        availability.style.color = '#bfdbfe';
        return true;
    }
    if (amount > available) {
        availability.textContent = locale.operationAmountExceeds
            .replace('{available}', asset.available_to_send)
            .replace('{symbol}', asset.symbol);
        availability.style.color = '#fca5a5';
        return false;
    }
    availability.textContent = locale.operationAmountAvailable
        .replace('{available}', asset.available_to_send)
        .replace('{symbol}', asset.symbol)
        .replace('{reserve}', reserve);
    availability.style.color = '#86efac';
    return true;
}

function useOperationMaxAmount() {
    const input = document.getElementById('operationAmount');
    const asset = getSelectedOperationAssetData();
    if (!input || !asset) return;
    input.value = asset.available_to_send;
    validateOperationAmount();
}

function handleOperationSourceNetworkChange() {
    activeOperationWalletId = null;
    activeOperationBalanceData = null;
    activeUniversalBridgeAsset = null;
    activeUniversalBridgeQuote = null;
    const search = document.getElementById('operationSourceAssetSearch');
    if (search) search.value = '';
    loadOperationBuilderWalletStatus();
}

async function loadOperationBuilderDestinationBalance(walletId = activeOperationWalletId) {
    const destinationBalance = document.getElementById('operationDestinationBalance');
    if (!destinationBalance) return;
    const locale = translations[getActiveLang()];
    const destination = getOperationBuilderDestination() || 'Base';
    if (!walletId) {
        destinationBalance.textContent = '';
        return;
    }
    if (destination === getOperationBuilderSource()) {
        destinationBalance.textContent = locale.operationDestinationSameNetwork.replace('{network}', destination);
        destinationBalance.style.color = 'var(--text-muted)';
        return;
    }

    destinationBalance.textContent = locale.operationDestinationBalanceLoading.replace('{network}', destination);
    destinationBalance.style.color = 'var(--text-muted)';
    try {
        const response = await fetch(`/api/wallets/${walletId}/network-balance/${encodeURIComponent(destination)}`);
        const data = await response.json();
        if (destination !== getOperationBuilderDestination()) return;
        if (!response.ok) {
            const isNotConfigured = response.status === 422 || String(data.detail || '').includes('not configured');
            destinationBalance.textContent = isNotConfigured
                ? locale.operationDestinationBalancePending.replace('{network}', destination)
                : locale.operationDestinationBalanceUnavailable.replace('{network}', destination);
            destinationBalance.style.color = isNotConfigured ? '#fbbf24' : '#fca5a5';
            return;
        }
        const assets = formatOperationVisibleAssets(data);
        destinationBalance.textContent = assets
            ? locale.operationDestinationBalance
                .replace('{network}', data.network)
                .replace('{assets}', assets)
            : locale.operationDestinationNoAssets.replace('{network}', data.network);
        destinationBalance.style.color = '#bfdbfe';
    } catch (_) {
        if (destination !== getOperationBuilderDestination()) return;
        destinationBalance.textContent = locale.operationDestinationBalanceUnavailable.replace('{network}', destination);
        destinationBalance.style.color = '#fca5a5';
    }
}

async function loadOperationBuilderWalletStatus() {
    const status = document.getElementById('operationWalletStatus');
    if (!status) return;
    activeOperationWalletId = null;
    activeOperationBalanceData = null;
    activeUniversalBridgeAsset = null;
    const locale = translations[getActiveLang()];
    const activeAddress = getActiveBaseWalletAddress();
    if (!/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        status.textContent = locale.operationWalletRequired;
        status.style.color = '#fbbf24';
        return;
    }
    status.textContent = locale.operationBalanceLoading;
    status.style.color = 'var(--text-muted)';
    try {
        const username = localStorage.getItem('airdrop_username');
        const walletsResponse = await fetch(`/api/wallets/${encodeURIComponent(username || '')}`);
        const walletsData = await walletsResponse.json();
        const wallet = walletsData.wallets?.find((item) => item.wallet_address?.toLowerCase() === activeAddress.toLowerCase());
        if (!wallet || !walletsResponse.ok) throw new Error('wallet_not_saved');
        activeOperationWalletId = wallet.id;
        const sessionState = await getActiveWalletSessionState(activeAddress);
        status.textContent = sessionState.matches
            ? locale.operationWalletSessionReady
                .replace('{address}', `${activeAddress.slice(0, 6)}…${activeAddress.slice(-4)}`)
                .replace('{network}', getOperationBuilderSource())
            : activeWalletConnectionMessage(sessionState, locale, activeAddress);
        status.style.color = sessionState.matches ? '#86efac' : '#fbbf24';
        await loadUniversalBridgeTokenSelectors();
    } catch (error) {
        activeOperationWalletId = null;
        activeOperationBalanceData = null;
        activeUniversalBridgeAsset = null;
        status.textContent = locale.operationBalanceUnavailable;
        status.style.color = '#fbbf24';
        validateOperationAmount();
    }
}

function updateOperationBuilder() {
    const locale = translations[getActiveLang()];
    const source = getOperationBuilderSource();
    const destination = getOperationBuilderDestination() || 'Base';
    const sourceToken = getUniversalBridgeToken(source, document.getElementById('operationSourceAsset')?.value);
    const destinationToken = getUniversalBridgeToken(destination, document.getElementById('operationReceiveAsset')?.value);
    const routeIsReady = Boolean(sourceToken && destinationToken && activeOperationWalletId);
    const swapPanel = document.getElementById('operationSwapPanel');
    const bridgePanel = document.getElementById('operationBridgePanel');
    const universalPanel = document.getElementById('universalBridgePanel');
    hideBridgePlanSaveButton();
    if (swapPanel) swapPanel.style.display = 'none';
    if (bridgePanel) bridgePanel.style.display = 'none';
    if (universalPanel) universalPanel.style.display = routeIsReady ? '' : 'none';
    const result = document.getElementById('universalBridgeResult');
    if (result && !routeIsReady) {
        result.textContent = locale.universalBridgeRouteNotReady;
        result.style.color = 'var(--text-muted)';
    }
}

function normalizeUniversalBridgeAmount(value, decimals) {
    const raw = String(value || '').trim();
    if (!/^\d+(?:\.\d+)?$/.test(raw)) return null;
    const [whole, fraction = ''] = raw.split('.');
    if (!whole || fraction.length > Number(decimals || 18)) return null;
    const normalizedWhole = whole.replace(/^0+(?=\d)/, '') || '0';
    const normalizedFraction = fraction.replace(/0+$/, '');
    if (normalizedWhole === '0' && !normalizedFraction) return null;
    return normalizedFraction ? `${normalizedWhole}.${normalizedFraction}` : normalizedWhole;
}

function getUniversalBridgeSelectedTokens() {
    const sourceNetwork = getOperationBuilderSource();
    const destinationNetwork = getOperationBuilderDestination() || sourceNetwork;
    return {
        sourceNetwork,
        destinationNetwork,
        sourceToken: getUniversalBridgeToken(sourceNetwork, document.getElementById('operationSourceAsset')?.value),
        destinationToken: getUniversalBridgeToken(destinationNetwork, document.getElementById('operationReceiveAsset')?.value),
    };
}

function setUniversalBridgeResult(message, color = 'var(--text-muted)') {
    const result = document.getElementById('universalBridgeResult');
    if (!result) return;
    result.style.display = message ? '' : 'none';
    result.textContent = message;
    result.style.color = color;
}

function openDexFromSameNetworkBridge() {
    const amount = document.getElementById('operationAmount')?.value || '';
    switchActivityPane('dex');
    window.setTimeout(() => {
        const input = document.getElementById('operationAmount');
        if (!input) return;
        input.value = amount;
        sanitizeDecimalInput(input, 18);
        validateOperationAmount();
    }, 60);
}

function showUniversalBridgeSameNetwork(network) {
    const locale = translations[getActiveLang()];
    const result = document.getElementById('universalBridgeResult');
    if (!result) return;
    result.style.display = '';
    result.style.color = '#fde68a';
    const action = network === 'Base'
        ? `<button type="button" class="btn-dark-sm" onclick="openDexFromSameNetworkBridge()" style="display:block; margin-top:9px; border-color:#7c3aed;">${escapeHtml(locale.universalBridgeOpenDex)}</button>`
        : '';
    result.innerHTML = `<span>${escapeHtml(locale.universalBridgeSameNetwork)}</span>${action}`;
}

function setUniversalBridgeReviewVisible(visible) {
    const button = document.getElementById('universalBridgeReviewButton');
    if (button) button.style.display = visible ? 'inline-flex' : 'none';
}

function quoteUniversalBridgeSummary(quote) {
    const locale = translations[getActiveLang()];
    const seconds = Number(quote?.estimated_seconds || 0);
    const timeText = Number.isFinite(seconds) && seconds > 0
        ? locale.universalBridgeEstimatedTime.replace('{minutes}', Math.max(1, Math.ceil(seconds / 60)))
        : '';
    return locale.universalBridgeQuoteReady
        .replace('{from}', `${quote.amount_in} ${quote.from_token.symbol}`)
        .replace('{to}', `${quote.amount_out} ${quote.to_token.symbol}`)
        .replace('{minimum}', `${quote.amount_out_min} ${quote.to_token.symbol}`)
        .replace('{tool}', quote.tool || 'LI.FI')
        .replace('{time}', timeText);
}

async function requestUniversalBridgeQuote() {
    const locale = translations[getActiveLang()];
    const button = document.getElementById('universalBridgeQuoteButton');
    const activeAddress = getActiveBaseWalletAddress();
    const { sourceNetwork, destinationNetwork, sourceToken, destinationToken } = getUniversalBridgeSelectedTokens();
    const amount = normalizeUniversalBridgeAmount(document.getElementById('operationAmount')?.value, sourceToken?.decimals);
    activeUniversalBridgeQuote = null;
    setUniversalBridgeReviewVisible(false);
    if (sourceNetwork === destinationNetwork) {
        showUniversalBridgeSameNetwork(sourceNetwork);
        return;
    }
    if (!sourceToken || !destinationToken || !amount || !validateOperationAmount() || !/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        setUniversalBridgeResult(locale.universalBridgeInvalid, '#fca5a5');
        return;
    }
    const connectionState = await getActiveWalletSessionState(activeAddress);
    if (!connectionState.matches) {
        const message = activeWalletConnectionMessage(connectionState, locale, activeAddress);
        const status = document.getElementById('operationWalletStatus');
        if (status) {
            status.textContent = message;
            status.style.color = '#fbbf24';
        }
        setUniversalBridgeResult(message, '#fca5a5');
        return;
    }
    try {
        setButtonLoading(button, true, locale.universalBridgeQuoteLoading);
        setUniversalBridgeResult(locale.universalBridgeQuoteLoading, '#bfdbfe');
        const response = await fetch('/api/universal-bridge/quote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                wallet_address: activeAddress,
                from_network: sourceNetwork,
                to_network: destinationNetwork,
                from_token_address: sourceToken.address,
                to_token_address: destinationToken.address,
                amount,
            }),
        });
        const data = await response.json();
        if (!response.ok || !data.transaction) throw new Error(data.detail || 'universal_bridge_quote_unavailable');
        data.expires_at = Date.now() + (Number(data.expires_in || 55) * 1000);
        activeUniversalBridgeQuote = data;
        setUniversalBridgeResult(quoteUniversalBridgeSummary(data), '#86efac');
        setUniversalBridgeReviewVisible(true);
    } catch (error) {
        setUniversalBridgeResult(operationErrorMessage(error, locale, locale.universalBridgeQuoteUnavailable), '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.universalBridgeGetQuote);
    }
}

function makeErc20AllowanceCallData(owner, spender) {
    return `0xdd62ed3e${owner.slice(2).toLowerCase().padStart(64, '0')}${spender.slice(2).toLowerCase().padStart(64, '0')}`;
}

function makeErc20ApproveCallData(spender, amountAtomic) {
    return `0x095ea7b3${spender.slice(2).toLowerCase().padStart(64, '0')}${BigInt(amountAtomic).toString(16).padStart(64, '0')}`;
}

async function waitForUniversalBridgeReceipt(provider, txHash) {
    for (let attempt = 0; attempt < 30; attempt += 1) {
        const receipt = await provider.request({ method: 'eth_getTransactionReceipt', params: [txHash] });
        if (receipt) {
            if (String(receipt.status || '').toLowerCase() === '0x0') throw new Error('universal_bridge_approval_failed');
            return receipt;
        }
        await new Promise((resolve) => setTimeout(resolve, 4000));
    }
    throw new Error('universal_bridge_approval_pending');
}

async function getFreshUniversalBridgeQuote() {
    await requestUniversalBridgeQuote();
    if (!activeUniversalBridgeQuote) throw new Error('universal_bridge_quote_unavailable');
    return activeUniversalBridgeQuote;
}

async function ensureUniversalBridgeApproval(provider, quote, fromAddress) {
    const approval = quote?.approval || {};
    if (!approval.required) return quote;
    const tokenAddress = quote?.from_token?.address;
    const spender = approval.spender;
    if (!/^0x[0-9a-fA-F]{40}$/.test(tokenAddress || '') || !/^0x[0-9a-fA-F]{40}$/.test(spender || '')) {
        throw new Error('universal_bridge_approval_invalid');
    }
    await switchToUniversalBridgeNetwork(provider, quote.from_network);
    const allowanceHex = await provider.request({
        method: 'eth_call',
        params: [{ to: tokenAddress, data: makeErc20AllowanceCallData(fromAddress, spender) }, 'latest'],
    });
    let allowance = 0n;
    try { allowance = BigInt(allowanceHex || '0x0'); } catch (_) { throw new Error('universal_bridge_allowance_unavailable'); }
    if (allowance >= BigInt(approval.amount_atomic)) return quote;
    if (!await openUniversalBridgeConfirmation(quote, true)) throw new Error('universal_bridge_cancelled');
    setUniversalBridgeResult(translations[getActiveLang()].universalBridgeApprovalSigning, '#bfdbfe');
    const approvalTxHash = await provider.request({
        method: 'eth_sendTransaction',
        params: [{
            from: fromAddress,
            to: tokenAddress,
            data: makeErc20ApproveCallData(spender, approval.amount_atomic),
            value: '0x0',
        }],
    });
    setUniversalBridgeResult(translations[getActiveLang()].universalBridgeApprovalWaiting, '#bfdbfe');
    await waitForUniversalBridgeReceipt(provider, approvalTxHash);
    return getFreshUniversalBridgeQuote();
}

function universalBridgeTransactionParams(quote, fromAddress) {
    const tx = quote?.transaction || {};
    const expected = UNIVERSAL_BRIDGE_NETWORKS[quote?.from_network];
    if (
        !expected
        || Number(tx.chain_id) !== parseInt(expected.chainId, 16)
        || String(tx.from || '').toLowerCase() !== fromAddress.toLowerCase()
        || !/^0x[0-9a-fA-F]{40}$/.test(String(tx.to || ''))
        || !/^0x(?:[a-fA-F0-9]{2})*$/.test(String(tx.data || ''))
        || !/^(?:0|[1-9]\d*|0x[0-9a-fA-F]+)$/.test(String(tx.value || '0'))
    ) throw new Error('universal_bridge_transaction_invalid');
    return {
        from: fromAddress,
        to: tx.to,
        data: tx.data,
        value: `0x${BigInt(tx.value || '0').toString(16)}`,
    };
}

function getUniversalBridgeRecordStatus(record) {
    const locale = translations[getActiveLang()];
    const status = String(record?.status || 'submitted');
    const statusKeys = {
        submitted: 'universalBridgeStatusSubmitted',
        in_progress: 'universalBridgeStatusInProgress',
        completed: 'universalBridgeStatusCompleted',
        failed: 'universalBridgeStatusFailed',
    };
    const colors = {
        submitted: '#bfdbfe',
        in_progress: '#fde68a',
        completed: '#86efac',
        failed: '#fca5a5',
    };
    return {
        key: status,
        label: locale[statusKeys[status]] || status,
        color: colors[status] || 'var(--text-muted)',
    };
}

function getUniversalBridgeExplorerUrl(record) {
    const explorer = UNIVERSAL_BRIDGE_NETWORKS[record?.from_network]?.blockExplorerUrls?.[0];
    const txHash = String(record?.tx_hash || '');
    if (!explorer || !/^0x[a-fA-F0-9]{64}$/.test(txHash)) return '';
    return `${explorer.replace(/\/$/, '')}/tx/${encodeURIComponent(txHash)}`;
}

function scheduleUniversalBridgeRefresh(recordId, delay = 15000) {
    clearTimeout(universalBridgeRefreshTimer);
    universalBridgeRefreshTimer = setTimeout(async () => {
        if (!document.getElementById('universalBridgeHistory')) return;
        await refreshUniversalBridgeHistoryRecord(recordId, true);
    }, delay);
}

function getUniversalBridgeRefreshCooldown(recordId) {
    const expiresAt = Number(universalBridgeRefreshCooldowns.get(String(recordId)) || 0);
    const remaining = Math.max(0, expiresAt - Date.now());
    if (!remaining) universalBridgeRefreshCooldowns.delete(String(recordId));
    return remaining;
}

function scheduleUniversalBridgeCooldownRepaint(delay) {
    clearTimeout(universalBridgeCooldownTimer);
    universalBridgeCooldownTimer = setTimeout(() => {
        if (document.getElementById('universalBridgeHistory')) loadUniversalBridgeHistory();
    }, Math.max(250, delay + 50));
}

function setUniversalBridgeRefreshButtonLoading(button, loading) {
    if (!button) return;
    const locale = translations[getActiveLang()];
    if (!loading) {
        button.disabled = false;
        button.style.opacity = '';
        button.style.cursor = '';
        button.style.display = '';
        button.style.alignItems = '';
        button.style.gap = '';
        button.textContent = locale.universalBridgeRefresh;
        return;
    }
    button.disabled = true;
    button.style.opacity = '.82';
    button.style.cursor = 'wait';
    button.style.display = 'inline-flex';
    button.style.alignItems = 'center';
    button.style.gap = '5px';
    button.replaceChildren();
    const spinner = document.createElement('span');
    spinner.setAttribute('aria-hidden', 'true');
    spinner.textContent = '↻';
    spinner.style.cssText = 'display:inline-block; font-size:14px; line-height:12px; animation:button-loading-spinner .75s linear infinite;';
    const label = document.createElement('span');
    label.textContent = locale.universalBridgeRefreshing;
    button.append(spinner, label);
}

async function loadUniversalBridgeHistory() {
    const locale = translations[getActiveLang()];
    const container = document.getElementById('universalBridgeHistory');
    if (!container) return;
    clearTimeout(universalBridgeRefreshTimer);
    try {
        const response = await fetch('/api/universal-bridge/history');
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.records)) throw new Error('universal_bridge_history_unavailable');
        if (!data.records.length) {
            container.innerHTML = renderAppEmptyState(locale.emptyStateBridgeTitle, locale.universalBridgeHistoryEmpty);
            return;
        }
        container.innerHTML = data.records.map((record) => {
            const status = getUniversalBridgeRecordStatus(record);
            const txUrl = getUniversalBridgeExplorerUrl(record);
            const date = new Date(Number(record.created_at) * 1000).toLocaleString();
            const received = record.amount_out ? `≈ ${escapeHtml(record.amount_out)} ${escapeHtml(record.to_symbol)}` : '—';
            const providerStatus = record.provider_status ? ` · ${escapeHtml(record.provider_status)}` : '';
            const cooldownMs = getUniversalBridgeRefreshCooldown(record.id);
            const cooldownSeconds = Math.max(1, Math.ceil(cooldownMs / 1000));
            const refreshButton = status.key === 'completed'
                ? ''
                : `<button type="button" onclick="refreshUniversalBridgeHistoryRecord(${Number(record.id)}, false, this)" class="btn-dark-sm" ${cooldownMs ? 'disabled' : ''} style="padding:5px 8px; font-size:11px; ${cooldownMs ? 'opacity:.55; cursor:not-allowed;' : ''}">${cooldownMs ? locale.universalBridgeRefreshCooldown.replace('{seconds}', cooldownSeconds) : locale.universalBridgeRefresh}</button>`;
            return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:10px 11px; margin-top:8px;">
                <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:10px;">
                    <div style="min-width:0;"><div style="color:#fff; font-size:12px; font-weight:600;">${escapeHtml(record.amount_in)} ${escapeHtml(record.from_symbol)} → ${received}</div><div style="color:var(--text-muted); font-size:11px; margin-top:4px;">${escapeHtml(record.from_network)} → ${escapeHtml(record.to_network)} · ${escapeHtml(date)} · ${escapeHtml(record.provider || 'LI.FI')}</div><div style="color:${status.color}; font-size:11px; margin-top:4px;">${escapeHtml(status.label)}${providerStatus}</div></div>
                    <div style="display:flex; flex-direction:column; align-items:flex-end; gap:7px; flex:0 0 auto;">
                        ${refreshButton}
                        ${txUrl ? `<a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd; font-size:11px; white-space:nowrap;">${locale.universalBridgeOpenTx}</a>` : ''}
                    </div>
                </div>
            </div>`;
        }).join('');
        const pending = data.records.find((record) => ['submitted', 'in_progress'].includes(record.status));
        if (pending) scheduleUniversalBridgeRefresh(pending.id);
        const activeCooldowns = data.records.map((record) => getUniversalBridgeRefreshCooldown(record.id)).filter(Boolean);
        if (activeCooldowns.length) scheduleUniversalBridgeCooldownRepaint(Math.min(...activeCooldowns));
    } catch (_) {
        container.innerHTML = `<div style="color:#fca5a5; font-size:12px;">${locale.universalBridgeProviderUnavailable}</div>`;
    }
}

function setOperationsJournalFilter(filter) {
    if (!['all', 'pending', 'completed', 'failed'].includes(filter)) return;
    operationsJournalFilter = filter;
    renderDashboardContent('Farming');
}

function setOperationsJournalTypeFilter(value) {
    if (!['all', 'bridge', 'swap', 'lending', 'transfer'].includes(value)) return;
    operationsJournalTypeFilter = value;
    loadOperationsJournal();
}

function setOperationsJournalWalletFilter(value) {
    if (value !== 'all' && !/^0x[0-9a-fA-F]{40}$/.test(value || '')) return;
    operationsJournalWalletFilter = value;
    loadOperationsJournal();
}

async function loadOperationsJournalWalletOptions() {
    const select = document.getElementById('operationsJournalWalletFilter');
    if (!select) return;
    const locale = translations[getActiveLang()];
    const username = getCurrentUsername();
    if (!username) return;
    try {
        const response = await fetch(`/api/wallets/${encodeURIComponent(username)}`);
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.wallets)) throw new Error('wallets_unavailable');
        select.replaceChildren();
        const allOption = document.createElement('option');
        allOption.value = 'all';
        allOption.textContent = locale.operationsJournalWalletAll;
        select.append(allOption);
        data.wallets.forEach((wallet) => {
            const address = String(wallet.wallet_address || '');
            if (!/^0x[0-9a-fA-F]{40}$/.test(address)) return;
            const option = document.createElement('option');
            option.value = address;
            const fallback = `${address.slice(0, 6)}…${address.slice(-4)}`;
            option.textContent = wallet.label ? `${wallet.label} · ${fallback}` : fallback;
            select.append(option);
        });
        const canKeep = [...select.options].some((option) => option.value.toLowerCase() === String(operationsJournalWalletFilter).toLowerCase());
        select.value = canKeep ? operationsJournalWalletFilter : 'all';
        operationsJournalWalletFilter = select.value;
    } catch (_) {
        select.style.display = 'none';
    }
}

function setOperationsJournalCheckButtonLoading(button, loading) {
    if (!button) return;
    const locale = translations[getActiveLang()];
    if (!loading) {
        button.disabled = false;
        button.style.opacity = '';
        button.style.cursor = '';
        button.style.display = '';
        button.style.alignItems = '';
        button.style.gap = '';
        button.textContent = locale.operationsJournalCheckPending;
        return;
    }
    button.disabled = true;
    button.style.opacity = '.82';
    button.style.cursor = 'wait';
    button.style.display = 'inline-flex';
    button.style.alignItems = 'center';
    button.style.gap = '5px';
    button.replaceChildren();
    const spinner = document.createElement('span');
    spinner.setAttribute('aria-hidden', 'true');
    spinner.textContent = '↻';
    spinner.style.cssText = 'display:inline-block; font-size:14px; line-height:12px; animation:button-loading-spinner .75s linear infinite;';
    const label = document.createElement('span');
    label.textContent = locale.operationsJournalChecking;
    button.append(spinner, label);
}

async function checkPendingOperations(button) {
    if (Date.now() < operationsJournalCheckCooldownUntil) return;
    operationsJournalCheckCooldownUntil = Date.now() + 12000;
    setOperationsJournalCheckButtonLoading(button, true);
    try {
        const response = await fetch('/api/universal-bridge/history');
        const data = await response.json();
        if (response.ok && Array.isArray(data.records)) {
            const pendingBridges = data.records.filter((record) => ['submitted', 'in_progress'].includes(record.status)).slice(0, 10);
            for (const record of pendingBridges) {
                await refreshUniversalBridgeHistoryRecord(record.id, true);
            }
        }
        await loadOperationsJournal();
    } catch (_) {
        await loadOperationsJournal();
    } finally {
        window.setTimeout(() => {
            const refreshedButton = document.getElementById('operationsJournalCheckButton');
            setOperationsJournalCheckButtonLoading(refreshedButton, false);
        }, Math.max(0, operationsJournalCheckCooldownUntil - Date.now()));
    }
}

async function loadDefiOverview(refresh = false) {
    const locale = translations[getActiveLang()];
    const panel = document.getElementById('defiOverviewPanel');
    const button = document.getElementById('defiRefreshButton');
    if (!panel) return;
    if (button) {
        button.disabled = true;
        button.style.opacity = '.72';
        button.style.cursor = 'wait';
    }
    panel.innerHTML = `<span style="color:var(--text-muted); font-size:13px;">${escapeHtml(locale.defiLoading)}</span>`;
    try {
        const activeAddress = getActiveBaseWalletAddress().toLowerCase();
        if (!activeAddress) throw new Error('wallet_required');
        const username = localStorage.getItem('airdrop_username') || '';
        const walletsResponse = await fetch(`/api/wallets/${encodeURIComponent(username)}`);
        const walletsData = await walletsResponse.json();
        if (!walletsResponse.ok || !Array.isArray(walletsData.wallets)) throw new Error('wallet_required');
        const savedWallet = walletsData.wallets.find((wallet) => String(wallet.wallet_address || '').toLowerCase() === activeAddress);
        if (!savedWallet) throw new Error('wallet_required');

        const response = await fetch(`/api/defi/aave-base-positions/${Number(savedWallet.id)}${refresh ? '?refresh=true' : ''}`);
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.positions)) throw new Error(data.detail || 'defi_load_failed');
        if (!data.positions.length) {
            panel.innerHTML = `<div style="color:var(--text-muted); font-size:13px; padding:4px 0;">${escapeHtml(locale.defiNoPositions)}</div>`;
            return;
        }
        panel.innerHTML = data.positions.map((position) => {
            const supply = position.has_supply
                ? `<div><div style="color:var(--text-muted); font-size:11px;">${escapeHtml(locale.defiSupplied)}</div><div style="color:#86efac; font-weight:700; margin-top:3px;">${escapeHtml(position.supplied)} ${escapeHtml(position.asset)}</div></div>`
                : '';
            const borrow = position.has_borrow
                ? `<div><div style="color:var(--text-muted); font-size:11px;">${escapeHtml(locale.defiBorrowed)}</div><div style="color:#fca5a5; font-weight:700; margin-top:3px;">${escapeHtml(position.borrowed)} ${escapeHtml(position.asset)}</div></div>`
                : '';
            const collateral = position.has_supply && position.collateral_enabled
                ? `<span style="color:#c4b5fd; font-size:11px; border:1px solid rgba(196,181,253,.38); border-radius:999px; padding:3px 7px;">${escapeHtml(locale.defiCollateral)}</span>`
                : '';
            const withdraw = position.has_supply && String(position.asset || '').toUpperCase() === 'USDC'
                ? `<div id="aaveWithdrawPanel" style="margin-top:12px;"><button type="button" onclick="showAaveUsdcWithdrawForm('${escapeHtml(position.supplied)}')" class="btn-dark-sm" style="padding:7px 10px; font-size:12px; border-color:#7c3aed;">${escapeHtml(locale.defiWithdrawOpen)}</button></div>`
                : '';
            return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:11px 12px; margin-top:8px;"><div style="display:flex; justify-content:space-between; gap:10px; align-items:center;"><div style="color:#fff; font-size:13px; font-weight:700;">${escapeHtml(position.asset)}</div>${collateral}</div><div style="display:flex; flex-wrap:wrap; gap:20px; margin-top:10px;">${supply}${borrow}</div>${withdraw}</div>`;
        }).join('');
    } catch (error) {
        const message = error.message === 'wallet_required' ? locale.defiWalletRequired : locale.defiLoadError;
        panel.innerHTML = `<div style="color:#fca5a5; font-size:13px; line-height:1.45;">${escapeHtml(message)}</div>`;
    } finally {
        if (button) {
            button.disabled = false;
            button.style.opacity = '';
            button.style.cursor = '';
        }
    }
}

async function loadAaveDefiHistory() {
    const locale = translations[getActiveLang()];
    const panel = document.getElementById('defiHistoryPanel');
    if (!panel) return;
    try {
        const response = await fetch('/api/defi/aave-base/history');
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.records)) throw new Error('defi_history_unavailable');
        if (!data.records.length) {
            panel.innerHTML = `<div style="color:var(--text-muted); font-size:12px; line-height:1.45;">${escapeHtml(locale.defiHistoryEmpty)}</div>`;
            return;
        }
        panel.innerHTML = data.records.map((record) => {
            const status = getOperationsJournalStatus(record);
            const action = String(record.operation_type) === 'withdraw'
                ? locale.defiHistoryWithdraw
                : locale.defiHistorySupply;
            const date = new Date(Number(record.created_at) * 1000).toLocaleString();
            const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(record.tx_hash)}`;
            return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:10px 11px; margin-top:8px; display:flex; justify-content:space-between; gap:10px; align-items:flex-start;"><div style="min-width:0;"><div style="color:#fff; font-size:12px; font-weight:700;">${escapeHtml(action)} · ${escapeHtml(record.amount)} ${escapeHtml(record.asset_symbol || 'USDC')}</div><div style="color:var(--text-muted); font-size:11px; margin-top:4px;">${escapeHtml(record.protocol || 'Aave V3')} · ${escapeHtml(record.network || 'Base')} · ${escapeHtml(date)}</div><div style="color:${status.color}; font-size:11px; margin-top:4px;">${escapeHtml(status.label)}</div></div><a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd; font-size:11px; white-space:nowrap; flex:0 0 auto;">${escapeHtml(locale.defiHistoryOpenTx)}</a></div>`;
        }).join('');
    } catch (_) {
        panel.innerHTML = `<div style="color:#fca5a5; font-size:12px;">${escapeHtml(locale.defiHistoryLoadError)}</div>`;
    }
}

function normalizeUsdcInput(value) {
    const input = String(value || '').trim();
    if (!/^\d+(?:\.\d{1,6})?$/.test(input)) return null;
    const [wholePart, fractionPart = ''] = input.split('.');
    const whole = wholePart.replace(/^0+(?=\d)/, '') || '0';
    const fraction = fractionPart.replace(/0+$/, '');
    const normalized = fraction ? `${whole}.${fraction}` : whole;
    return normalized === '0' ? null : normalized;
}

function aaveSupplyResult(message, color = 'var(--text-muted)') {
    const result = document.getElementById('aaveSupplyResult');
    if (result) result.innerHTML = `<span style="color:${color};">${escapeHtml(message)}</span>`;
}

async function requestAaveUsdcSupplyQuote() {
    const locale = translations[getActiveLang()];
    const amount = normalizeUsdcInput(document.getElementById('aaveSupplyAmount')?.value);
    const activeAddress = getActiveBaseWalletAddress();
    const button = document.getElementById('aaveSupplyQuoteButton');
    const result = document.getElementById('aaveSupplyResult');
    activeAaveSupplyQuote = null;
    if (!amount) {
        aaveSupplyResult(locale.defiSupplyInvalid, '#fca5a5');
        return;
    }
    if (!/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        aaveSupplyResult(locale.defiSupplyWalletRequired, '#fca5a5');
        return;
    }
    const connectionState = await getActiveWalletSessionState(activeAddress);
    if (!connectionState.matches) {
        aaveSupplyResult(activeWalletConnectionMessage(connectionState, locale, activeAddress), '#fca5a5');
        return;
    }
    try {
        setButtonLoading(button, true, locale.defiSupplyLoading);
        const response = await fetch('/api/defi/aave-base/usdc-supply-quote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ wallet_address: activeAddress, amount }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'aave_supply_quote_failed');
        activeAaveSupplyQuote = setAaveQuoteExpiry(data);
        const ratePercent = Number(data.annual_supply_rate_percent || 0);
        const rate = ratePercent.toLocaleString(undefined, { maximumFractionDigits: 4 });
        const suppliedAmount = Number(data.amount);
        const annualInterest = suppliedAmount * ratePercent / 100;
        const estimatedTotal = suppliedAmount + annualInterest;
        const displayUsdc = (value) => Number(value).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 6 });
        const yearlyEstimate = Number.isFinite(annualInterest) && annualInterest >= 0 && Number.isFinite(estimatedTotal)
            ? `<div style="background:rgba(124,58,237,.08); border:1px solid rgba(124,58,237,.3); border-radius:10px; padding:10px 11px; margin-top:10px;"><div style="color:#e9d5ff; font-size:11px; font-weight:700;">${escapeHtml(locale.defiSupplyYearEstimate)}</div><div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:9px; margin-top:8px;"><div><div style="color:var(--text-muted); font-size:10px;">${escapeHtml(locale.defiSupplyYearInterest)}</div><div style="color:#86efac; font-size:13px; font-weight:700; margin-top:3px;">≈ ${escapeHtml(displayUsdc(annualInterest))} USDC</div></div><div><div style="color:var(--text-muted); font-size:10px;">${escapeHtml(locale.defiSupplyYearTotal)}</div><div style="color:#fff; font-size:13px; font-weight:700; margin-top:3px;">≈ ${escapeHtml(displayUsdc(estimatedTotal))} USDC</div></div></div><div style="color:var(--text-muted); font-size:10px; line-height:1.4; margin-top:8px;">${escapeHtml(locale.defiSupplyYearNote)}</div></div>`
            : '';
        const approval = data.approval?.required ? `<div style="color:#fde68a; margin-top:5px;">${escapeHtml(locale.defiSupplyNeedsApproval)}</div>` : '';
        const gasWarning = data.gas_reserve_met ? '' : `<div style="color:#fca5a5; margin-top:5px;">${escapeHtml(locale.defiSupplyNoGas.replace('{amount}', data.gas_reserve || ''))}</div>`;
        if (result) {
            result.innerHTML = `<div style="color:#86efac; font-weight:600;">${escapeHtml(locale.defiSupplyReady.replace('{amount}', data.amount))}</div><div style="color:var(--text-muted); margin-top:5px;">${escapeHtml(locale.defiSupplyAvailable.replace('{amount}', data.wallet_balance))}</div><div style="color:#c4b5fd; margin-top:4px;">${escapeHtml(locale.defiSupplyRate)}: ${escapeHtml(rate)}%</div>${yearlyEstimate}${approval}${gasWarning}${data.gas_reserve_met ? `<button type="button" id="aaveSupplyReviewButton" onclick="submitAaveUsdcSupply()" class="btn-purple-lg" style="font-size:13px; padding:10px 14px; width:auto; margin-top:11px;">${escapeHtml(locale.defiSupplyReview)}</button>` : ''}`;
        }
    } catch (error) {
        const message = String(error?.message || '');
        const display = message.includes('exceeds the wallet balance')
            ? locale.defiSupplyInsufficientBalance
            : (message.includes('Aave USDC supply is temporarily unavailable') ? locale.defiSupplyUnavailable : locale.defiSupplyQuoteError);
        aaveSupplyResult(operationErrorMessage(error, locale, display), '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.defiSupplyCheck);
    }
}

function validateAaveSupplyTransaction(quote, fromAddress) {
    const transaction = quote?.transaction || {};
    const asset = quote?.asset || {};
    if (!window.ethers?.utils?.Interface) return false;
    try {
        const contract = new window.ethers.utils.Interface([
            'function supply(address asset, uint256 amount, address onBehalfOf, uint16 referralCode)',
        ]);
        const expectedData = contract.encodeFunctionData('supply', [
            asset.address,
            String(quote.amount_atomic),
            fromAddress,
            0,
        ]).toLowerCase();
        return transaction.chain_id === 8453
            && String(transaction.from || '').toLowerCase() === fromAddress.toLowerCase()
            && String(transaction.to || '').toLowerCase() === String(quote.pool_address || '').toLowerCase()
            && String(transaction.data || '').toLowerCase() === expectedData
            && String(transaction.value || '0') === '0';
    } catch (_) {
        return false;
    }
}

async function waitForAaveSupplyApproval(provider, txHash) {
    for (let attempt = 0; attempt < 25; attempt += 1) {
        const receipt = await provider.request({ method: 'eth_getTransactionReceipt', params: [txHash] });
        if (receipt) {
            if (String(receipt.status || '').toLowerCase() === '0x0') throw new Error('aave_supply_approval_failed');
            return;
        }
        await new Promise((resolve) => window.setTimeout(resolve, 2500));
    }
    throw new Error('aave_supply_approval_pending');
}

async function submitAaveUsdcSupply() {
    const locale = translations[getActiveLang()];
    const quote = activeAaveSupplyQuote;
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    const button = document.getElementById('aaveSupplyReviewButton');
    if (!quote || !provider?.request) {
        aaveSupplyResult(locale.defiSupplyExpired, '#fca5a5');
        return;
    }
    if (!isAaveQuoteFresh(quote)) {
        activeAaveSupplyQuote = null;
        aaveSupplyResult(locale.defiSupplyExpired, '#fbbf24');
        return;
    }
    try {
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts.length) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const activeAddress = getActiveBaseWalletAddress();
        const fromAddress = (accounts || []).find((account) => String(account || '').toLowerCase() === activeAddress.toLowerCase());
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '')) throw new Error('aave_supply_wallet_mismatch');
        if (!validateAaveSupplyTransaction(quote, fromAddress)) throw new Error('aave_supply_transaction_invalid');
        await switchToBaseMainnet(provider);
        setButtonLoading(button, true, locale.defiSupplyPreparing);
        if (quote.approval?.required) {
            if (!await openAaveSupplyConfirmation(quote, true)) return;
            setButtonLoading(button, true, locale.defiSupplyApprovalSigning);
            const approvalHash = await provider.request({
                method: 'eth_sendTransaction',
                params: [{
                    from: fromAddress,
                    to: quote.asset.address,
                    data: makeErc20ApproveCallData(quote.pool_address, quote.approval.amount_atomic),
                    value: '0x0',
                }],
            });
            aaveSupplyResult(locale.defiSupplyApprovalWaiting, '#bfdbfe');
            await waitForAaveSupplyApproval(provider, approvalHash);
            if (!isAaveQuoteFresh(quote)) {
                activeAaveSupplyQuote = null;
                aaveSupplyResult(locale.defiSupplyExpired, '#fbbf24');
                return;
            }
        }
        if (!await openAaveSupplyConfirmation(quote, false)) return;
        if (!isAaveQuoteFresh(quote)) {
            activeAaveSupplyQuote = null;
            aaveSupplyResult(locale.defiSupplyExpired, '#fbbf24');
            return;
        }
        setButtonLoading(button, true, locale.defiSupplySigning);
        const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: fromAddress, to: quote.transaction.to, data: quote.transaction.data, value: '0x0' }],
        });
        activeAaveSupplyQuote = null;
        try {
            const submissionResponse = await fetch('/api/defi/aave-base/supply-submissions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ quote_id: quote.quote_id, tx_hash: txHash }),
            });
            if (submissionResponse.ok) await loadAaveDefiHistory();
        } catch (_) {
            // The wallet transaction remains valid even if the optional notification fails.
        }
        const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(txHash)}`;
        const result = document.getElementById('aaveSupplyResult');
        if (result) result.innerHTML = `<span style="color:#86efac;">${escapeHtml(locale.defiSupplySubmitted)}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${escapeHtml(locale.defiSupplyOpenExplorer)}</a>`;
        window.setTimeout(() => {
            loadDefiOverview(true);
            loadLendingPositions(true);
        }, 7000);
    } catch (error) {
        const rejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        const message = String(error?.message || '');
        const display = message.includes('approval_pending')
            ? locale.defiSupplyApprovalPending
            : (message.includes('quote_expired')
                ? locale.defiSupplyExpired
                : (message.includes('wallet_mismatch') ? locale.defiSupplyWalletRequired : locale.defiSupplyFailed));
        aaveSupplyResult(rejected ? locale.defiSupplyRejected : operationErrorMessage(error, locale, display), '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.defiSupplyReview);
    }
}

function showAaveUsdcWithdrawForm(positionAmount) {
    const locale = translations[getActiveLang()];
    const panel = document.getElementById('aaveWithdrawPanel');
    if (!panel) return;
    activeAaveWithdrawQuote = null;
    panel.innerHTML = `<div style="border-top:1px solid var(--border-color); margin-top:10px; padding-top:11px;"><label style="display:block; color:var(--text-muted); font-size:11px;">${escapeHtml(locale.defiWithdrawAmount)}<input id="aaveWithdrawAmount" inputmode="decimal" value="${escapeHtml(positionAmount)}" oninput="sanitizeDecimalInput(this, 6)" class="auth-input" style="margin-top:5px; padding:8px 10px; font-size:12px;"></label><button type="button" id="aaveWithdrawQuoteButton" onclick="requestAaveUsdcWithdrawQuote()" class="btn-dark-sm" style="padding:8px 11px; font-size:12px; margin-top:9px; border-color:#7c3aed;">${escapeHtml(locale.defiWithdrawCheck)}</button><div id="aaveWithdrawResult" style="font-size:12px; line-height:1.5; margin-top:9px;"></div></div>`;
}

function aaveWithdrawResult(message, color = 'var(--text-muted)') {
    const result = document.getElementById('aaveWithdrawResult');
    if (result) result.innerHTML = `<span style="color:${color};">${escapeHtml(message)}</span>`;
}

async function requestAaveUsdcWithdrawQuote() {
    const locale = translations[getActiveLang()];
    const amount = normalizeUsdcInput(document.getElementById('aaveWithdrawAmount')?.value);
    const activeAddress = getActiveBaseWalletAddress();
    const button = document.getElementById('aaveWithdrawQuoteButton');
    const result = document.getElementById('aaveWithdrawResult');
    activeAaveWithdrawQuote = null;
    if (!amount) {
        aaveWithdrawResult(locale.defiWithdrawInvalid, '#fca5a5');
        return;
    }
    if (!/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        aaveWithdrawResult(locale.defiWithdrawWalletRequired, '#fca5a5');
        return;
    }
    const connectionState = await getActiveWalletSessionState(activeAddress);
    if (!connectionState.matches) {
        aaveWithdrawResult(activeWalletConnectionMessage(connectionState, locale, activeAddress), '#fca5a5');
        return;
    }
    try {
        setButtonLoading(button, true, locale.defiWithdrawLoading);
        const response = await fetch('/api/defi/aave-base/usdc-withdraw-quote', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ wallet_address: activeAddress, amount }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'aave_withdraw_quote_failed');
        activeAaveWithdrawQuote = setAaveQuoteExpiry(data);
        const gasWarning = data.gas_reserve_met ? '' : `<div style="color:#fca5a5; margin-top:5px;">${escapeHtml(locale.defiWithdrawNoGas.replace('{amount}', data.gas_reserve || ''))}</div>`;
        if (result) {
            result.innerHTML = `<div style="color:#86efac; font-weight:600;">${escapeHtml(locale.defiWithdrawReady.replace('{amount}', data.amount))}</div><div style="color:var(--text-muted); margin-top:5px;">${escapeHtml(locale.defiWithdrawAvailable.replace('{amount}', data.position_balance))}</div>${gasWarning}${data.gas_reserve_met ? `<button type="button" id="aaveWithdrawReviewButton" onclick="submitAaveUsdcWithdraw()" class="btn-purple-lg" style="font-size:12px; padding:9px 12px; width:auto; margin-top:10px;">${escapeHtml(locale.defiWithdrawReview)}</button>` : ''}`;
        }
    } catch (error) {
        const message = String(error?.message || '');
        const display = message.includes('exceeds the Aave USDC position')
            ? locale.defiWithdrawInsufficientPosition
            : locale.defiWithdrawQuoteError;
        aaveWithdrawResult(operationErrorMessage(error, locale, display), '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.defiWithdrawCheck);
    }
}

function validateAaveWithdrawTransaction(quote, fromAddress) {
    const transaction = quote?.transaction || {};
    const asset = quote?.asset || {};
    if (!window.ethers?.utils?.Interface) return false;
    try {
        const contract = new window.ethers.utils.Interface([
            'function withdraw(address asset, uint256 amount, address to) returns (uint256)',
        ]);
        const expectedData = contract.encodeFunctionData('withdraw', [
            asset.address,
            String(quote.amount_atomic),
            fromAddress,
        ]).toLowerCase();
        return transaction.chain_id === 8453
            && String(transaction.from || '').toLowerCase() === fromAddress.toLowerCase()
            && String(transaction.to || '').toLowerCase() === String(quote.pool_address || '').toLowerCase()
            && String(transaction.data || '').toLowerCase() === expectedData
            && String(transaction.value || '0') === '0';
    } catch (_) {
        return false;
    }
}

async function submitAaveUsdcWithdraw() {
    const locale = translations[getActiveLang()];
    const quote = activeAaveWithdrawQuote;
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    const button = document.getElementById('aaveWithdrawReviewButton');
    if (!quote || !provider?.request) {
        aaveWithdrawResult(locale.defiWithdrawExpired, '#fca5a5');
        return;
    }
    if (!isAaveQuoteFresh(quote)) {
        activeAaveWithdrawQuote = null;
        aaveWithdrawResult(locale.defiWithdrawExpired, '#fbbf24');
        return;
    }
    try {
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts.length) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const activeAddress = getActiveBaseWalletAddress();
        const fromAddress = (accounts || []).find((account) => String(account || '').toLowerCase() === activeAddress.toLowerCase());
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '')) throw new Error('aave_withdraw_wallet_mismatch');
        if (!validateAaveWithdrawTransaction(quote, fromAddress)) throw new Error('aave_withdraw_transaction_invalid');
        await switchToBaseMainnet(provider);
        if (!await openAaveWithdrawConfirmation(quote)) return;
        if (!isAaveQuoteFresh(quote)) {
            activeAaveWithdrawQuote = null;
            aaveWithdrawResult(locale.defiWithdrawExpired, '#fbbf24');
            return;
        }
        setButtonLoading(button, true, locale.defiWithdrawSigning);
        const txHash = await provider.request({
            method: 'eth_sendTransaction',
            params: [{ from: fromAddress, to: quote.transaction.to, data: quote.transaction.data, value: '0x0' }],
        });
        activeAaveWithdrawQuote = null;
        try {
            const submissionResponse = await fetch('/api/defi/aave-base/withdraw-submissions', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ quote_id: quote.quote_id, tx_hash: txHash }),
            });
            if (submissionResponse.ok) await loadAaveDefiHistory();
        } catch (_) {
            // The wallet transaction remains valid even if the optional notification fails.
        }
        const txUrl = `${BASE_MAINNET_CONFIG.blockExplorerUrls[0]}/tx/${encodeURIComponent(txHash)}`;
        const result = document.getElementById('aaveWithdrawResult');
        if (result) result.innerHTML = `<span style="color:#86efac;">${escapeHtml(locale.defiWithdrawSubmitted)}</span> <a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="color:#c4b5fd;">${escapeHtml(locale.defiWithdrawOpenExplorer)}</a>`;
        window.setTimeout(() => {
            loadDefiOverview(true);
            loadLendingPositions(true);
        }, 7000);
    } catch (error) {
        const rejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED';
        const message = String(error?.message || '');
        const display = message.includes('quote_expired')
            ? locale.defiWithdrawExpired
            : (message.includes('wallet_mismatch') ? locale.defiWithdrawWalletRequired : locale.defiWithdrawFailed);
        aaveWithdrawResult(rejected ? locale.defiWithdrawRejected : operationErrorMessage(error, locale, display), '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.defiWithdrawReview);
    }
}

function getOperationsJournalStatus(record) {
    const locale = translations[getActiveLang()];
    const status = String(record?.status || 'submitted');
    const keyMap = {
        submitted: 'operationsJournalStatusSubmitted',
        in_progress: 'operationsJournalStatusInProgress',
        completed: 'operationsJournalStatusCompleted',
        failed: 'operationsJournalStatusFailed',
    };
    const colors = {
        submitted: '#bfdbfe',
        in_progress: '#fde68a',
        completed: '#86efac',
        failed: '#fca5a5',
    };
    return { label: locale[keyMap[status]] || status, color: colors[status] || 'var(--text-muted)' };
}

function getOperationsJournalType(record) {
    const locale = translations[getActiveLang()];
    const type = String(record?.type || '');
    const labels = {
        bridge: locale.operationsJournalTypeBridge,
        swap: locale.operationsJournalTypeSwap,
        lending: locale.operationsJournalTypeLending,
        transfer: locale.operationsJournalTypeTransfer,
    };
    const icons = { bridge: '🌉', swap: '🔄', lending: '◈', transfer: '↗' };
    return { label: labels[type] || type, icon: icons[type] || '•' };
}

function getOperationsJournalAction(record) {
    const locale = translations[getActiveLang()];
    if (record?.type !== 'lending') return '';
    return record.operation_action === 'withdraw'
        ? (locale.defiHistoryWithdraw || 'Withdraw')
        : (locale.defiHistorySupply || 'Supply');
}

function getOperationsJournalExplorerUrl(record) {
    const explorer = UNIVERSAL_BRIDGE_NETWORKS[record?.from_network]?.blockExplorerUrls?.[0];
    const txHash = String(record?.tx_hash || '');
    if (!explorer || !/^0x[a-fA-F0-9]{64}$/.test(txHash)) return '';
    return `${explorer.replace(/\/$/, '')}/tx/${encodeURIComponent(txHash)}`;
}

function getShortOperationAddress(address) {
    const value = String(address || '');
    return /^0x[a-fA-F0-9]{40}$/.test(value) ? `${value.slice(0, 6)}…${value.slice(-4)}` : '';
}

function formatOperationsJournalUsd(value) {
    const number = Number(value);
    if (!Number.isFinite(number) || number < 0) return '';
    return `≈ $${number.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function renderOperationsJournalSummary(records) {
    const summary = document.getElementById('operationsJournalSummary');
    if (!summary) return;
    const locale = translations[getActiveLang()];
    const total = records.length;
    const pending = records.filter((record) => ['submitted', 'in_progress'].includes(record.status)).length;
    const completed = records.filter((record) => record.status === 'completed').length;
    const review = records.filter((record) => record.status === 'failed').length;
    const items = [
        [locale.operationsJournalSummaryTotal, total, '#e9d5ff'],
        [locale.operationsJournalSummaryPending, pending, '#fde68a'],
        [locale.operationsJournalSummaryCompleted, completed, '#86efac'],
        [locale.operationsJournalSummaryReview, review, '#fca5a5'],
    ];
    summary.innerHTML = items.map(([label, value, color]) => `
        <div class="operations-journal-summary-card">
            <span>${escapeHtml(label)}</span><b style="color:${color};">${Number(value)}</b>
        </div>`).join('');
}

async function loadOperationsJournal() {
    const locale = translations[getActiveLang()];
    const container = document.getElementById('operationsJournalList');
    if (!container) return;
    try {
        const params = new URLSearchParams();
        if (operationsJournalTypeFilter !== 'all') params.set('operation_type', operationsJournalTypeFilter);
        if (operationsJournalWalletFilter !== 'all') params.set('wallet_address', operationsJournalWalletFilter);
        if (['completed', 'failed'].includes(operationsJournalFilter)) params.set('status', operationsJournalFilter);
        const query = params.toString();
        const response = await fetch(`/api/operations/history${query ? `?${query}` : ''}`);
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.records)) throw new Error('operations_history_unavailable');
        const records = data.records.filter((record) => {
            if (operationsJournalFilter === 'pending') return ['submitted', 'in_progress'].includes(record.status);
            return operationsJournalFilter === 'all' || record.status === operationsJournalFilter;
        });
        renderOperationsJournalSummary(data.records);
        if (!records.length) {
            container.innerHTML = renderAppEmptyState(
                locale.emptyStateJournalTitle,
                locale.operationsJournalEmpty,
                locale.emptyStateJournalAction,
                "switchActivityPane('dex')"
            );
            return;
        }
        container.innerHTML = records.map((record) => {
            const status = getOperationsJournalStatus(record);
            const type = getOperationsJournalType(record);
            const action = getOperationsJournalAction(record);
            const txUrl = getOperationsJournalExplorerUrl(record);
            const date = new Date(Number(record.created_at) * 1000).toLocaleString();
            const output = record.amount_out ? ` → ≈ ${escapeHtml(record.amount_out)} ${escapeHtml(record.to_symbol)}` : '';
            const recipient = record.type === 'transfer' && record.recipient
                ? ` · ${locale.operationsJournalRecipient}: ${escapeHtml(getShortOperationAddress(record.recipient))}`
                : '';
            const provider = record.provider ? ` · ${escapeHtml(record.provider)}` : '';
            const providerStatus = record.provider_status ? ` · ${escapeHtml(record.provider_status)}` : '';
            const usd = formatOperationsJournalUsd(record.estimated_usd);
            return `<div class="operations-journal-row">
                <div style="min-width:0;"><div style="display:flex; flex-wrap:wrap; align-items:center; gap:7px;"><span style="font-size:12px; color:#c4b5fd;">${type.icon} ${escapeHtml(type.label)}${action ? ` · ${escapeHtml(action)}` : ''}</span><span style="font-size:11px; color:${status.color}; border:1px solid ${status.color}; border-radius:999px; padding:2px 6px;">${escapeHtml(status.label)}</span></div><div style="color:#fff; font-size:13px; font-weight:600; margin-top:7px;">${escapeHtml(record.amount_in)} ${escapeHtml(record.from_symbol)}${output}</div><div style="color:var(--text-muted); font-size:11px; line-height:1.45; margin-top:4px;">${escapeHtml(record.from_network)} → ${escapeHtml(record.to_network)} · ${escapeHtml(date)}${provider}${recipient}${providerStatus}</div></div>
                <div style="text-align:right; flex:0 0 auto;">${usd ? `<div style="color:#c4b5fd; font-size:12px; font-weight:600; white-space:nowrap;">${usd}</div>` : ''}${txUrl ? `<a href="${txUrl}" target="_blank" rel="noopener noreferrer" style="display:block; margin-top:7px; color:#c4b5fd; font-size:12px; white-space:nowrap;">${locale.universalBridgeOpenTx}</a>` : ''}</div>
            </div>`;
        }).join('');
    } catch (_) {
        renderOperationsJournalSummary([]);
        container.innerHTML = `<div style="padding:14px 0; color:#fca5a5; font-size:13px;">${locale.operationsJournalLoadError}</div>`;
    }
}

async function refreshUniversalBridgeHistoryRecord(recordId, silent = false, button = null) {
    const locale = translations[getActiveLang()];
    if (!silent && getUniversalBridgeRefreshCooldown(recordId) > 0) return null;
    try {
        if (!silent && button) setUniversalBridgeRefreshButtonLoading(button, true);
        const response = await fetch(`/api/universal-bridge/history/${encodeURIComponent(recordId)}/refresh`, { method: 'POST' });
        const data = await response.json();
        if (!response.ok || !data.record) throw new Error(data.detail || 'universal_bridge_status_unavailable');
        universalBridgeRefreshCooldowns.set(String(recordId), Date.now() + 12000);
        const record = data.record;
        const status = getUniversalBridgeRecordStatus(record);
        setUniversalBridgeResult(
            data.provider_available
                ? locale.universalBridgeStatus.replace('{status}', status.label)
                : locale.universalBridgeProviderUnavailable,
            data.provider_available ? status.color : '#fbbf24',
        );
        await loadUniversalBridgeHistory();
        return record;
    } catch (_) {
        if (button) setUniversalBridgeRefreshButtonLoading(button, false);
        if (!silent) showNotification(locale.universalBridgeProviderUnavailable, 'error');
        return null;
    }
}

async function saveUniversalBridgeSubmission(txHash, quote, fromAddress) {
    const response = await fetch('/api/universal-bridge/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            wallet_address: fromAddress,
            from_network: quote.from_network,
            to_network: quote.to_network,
            from_token_address: quote.from_token.address,
            to_token_address: quote.to_token.address,
            amount_in: quote.amount_in,
            amount_out: quote.amount_out,
            amount_out_min: quote.amount_out_min,
            provider: quote.tool || 'LI.FI',
            bridge: quote.tool_key || '',
            tx_hash: txHash,
        }),
    });
    const data = await response.json();
    if (!response.ok || !data.record) throw new Error(data.detail || 'universal_bridge_submission_unavailable');
    return data.record;
}

async function refreshUniversalBridgeStatus(txHash, quote) {
    const locale = translations[getActiveLang()];
    try {
        const params = new URLSearchParams({
            from_network: quote.from_network,
            to_network: quote.to_network,
            bridge: String(quote.tool_key || '').replace(/[^A-Za-z0-9_-]/g, ''),
        });
        const response = await fetch(`/api/universal-bridge/status/${encodeURIComponent(txHash)}?${params.toString()}`);
        const data = await response.json();
        if (!response.ok) return;
        const status = data.substatus || data.lifi_status;
        if (status) setUniversalBridgeResult(locale.universalBridgeStatus.replace('{status}', status), '#bfdbfe');
    } catch (_) {
        // Status updates are informational. The source transaction remains available in the explorer.
    }
}

async function executeUniversalBridge() {
    const locale = translations[getActiveLang()];
    const button = document.getElementById('universalBridgeReviewButton');
    const provider = walletConnectProvider?.session ? walletConnectProvider : window.ethereum;
    let quote = activeUniversalBridgeQuote;
    if (!quote || !provider?.request) {
        setUniversalBridgeResult(locale.universalBridgeInvalid, '#fca5a5');
        return;
    }
    if (Number(quote.expires_at || 0) <= Date.now()) {
        activeUniversalBridgeQuote = null;
        setUniversalBridgeReviewVisible(false);
        setUniversalBridgeResult(locale.universalBridgeQuoteExpired, '#fbbf24');
        return;
    }
    try {
        const activeAddress = getActiveBaseWalletAddress();
        const connectionState = await getActiveWalletSessionState(activeAddress);
        if (!connectionState.matches) {
            setUniversalBridgeResult(activeWalletConnectionMessage(connectionState, locale, activeAddress), '#fca5a5');
            return;
        }
        let accounts = await provider.request({ method: 'eth_accounts' });
        if (!Array.isArray(accounts) || !accounts[0]) accounts = await provider.request({ method: 'eth_requestAccounts' });
        const fromAddress = selectedEvmWalletAddresses(accounts).find(
            (address) => address.toLowerCase() === activeAddress.toLowerCase(),
        );
        if (!/^0x[0-9a-fA-F]{40}$/.test(fromAddress || '')) {
            throw new Error('universal_bridge_wallet_mismatch');
        }
        setButtonLoading(button, true, locale.universalBridgeSigning);
        quote = await ensureUniversalBridgeApproval(provider, quote, fromAddress);
        activeUniversalBridgeQuote = quote;
        if (!await openUniversalBridgeConfirmation(quote, false)) return;
        await switchToUniversalBridgeNetwork(provider, quote.from_network);
        const txHash = await provider.request({ method: 'eth_sendTransaction', params: [universalBridgeTransactionParams(quote, fromAddress)] });
        const explorer = UNIVERSAL_BRIDGE_NETWORKS[quote.from_network]?.blockExplorerUrls?.[0];
        const result = document.getElementById('universalBridgeResult');
        if (result) {
            result.style.display = '';
            result.replaceChildren();
            const message = document.createElement('span');
            message.textContent = locale.universalBridgeSubmitted;
            message.style.color = '#86efac';
            result.append(message, document.createTextNode(' '));
            if (explorer) {
                const link = document.createElement('a');
                link.href = `${explorer.replace(/\/$/, '')}/tx/${encodeURIComponent(txHash)}`;
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
                link.textContent = locale.universalBridgeOpenTx;
                link.style.color = '#c4b5fd';
                result.append(link);
            }
        }
        activeUniversalBridgeQuote = null;
        setUniversalBridgeReviewVisible(false);
        void saveUniversalBridgeSubmission(txHash, quote, fromAddress)
            .then(async () => {
                showNotification(locale.universalBridgeRecordSaved, 'success');
                await loadUniversalBridgeHistory();
            })
            .catch(() => {
                // The wallet transaction is still valid even if recording is temporarily unavailable.
                setTimeout(() => refreshUniversalBridgeStatus(txHash, quote), 12000);
            });
    } catch (error) {
        const rejected = error?.code === 4001 || error?.code === 'ACTION_REJECTED' || String(error?.message || '').includes('universal_bridge_cancelled');
        const message = String(error?.message || '');
        const display = message.includes('universal_bridge_approval_pending')
            ? locale.universalBridgeApprovalPending
            : message.includes('universal_bridge_wallet_mismatch')
                ? locale.baseSwapActiveWalletMismatch
                : message.includes('universal_bridge_network_not_selected')
                    ? locale.operationWalletNetworkRequired
                    : (rejected ? locale.universalBridgeRejected : operationErrorMessage(error, locale, locale.universalBridgeFailed));
        setUniversalBridgeResult(display, '#fca5a5');
    } finally {
        setButtonLoading(button, false, locale.universalBridgeReview);
    }
}

async function checkBridgeReadiness() {
    const locale = translations[getActiveLang()];
    const amount = getOperationBuilderAmount();
    const destination = getOperationBuilderDestination();
    const result = document.getElementById('bridgePlanResult');
    const saveButton = document.getElementById('bridgePlanSaveButton');
    const walletAddress = getActiveBaseWalletAddress();
    if (!validateOperationAmount()) {
        if (saveButton) saveButton.style.display = 'none';
        return false;
    }
    if (!amount || !destination || !/^0x[0-9a-fA-F]{40}$/.test(walletAddress)) {
        if (saveButton) saveButton.style.display = 'none';
        if (result) {
            result.textContent = locale.bridgePlanInvalid;
            result.style.color = '#fca5a5';
        }
        return false;
    }
    if (result) {
        result.textContent = locale.bridgePlanChecking;
        result.style.color = '#bfdbfe';
    }
    try {
        const [sourceResponse, destinationResponse] = await Promise.all([
            fetch('/api/gas/Base'), fetch(`/api/gas/${encodeURIComponent(destination)}`),
        ]);
        const [sourceGas, destinationGas] = await Promise.all([
            sourceResponse.json(), destinationResponse.json(),
        ]);
        if (!sourceResponse.ok || !destinationResponse.ok) throw new Error('bridge_gas_unavailable');
        if (result) {
            result.textContent = locale.bridgePlanReady
                .replace('{amount}', amount)
                .replace('{destination}', destination)
                .replace('{sourceGas}', getBridgeGasText(sourceGas))
                .replace('{destinationGas}', getBridgeGasText(destinationGas));
            result.style.color = '#86efac';
        }
        if (saveButton) saveButton.style.display = 'inline-flex';
        return true;
    } catch (error) {
        if (saveButton) saveButton.style.display = 'none';
        if (result) {
            result.textContent = locale.bridgePlanGasUnavailable;
            result.style.color = '#fbbf24';
        }
        return false;
    }
}

async function saveBridgePlan() {
    const locale = translations[getActiveLang()];
    const amount = getOperationBuilderAmount();
    const destination = getOperationBuilderDestination();
    const walletAddress = getActiveBaseWalletAddress();
    const result = document.getElementById('bridgePlanResult');
    if (!validateOperationAmount()) return;
    if (!amount || !destination || !/^0x[0-9a-fA-F]{40}$/.test(walletAddress)) {
        if (result) {
            result.textContent = locale.bridgePlanInvalid;
            result.style.color = '#fca5a5';
        }
        return;
    }
    try {
        const response = await fetch('/api/bridge-plans', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ wallet_address: walletAddress, to_network: destination, amount }),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'bridge_plan_unavailable');
        if (result) {
            result.textContent = locale.bridgePlanSaved;
            result.style.color = '#86efac';
        }
        showNotification(locale.bridgePlanSaved, 'success');
        const saveButton = document.getElementById('bridgePlanSaveButton');
        if (saveButton) saveButton.style.display = 'none';
        await loadBridgePlans();
    } catch (error) {
        if (result) {
            result.textContent = locale.bridgePlanSaveError;
            result.style.color = '#fca5a5';
        }
        showNotification(locale.bridgePlanSaveError, 'error');
    }
}

async function loadBridgePlans() {
    const container = document.getElementById('bridgePlansHistory');
    if (!container) return;
    const locale = translations[getActiveLang()];
    try {
        const response = await fetch('/api/bridge-plans');
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.plans)) throw new Error('bridge_plan_unavailable');
        if (!data.plans.length) {
            container.textContent = locale.bridgePlanEmpty;
            container.style.color = 'var(--text-muted)';
            container.style.fontSize = '12px';
            return;
        }
        container.innerHTML = data.plans.map((plan) => {
            const createdAt = new Date(Number(plan.created_at) * 1000).toLocaleString();
            return `<div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:11px 12px; margin-top:8px;"><div style="color:#fff; font-size:13px; font-weight:700;">${escapeHtml(plan.amount)} ${escapeHtml(plan.asset)} · ${escapeHtml(plan.from_network)} → ${escapeHtml(plan.to_network)}</div><div style="color:var(--text-muted); font-size:11px; margin-top:4px;">${escapeHtml(createdAt)} · ${locale.bridgePlanStatusPlanned}</div></div>`;
        }).join('');
    } catch (error) {
        container.textContent = locale.bridgePlanLoadError;
        container.style.color = '#fca5a5';
        container.style.fontSize = '12px';
    }
}

async function startScanningDrops() {
    const log = document.getElementById('drop-logs');
    const username = getCurrentUsername();
    const t = translations[currentLang];
    if (log) log.innerHTML += `<br><span style="color: var(--text-muted);">${t.lootChecking}</span>`;
    try {
        const res = await fetch(`/api/scan/${username}`, { method: 'POST' });
        const data = await res.json();
        if (!res.ok) throw new Error(data.detail || 'scan_failed');
        const summary = t.lootScanSummary
            .replace('{total}', data.data.total_wallets_scanned)
            .replace('{valid}', data.data.valid_wallets_checked);
        if (log) {
            log.innerHTML += `<br><span style="color: #86efac;">${summary}</span>`;
            log.innerHTML += `<br><span style="color: #fbbf24;">${t.lootIntegrationsPending}</span>`;
        }
    } catch (error) {
        if (log) log.innerHTML += `<br><span style="color: #fca5a5;">${translateBackendDetail(error.message)}</span>`;
    }
}

async function loadOfficialOpportunities() {
    const container = document.getElementById('officialOpportunitiesContainer');
    if (!container) return;
    const t = translations[currentLang];
    const sourceCount = document.getElementById('officialOpportunitiesCount');
    try {
        const response = await fetch('/api/opportunities');
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.sources)) throw new Error('opportunities_unavailable');
        if (sourceCount) sourceCount.textContent = t.opportunityCount.replace('{count}', String(data.sources.length));
        container.innerHTML = data.sources.map((source) => {
            const summary = source.summaries?.[getActiveLang()] || source.summaries?.en || t[`opportunity_${source.summary_key}`] || t.opportunitySummaryFallback;
            const status = source.status === 'official_updates' ? t.opportunityStatusOfficial : t.opportunityStatusPending;
            const dateLocale = { ru: 'ru-RU', en: 'en-US', zh: 'zh-CN' }[getActiveLang()] || 'en-US';
            const updatedAt = Number(source.updated_at) > 0
                ? new Date(Number(source.updated_at) * 1000).toLocaleDateString(dateLocale, { year: 'numeric', month: 'short', day: 'numeric' })
                : t.opportunityDateUnknown;
            const deleteButton = data.can_manage && !source.is_system
                ? `<button type="button" class="btn-dark-sm" onclick="deleteOfficialOpportunity(${Number(source.id)})" style="white-space:nowrap; padding:8px 11px; color:#fca5a5;">${t.opportunityDelete}</button>`
                : '';
            return `
                <article class="opportunity-source-card">
                    <div class="opportunity-source-main">
                        <div class="opportunity-source-topline">
                            <div class="opportunity-source-name">${escapeHtml(source.name)} <span>${escapeHtml(source.network)}</span></div>
                            <span class="opportunity-source-status">${escapeHtml(status)}</span>
                        </div>
                        <div class="opportunity-source-summary">${escapeHtml(summary)}</div>
                        <div class="opportunity-source-updated">${t.opportunityUpdated}: ${escapeHtml(updatedAt)}</div>
                    </div>
                    <div class="opportunity-source-actions">
                        <a href="${escapeHtml(source.official_url)}" target="_blank" rel="noopener noreferrer" class="btn-dark-sm" style="white-space:nowrap; padding:8px 11px; text-decoration:none;">${t.opportunityOfficialLink}</a>
                        ${deleteButton}
                    </div>
                </article>
            `;
        }).join('') || `<div style="color:var(--text-muted); font-size:13px;">${t.opportunityEmpty}</div>`;
        renderOpportunityAdminControls(Boolean(data.can_manage));
    } catch (error) {
        if (sourceCount) sourceCount.textContent = '';
        container.innerHTML = `<div style="color:#fca5a5; font-size:13px;">${t.opportunityLoadError}</div>`;
    }
}

async function loadLendingWalletConnectionStatus() {
    const status = document.getElementById('lendingWalletStatus');
    if (!status) return;
    const locale = translations[getActiveLang()];
    const activeAddress = getActiveBaseWalletAddress();
    if (!/^0x[0-9a-fA-F]{40}$/.test(activeAddress)) {
        status.textContent = locale.baseSwapWalletRequired;
        status.style.color = '#fbbf24';
        return;
    }
    const sessionState = await getActiveWalletSessionState(activeAddress);
    status.textContent = sessionState.matches
        ? locale.operationWalletSessionReady
            .replace('{address}', `${activeAddress.slice(0, 6)}…${activeAddress.slice(-4)}`)
            .replace('{network}', 'Base')
        : activeWalletConnectionMessage(sessionState, locale, activeAddress);
    status.style.color = sessionState.matches ? '#86efac' : '#fbbf24';
}

async function loadAirdropEligibility() {
    const container = document.getElementById('airdropEligibilityContainer');
    if (!container) return;
    const locale = translations[currentLang];
    const username = localStorage.getItem('airdrop_username');
    if (!username) {
        container.innerHTML = `<div style="color:var(--text-muted); font-size:13px;">${locale.eligibilityNoWallets}</div>`;
        return;
    }
    try {
        const response = await fetch(`/api/eligibility/${encodeURIComponent(username)}`);
        const data = await response.json();
        if (!response.ok || !Array.isArray(data.wallets) || !Array.isArray(data.claim_checks)) {
            throw new Error('eligibility_unavailable');
        }
        const wallets = data.wallets.length
            ? `<div style="color:var(--text-muted); font-size:12px; line-height:1.5; margin-bottom:12px;">${locale.eligibilityWallets}: ${data.wallets.map((wallet) => escapeHtml(wallet.label || `${wallet.address.slice(0, 6)}…${wallet.address.slice(-4)}`)).join(', ')}</div>`
            : `<div style="color:var(--text-muted); font-size:13px; line-height:1.5;">${locale.eligibilityNoWallets}</div>`;
        const checks = data.claim_checks.length
            ? data.claim_checks.map((source) => `
                <div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:12px; padding:13px; display:flex; justify-content:space-between; gap:12px; align-items:center;">
                    <div>
                        <div style="color:#fff; font-size:14px; font-weight:700;">${escapeHtml(source.name)} <span style="color:var(--text-muted); font-weight:400;">(${escapeHtml(source.network)})</span></div>
                        <div style="color:var(--text-muted); font-size:12px; margin-top:4px;">${escapeHtml(source.summaries?.[getActiveLang()] || source.summaries?.en || '')}</div>
                    </div>
                    <a href="${escapeHtml(source.claim_url)}" target="_blank" rel="noopener noreferrer" class="btn-dark-sm" style="white-space:nowrap; padding:8px 11px; text-decoration:none;">${locale.eligibilityOpenCheck}</a>
                </div>
            `).join('')
            : `<div style="color:var(--text-muted); font-size:13px; line-height:1.5;">${locale.eligibilityNoChecks}</div>`;
        container.innerHTML = `${wallets}<div style="display:flex; flex-direction:column; gap:10px;">${checks}</div><div style="color:#fbbf24; font-size:12px; line-height:1.5; margin-top:12px;">${locale.eligibilityCheckedNotice}</div>`;
    } catch (error) {
        container.innerHTML = `<div style="color:#fca5a5; font-size:13px;">${locale.eligibilityLoadError}</div>`;
    }
}

function renderOpportunityAdminControls(canManage) {
    const container = document.getElementById('officialOpportunityAdminContainer');
    if (!container) return;
    if (!canManage) {
        container.innerHTML = '';
        return;
    }
    const t = translations[currentLang];
    const fieldStyle = 'class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;"';
    container.innerHTML = `
        <div class="dashboard-card" style="margin-top:18px;">
            <h3 style="color:#fff; margin-top:0; font-size:16px;">${t.opportunityAdminTitle}</h3>
            <p style="color:var(--text-muted); font-size:13px; line-height:1.5;">${t.opportunityAdminDesc}</p>
            <form onsubmit="submitOfficialOpportunity(event)" style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
                <label style="color:var(--text-muted); font-size:12px;">${t.opportunitySourceKey}<input id="opportunitySourceKey" maxlength="40" required ${fieldStyle}></label>
                <label style="color:var(--text-muted); font-size:12px;">${t.opportunitySourceName}<input id="opportunitySourceName" maxlength="80" required ${fieldStyle}></label>
                <label style="color:var(--text-muted); font-size:12px;">${t.opportunitySourceNetwork}<input id="opportunitySourceNetwork" maxlength="80" required ${fieldStyle}></label>
                <label style="color:var(--text-muted); font-size:12px;">${t.opportunitySourceUrl}<input id="opportunitySourceUrl" type="url" maxlength="500" required ${fieldStyle}></label>
                <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.opportunityClaimUrl}<input id="opportunityClaimUrl" type="url" maxlength="500" ${fieldStyle}></label>
                <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.opportunitySourceSummaryRu}<textarea id="opportunitySourceSummaryRu" maxlength="500" required ${fieldStyle}></textarea></label>
                <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.opportunitySourceSummaryEn}<textarea id="opportunitySourceSummaryEn" maxlength="500" required ${fieldStyle}></textarea></label>
                <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.opportunitySourceSummaryZh}<textarea id="opportunitySourceSummaryZh" maxlength="500" required ${fieldStyle}></textarea></label>
                <button type="submit" class="btn-purple-lg" style="grid-column:1 / -1; font-size:13px; padding:12px 20px;">${t.opportunityPublish}</button>
            </form>
        </div>
    `;
}

async function submitOfficialOpportunity(event) {
    event.preventDefault();
    const t = translations[currentLang];
    const payload = {
        source_key: document.getElementById('opportunitySourceKey')?.value || '',
        name: document.getElementById('opportunitySourceName')?.value || '',
        network: document.getElementById('opportunitySourceNetwork')?.value || '',
        official_url: document.getElementById('opportunitySourceUrl')?.value || '',
        claim_url: document.getElementById('opportunityClaimUrl')?.value || '',
        summary_ru: document.getElementById('opportunitySourceSummaryRu')?.value || '',
        summary_en: document.getElementById('opportunitySourceSummaryEn')?.value || '',
        summary_zh: document.getElementById('opportunitySourceSummaryZh')?.value || '',
    };
    try {
        const response = await fetch('/api/opportunities', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
        });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'opportunities_unavailable');
        showNotification(t.opportunityPublished, 'success');
        await loadOfficialOpportunities();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || t.opportunityManageError, 'error');
    }
}

async function deleteOfficialOpportunity(sourceId) {
    const t = translations[currentLang];
    if (!Number.isInteger(sourceId) || !window.confirm(t.opportunityDeleteConfirm)) return;
    try {
        const response = await fetch(`/api/opportunities/${sourceId}`, { method: 'DELETE' });
        const data = await response.json();
        if (!response.ok) throw new Error(data.detail || 'opportunities_unavailable');
        showNotification(t.opportunityDeleted, 'success');
        await loadOfficialOpportunities();
    } catch (error) {
        showNotification(translateBackendDetail(error.message) || t.opportunityManageError, 'error');
    }
}

async function loadPlatformStats() {
    try {
        const res = await fetch('/api/stats');
        const data = await res.json();
        window.cachedStatsData = data;
        const counterEl = document.getElementById('slots-counter-text');
        if (counterEl) {
            counterEl.innerHTML = `${t('privateSoftware')}. <b style="color:#fff; margin-left:8px;">${data.current_slots} / ${data.max_slots} ${t('slotsShort')}</b>`;
        }

        if (data.is_sold_out) {
            const farmBtn = document.getElementById('farm-btn');
            if (farmBtn) {
                farmBtn.innerText = "Sold Out";
                farmBtn.style.opacity = "0.5";
                farmBtn.style.pointerEvents = "none";
            }
        }
    } catch (e) {
        console.error("Stats Error:", e);
    }
}

function hideProxyTip() {
    dismissInterfaceHint('wallet-proxy-tip');
}

// --- DEX, Bridges, Lending Global Handlers ---

let activeDexQuote = null;
let activeBridgeQuote = null;

function updateDexTokens() {
}

function setDexMaxAmount() {
    return useOperationMaxAmount();
}

async function requestDexQuote() {
    return requestBaseSwapQuote();
}
async function executeDexSwap() {
    return submitBaseSwap();
}
async function requestBridgeQuote() {
    return requestUniversalBridgeQuote();
}
async function executeBridgeTransfer() {
    return executeUniversalBridge();
}
async function buildLendingOperation() {
    return buildVerifiedLendingOperation();
}
async function loadLendingPositions(refresh = false) {
    const locale = translations[getActiveLang()];
    const activeAddress = getActiveBaseWalletAddress();
    const container = document.getElementById('lendingPositionsList');
    if (!container) return;

    if (!activeAddress) {
        container.textContent = locale.defiSupplyWalletRequired;
        return;
    }

    try {
        container.textContent = locale.loading;
        const username = localStorage.getItem('airdrop_username') || '';
        const walletsResponse = await fetch(`/api/wallets/${encodeURIComponent(username)}`);
        const walletsData = await walletsResponse.json();
        const wallet = walletsData.wallets?.find((item) => String(item.wallet_address || '').toLowerCase() === activeAddress.toLowerCase());
        if (!walletsResponse.ok || !wallet) throw new Error('wallet_not_saved');
        const res = await fetch(`/api/defi/aave-base-positions/${encodeURIComponent(wallet.id)}${refresh ? '?refresh=true' : ''}`);
        const data = await res.json();
        if (!res.ok || !data.positions || !data.positions.length) {
            container.innerHTML = renderAppEmptyState(
                locale.emptyStateLendingTitle,
                locale.errors?.defiOverviewEmpty || locale.defiNoPositions,
            );
            return;
        }

        const positions = data.positions.filter((position) => position.has_supply || position.has_borrow);
        if (!positions.length) {
            container.innerHTML = renderAppEmptyState(
                locale.emptyStateLendingTitle,
                locale.errors?.defiOverviewEmpty || locale.defiNoPositions,
            );
            return;
        }
        container.innerHTML = positions.map((pos) => `
            <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:10px; margin-bottom:6px;">
                <div>
                    <b>${escapeHtml(pos.asset || 'USDC')}</b><br>
                    <span style="color:var(--text-muted);">Aave V3 · Base</span>
                </div>
                <div style="text-align:right;">
                    <b>${escapeHtml(locale.errors?.defiOverviewSupplied || locale.defiOverviewSupplied || 'Supplied')}:</b> ${escapeHtml(pos.supplied || '0')}<br>
                    <span style="color:var(--text-muted);">${escapeHtml(locale.errors?.defiOverviewBorrowed || locale.defiOverviewBorrowed || 'Borrowed')}: ${escapeHtml(pos.borrowed || '0')}</span>
                </div>
            </div>
        `).join('');
    } catch (_) {
        container.textContent = locale.errors?.defiOverviewLoadError || locale.defiLoadError;
    }
}

async function buildVerifiedLendingOperation() {
    const locale = translations[getActiveLang()];
    const action = document.getElementById('lendingActionType')?.value || 'supply';
    const amount = document.getElementById('lendingAmount')?.value || '';
    const result = document.getElementById('lendingResultContainer');
    if (!result) return;
    const connectionState = await getActiveWalletSessionState();
    if (!connectionState.matches) {
        result.innerHTML = `<span style="color:#fca5a5;">${escapeHtml(activeWalletConnectionMessage(connectionState, locale))}</span>`;
        return;
    }
    result.replaceChildren();
    const hiddenAmount = document.createElement('input');
    hiddenAmount.type = 'hidden';
    hiddenAmount.value = amount;
    const quoteResult = document.createElement('div');
    if (action === 'withdraw') {
        hiddenAmount.id = 'aaveWithdrawAmount';
        quoteResult.id = 'aaveWithdrawResult';
        result.append(hiddenAmount, quoteResult);
        await requestAaveUsdcWithdrawQuote();
    } else {
        hiddenAmount.id = 'aaveSupplyAmount';
        quoteResult.id = 'aaveSupplyResult';
        result.append(hiddenAmount, quoteResult);
        await requestAaveUsdcSupplyQuote();
    }
    if (!quoteResult.textContent.trim()) quoteResult.textContent = locale.errors?.genericRequestFailed || locale.operationErrorTryAgain;
}

async function loadAccountOverview() {
    const locale = translations[getActiveLang()];
    const username = localStorage.getItem('airdrop_username') || '';
    const setText = (id, value) => {
        const element = document.getElementById(id);
        if (element) element.textContent = value;
    };
    const requestJson = async (url) => {
        const response = await fetch(url);
        const data = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(data.detail || 'account_overview_unavailable');
        return data;
    };

    try {
        const [securityResult, walletsResult, telegramResult, historyResult] = await Promise.allSettled([
            requestJson('/api/security/overview'),
            username ? requestJson(`/api/wallets/${encodeURIComponent(username)}`) : Promise.resolve({ wallets: [] }),
            requestJson('/api/telegram/status'),
            requestJson('/api/operations/history'),
        ]);
        const security = securityResult.status === 'fulfilled' ? securityResult.value : {};
        const walletData = walletsResult.status === 'fulfilled' ? walletsResult.value : { wallets: [] };
        const telegram = telegramResult.status === 'fulfilled' ? telegramResult.value : { linked: false };
        const history = historyResult.status === 'fulfilled' ? historyResult.value : { records: [] };
        const wallets = Array.isArray(walletData.wallets) ? walletData.wallets : [];
        const activeAddress = getActiveBaseWalletAddress().toLowerCase();
        const activeWallet = wallets.find((wallet) => String(wallet.wallet_address || '').toLowerCase() === activeAddress);
        const shortAddress = activeWallet ? getShortOperationAddress(activeWallet.wallet_address) : '';
        accountOverviewActiveWalletId = activeWallet?.id || null;

        setText('accountOverviewActiveWallet', activeWallet
            ? `${activeWallet.label || locale.walletDefaultName} · ${shortAddress}`
            : locale.accountOverviewNoActiveWallet);
        setText('accountOverviewWalletCount', `${wallets.length} / ${walletData.max_slots || 0}`);
        setText('accountOverviewTelegram', telegram.linked ? locale.accountOverviewConnected : locale.accountOverviewNotConnected);
        setText('accountOverviewSession', security.session_active ? locale.accountOverviewProtected : locale.accountOverviewUnavailable);
        setText('accountOverviewPlan', walletData.plan || userPlan || '—');

        const activeWalletDetail = document.getElementById('accountOverviewActiveWalletDetail');
        if (activeWalletDetail) {
            activeWalletDetail.textContent = activeWallet
                ? (activeWallet.has_proxy ? locale.walletProxyConfigured : locale.walletNoProxy)
                : locale.accountOverviewSelectWallet;
        }
        loadAccountScheduleOverview(activeWallet);
        loadAccountReadiness(activeWallet, security, telegram);

        const activityContainer = document.getElementById('accountOverviewActivity');
        if (!activityContainer) return;
        const records = Array.isArray(history.records) ? history.records.slice(0, 3) : [];
        if (!records.length) {
            activityContainer.innerHTML = `<div class="account-empty-state">${escapeHtml(locale.accountOverviewNoActivity)}</div>`;
            return;
        }
        activityContainer.innerHTML = records.map((record) => {
            const status = getOperationsJournalStatus(record);
            const type = getOperationsJournalType(record);
            const timestamp = Number(record.created_at) * 1000;
            const date = Number.isFinite(timestamp) && timestamp > 0
                ? new Date(timestamp).toLocaleDateString(currentLang === 'ru' ? 'ru-RU' : currentLang === 'zh' ? 'zh-CN' : 'en-US', { day: 'numeric', month: 'short' })
                : '—';
            const target = record.amount_out
                ? ` → ${escapeHtml(record.amount_out)} ${escapeHtml(record.to_symbol || '')}`
                : '';
            return `<div class="account-activity-row">
                <div class="account-activity-main"><span class="account-activity-type">${type.icon} ${escapeHtml(type.label)}</span><span class="account-activity-value">${escapeHtml(record.amount_in || '—')} ${escapeHtml(record.from_symbol || '')}${target}</span></div>
                <div class="account-activity-meta"><span style="color:${status.color};">${escapeHtml(status.label)}</span><span>${escapeHtml(date)}</span></div>
            </div>`;
        }).join('');
    } catch (_) {
        accountOverviewActiveWalletId = null;
        setText('accountOverviewActiveWallet', locale.accountOverviewUnavailable);
        setText('accountOverviewWalletCount', '—');
        setText('accountOverviewTelegram', locale.accountOverviewUnavailable);
        setText('accountOverviewSession', locale.accountOverviewUnavailable);
        setText('accountOverviewSchedule', locale.accountOverviewUnavailable);
        setText('accountOverviewScheduleDetail', locale.accountOverviewScheduleDesc);
        const activityContainer = document.getElementById('accountOverviewActivity');
        if (activityContainer) activityContainer.innerHTML = `<div class="account-empty-state">${escapeHtml(locale.accountOverviewLoadError)}</div>`;
        const readinessContainer = document.getElementById('accountReadinessContent');
        const readinessSummary = document.getElementById('accountReadinessSummary');
        if (readinessContainer) readinessContainer.innerHTML = `<div class="account-empty-state">${escapeHtml(locale.accountOverviewLoadError)}</div>`;
        if (readinessSummary) readinessSummary.textContent = locale.accountOverviewUnavailable;
    }
}

// --- Рендеринг Дашборда ---
function renderDashboardContent(section) {
    currentSection = section;
    const activeTranslations = translations[currentLang] || translations['ru'];
    const t = { ...activeTranslations, ...(activeTranslations.errors || {}) };
    const content = document.getElementById('dashboard-content');
    const username = getCurrentUsername();

    let centerHtml = '';
    
    if (section === 'Account') {
        const guideHtml = renderInterfaceHint('account-welcome', `${t.accWelcome}, ${username}! ${t.accountOverviewIntro}`, 'purple', '', '');
        const subscriptionStatusText = subscriptionStatus === 'grace'
            ? t.subscriptionGrace.replace('{days}', subscriptionGraceDaysLeft)
            : (subscriptionStatus === 'expired'
                ? t.subscriptionExpired
                : `${t.subActive} (${subscriptionDaysLeft} ${t.days})`);
        const subscriptionActionHtml = subscriptionStatus !== 'active'
            ? `<button type="button" onclick="openPricingModal()" class="btn-dark-sm">${t.subscriptionRenew}</button>`
            : (userPlan === 'Premium'
                ? `<p class="account-subscription-max">${t.subscriptionPremiumMax}</p>`
                : `<button type="button" onclick="openPricingModal()" class="btn-dark-sm">${t.btnChangePlan}</button>`);

        centerHtml = `
            ${guideHtml}
            <div class="account-overview-header dashboard-card">
                <div>
                    <div class="account-kicker">${t.accountOverviewKicker}</div>
                    <h2>${t.accountOverviewTitle}</h2>
                    <p>${t.accountOverviewDesc}</p>
                </div>
                <button type="button" onclick="loadAccountOverview()" class="btn-dark-sm">${t.accountOverviewRefresh}</button>
            </div>

            <div class="account-overview-grid">
                <div class="account-overview-card account-overview-card-wide">
                    <span class="account-overview-label">${t.accountOverviewActiveWallet}</span>
                    <strong id="accountOverviewActiveWallet">${t.loading}</strong>
                    <small id="accountOverviewActiveWalletDetail">${t.loading}</small>
                </div>
                <div class="account-overview-card">
                    <span class="account-overview-label">${t.accountOverviewWallets}</span>
                    <strong id="accountOverviewWalletCount">${t.loading}</strong>
                    <small>${t.accountOverviewWalletsDesc}</small>
                </div>
                <div class="account-overview-card">
                    <span class="account-overview-label">${t.accountOverviewTelegram}</span>
                    <strong id="accountOverviewTelegram">${t.loading}</strong>
                    <small>${t.accountOverviewTelegramDesc}</small>
                </div>
                <div class="account-overview-card">
                    <span class="account-overview-label">${t.accountOverviewSession}</span>
                    <strong id="accountOverviewSession">${t.loading}</strong>
                    <small>${t.accountOverviewSessionDesc}</small>
                </div>
                <div class="account-overview-card account-overview-card-wide">
                    <span class="account-overview-label">${t.accountOverviewSchedule}</span>
                    <strong id="accountOverviewSchedule">${t.loading}</strong>
                    <small id="accountOverviewScheduleDetail">${t.accountOverviewScheduleDesc}</small>
                </div>
            </div>

            <div class="account-overview-columns">
                <div class="dashboard-card account-subscription-card account-subscription-card--${subscriptionStatus}">
                    <div class="account-section-heading"><div><div class="account-kicker">${t.accountOverviewSubscription}</div><h3>${t.subTitle}</h3></div><span id="accountOverviewPlan" class="account-plan-badge">${escapeHtml(userPlan)}</span></div>
                    <p>${t.subPlan}: <b>${escapeHtml(userPlan)}</b> · ${escapeHtml(subscriptionStatusText)}</p>
                    <p class="account-subscription-note">${t.subscriptionPaymentNote}</p>
                    ${subscriptionActionHtml}
                </div>
                <div class="dashboard-card account-quick-card">
                    <div class="account-section-heading"><div><div class="account-kicker">${t.accountOverviewShortcuts}</div><h3>${t.accountOverviewQuickTitle}</h3></div></div>
                    <div class="account-quick-actions">
                        <button type="button" onclick="switchMenu(null, 'Wallets')">${t.accountOverviewGoWallets}</button>
                        <button type="button" onclick="openAccountWalletSchedule()">${t.accountOverviewOpenSchedule}</button>
                        <button type="button" onclick="switchMenu(null, 'Farming')">${t.accountOverviewGoActions}</button>
                        <button type="button" onclick="switchMenu(null, 'Settings')">${t.accountOverviewGoSettings}</button>
                    </div>
                </div>
            </div>

            <div class="dashboard-card account-readiness-card">
                <div class="account-section-heading">
                    <div><div class="account-kicker">${t.accountReadinessKicker}</div><h3>${t.accountReadinessTitle}</h3></div>
                    <span id="accountReadinessSummary" class="account-readiness-summary">${t.loading}</span>
                </div>
                <p class="account-readiness-desc">${t.accountReadinessDesc}</p>
                <div id="accountReadinessContent" class="account-readiness-grid"><div class="account-empty-state">${t.loading}</div></div>
            </div>

            <div class="dashboard-card account-activity-card">
                <div class="account-section-heading"><div><div class="account-kicker">${t.accountOverviewActivityKicker}</div><h3>${t.accountOverviewActivityTitle}</h3></div><button type="button" onclick="switchActivityPane('journal')" class="btn-dark-sm">${t.accountOverviewOpenJournal}</button></div>
                <div id="accountOverviewActivity" class="account-activity-list"><div class="account-empty-state">${t.loading}</div></div>
            </div>
        `;
        setTimeout(loadAccountOverview, 50);

} else if (section === 'Settings') {
        const notifTransactionSubmittedChecked = localStorage.getItem('ax_notify_transactions_submitted') === 'true' ? 'checked' : '';
        const notifTransactionFinalChecked = localStorage.getItem('ax_notify_transactions_final') !== 'false' ? 'checked' : '';
        const notifRemindersChecked = localStorage.getItem('ax_notify_reminders') !== 'false' ? 'checked' : '';
        const notifErrorsChecked = localStorage.getItem('ax_notify_errors') !== 'false' ? 'checked' : '';
        const notifDefiSupplySubmittedChecked = localStorage.getItem('ax_notify_defi_supply_submitted') === 'true' ? 'checked' : '';
        const notifDefiWithdrawSubmittedChecked = localStorage.getItem('ax_notify_defi_withdraw_submitted') === 'true' ? 'checked' : '';
        const notifDefiFinalChecked = localStorage.getItem('ax_notify_defi_final') === 'true' ? 'checked' : '';
        const notifDefiErrorsChecked = localStorage.getItem('ax_notify_defi_errors') === 'true' ? 'checked' : '';

        const antiSybilWarningHtml = renderInterfaceHint('settings-safety-note', `${t.setWarnTitle}. ${t.setWarnDesc}`, 'warning', '', '🛡️');

        centerHtml = `
            ${antiSybilWarningHtml}

            <div class="dashboard-card" style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 18px; padding: 22px; box-shadow: 0 8px 30px rgba(0,0,0,0.4); margin-bottom: 16px;">
                <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom: 16px; border-bottom: 1px solid var(--border-color); padding-bottom: 14px;">
                    <div>
                        <h3 style="color: #fff; margin: 0 0 4px 0; font-size: 16px; font-weight: 600;">${t.setTitle}</h3>
                        <p style="color: var(--text-muted); font-size: 13px; margin: 0;">${t.setDesc}</p>
                    </div>
                </div>

                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin-bottom: 16px;">
                    <div>
                        <label style="font-size: 12px; color: var(--text-muted); display: block; margin-bottom: 6px;">${t.setGwei}</label>
                        <input type="number" inputmode="numeric" class="auth-input" value="30" min="5" max="300" id="globalGweiInput" oninput="sanitizeIntegerInput(this, 3); checkInputLimit(this, 300)" style="padding: 10px 12px; background: var(--bg-main); border-radius: 10px; font-size: 13px;">
                    </div>
                    <div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; padding:12px;">
                        <div style="font-size:13px; color:#fff; font-weight:600;">${t.tgConnectTitle}</div>
                        <div id="telegramConnectionState" style="font-size:12px; color:var(--text-muted); margin-top:4px;">${t.tgChecking}</div>
                        <div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:10px;">
                            <button type="button" onclick="createTelegramLink()" style="background:#7c3aed; color:#fff; border:0; border-radius:8px; padding:8px 10px; cursor:pointer; font-size:12px; font-weight:600;">${t.tgConnectBtn}</button>
                            <button type="button" id="telegramTestButton" onclick="sendTelegramTest()" style="display:none; background:transparent; color:#c4b5fd; border:1px solid #7c3aed; border-radius:8px; padding:8px 10px; cursor:pointer; font-size:12px;">${t.tgTestBtn}</button>
                        </div>
                        <div id="telegramLinkResult" style="font-size:12px; color:var(--text-muted); line-height:1.4; margin-top:8px;"></div>
                    </div>
                </div>

                <div style="background: var(--bg-main); border: 1px solid var(--border-color); border-radius: 12px; padding: 16px; margin-bottom: 18px;">
                    <div style="font-size: 13px; color: #fff; font-weight: 600; margin-bottom: 12px;">${t.notifTitle}</div>
                    <div style="font-size:12px; color:var(--text-muted); line-height:1.45; margin:-4px 0 12px;">${t.notifDesc}</div>
                    <div style="display:flex; flex-wrap:wrap; gap:8px; margin:0 0 14px;">
                        <button type="button" onclick="applyTelegramNotificationPreset('important')" class="tg-notification-preset">${t.notifPresetImportant}</button>
                        <button type="button" onclick="applyTelegramNotificationPreset('all')" class="tg-notification-preset">${t.notifPresetAll}</button>
                        <button type="button" onclick="applyTelegramNotificationPreset('errors')" class="tg-notification-preset">${t.notifPresetErrors}</button>
                    </div>
                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px; font-size: 13px; color: var(--text-muted);">
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;"><input type="checkbox" id="notifTransactionSubmittedToggle" ${notifTransactionSubmittedChecked}> ${t.notifTransactionSubmitted}</label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;"><input type="checkbox" id="notifTransactionFinalToggle" ${notifTransactionFinalChecked}> ${t.notifTransactionFinal}</label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;"><input type="checkbox" id="notifRemindersToggle" ${notifRemindersChecked}> ${t.notifReminders}</label>
                        <label style="display: flex; align-items: center; gap: 8px; cursor: pointer;"><input type="checkbox" id="notifErrorsToggle" ${notifErrorsChecked}> ${t.notifErrors}</label>
                    </div>
                    <div style="border-top:1px solid var(--border-color); margin-top:14px; padding-top:12px;">
                        <div style="color:#e9d5ff; font-size:12px; font-weight:700;">${t.notifDefiTitle}</div>
                        <div style="font-size:11px; color:var(--text-muted); line-height:1.45; margin:4px 0 10px;">${t.notifDefiDesc}</div>
                        <div style="display:grid; grid-template-columns:1fr 1fr; gap:10px; font-size:13px; color:var(--text-muted);">
                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer;"><input type="checkbox" id="notifDefiSupplySubmittedToggle" ${notifDefiSupplySubmittedChecked}> ${t.notifDefiSupplySubmitted}</label>
                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer;"><input type="checkbox" id="notifDefiWithdrawSubmittedToggle" ${notifDefiWithdrawSubmittedChecked}> ${t.notifDefiWithdrawSubmitted}</label>
                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer;"><input type="checkbox" id="notifDefiFinalToggle" ${notifDefiFinalChecked}> ${t.notifDefiFinal}</label>
                            <label style="display:flex; align-items:center; gap:8px; cursor:pointer;"><input type="checkbox" id="notifDefiErrorsToggle" ${notifDefiErrorsChecked}> ${t.notifDefiErrors}</label>
                        </div>
                    </div>
                </div>

                <div style="background:var(--bg-main); border:1px solid var(--border-color); border-radius:12px; padding:16px; margin-bottom:18px;">
                    <div style="display:flex; justify-content:space-between; gap:12px; align-items:center; margin-bottom:5px;">
                        <div style="font-size:13px; color:#fff; font-weight:700;">${t.securityOverviewTitle}</div>
                        <button type="button" onclick="loadSecurityOverview()" class="tg-notification-preset">${t.securityRefresh}</button>
                    </div>
                    <div style="font-size:12px; color:var(--text-muted); line-height:1.45; margin-bottom:8px;">${t.securityOverviewDesc}</div>
                    <div id="securityOverviewContent" style="margin-bottom:13px;"></div>
                    <div style="border-top:1px solid var(--border-color); padding-top:12px; color:#bfdbfe; font-size:12px; line-height:1.55;">
                        <div style="font-weight:700; color:#e9d5ff; margin-bottom:4px;">${t.securityGuarantees}</div>
                        <div>• ${t.securityNoKeys}</div>
                        <div>• ${t.securityConfirm}</div>
                        <div>• ${t.securitySingleSession}</div>
                    </div>
                </div>

                <button type="button" onclick="saveGlobalProfileSettings()" class="btn-modal-primary" style="width:100%; padding: 12px; font-size: 14px; font-weight: 600; border-radius: 12px; cursor: pointer;">${t.btnSaveSet}</button>
            </div>

            <div class="dashboard-card" style="background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 18px; padding: 22px; box-shadow: 0 8px 30px rgba(0,0,0,0.4);">
                <div style="color: #fff; font-weight: 700; font-size: 16px; margin-bottom: 4px;">${t.setInterfaceTitle}</div>
                <div style="color: var(--text-muted); font-size: 13px; margin-bottom: 14px;">${t.setInterfaceDesc}</div>
                <div style="display:flex; flex-direction:column; gap:16px;">
                    <label style="display: flex; align-items: center; justify-content: space-between; cursor: pointer;">
                        <span style="padding-right:16px;">
                            <span style="display:block; color:#fff; font-size:13px; font-weight:600;">${t.setInterfaceHintsToggle}</span>
                            <span style="display:block; color:var(--text-muted); font-size:12px; line-height:1.45; margin-top:3px;">${t.setInterfaceHintsToggleDesc}</span>
                        </span>
                        <span class="toggle-switch" style="flex:0 0 auto;">
                            <input type="checkbox" ${areInterfaceHintsEnabled() ? 'checked' : ''} onchange="toggleInterfaceHints(this)">
                            <span class="toggle-slider"></span>
                        </span>
                    </label>
                </div>
            </div>
        `;
        setTimeout(() => {
            refreshTelegramConnectionState();
            loadSecurityOverview();
        }, 50);

    } else if (section === 'Looter') {
        centerHtml = `
            <div class="dashboard-card">
                <div class="opportunity-monitor-heading">
                    <div>
                        <span class="account-kicker">OFFICIAL SOURCES</span>
                        <h3>${t.lootTitle}</h3>
                    </div>
                    <button type="button" onclick="loadOfficialOpportunities(); loadAirdropEligibility();" class="btn-dark-sm opportunity-refresh">${t.opportunityRefresh}</button>
                </div>
                <p style="color: var(--text-muted); font-size: 13px; line-height: 1.5;">${t.lootDesc}</p>
                <button type="button" onclick="startScanningDrops()" class="btn-purple-lg" style="font-size: 13px; padding: 12px 20px; width:auto; margin-top: 4px;">${t.btnScan}</button>
                <div id="drop-logs" class="opportunity-scan-log">${t.logInitLoot}</div>
            </div>
            <div class="dashboard-card">
                <h3 style="color:#fff; margin-top:0; font-size:16px;">${t.eligibilityTitle}</h3>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5;">${t.eligibilityDesc}</p>
                <div id="airdropEligibilityContainer" style="display:flex; flex-direction:column; gap:10px;">${t.loading}</div>
            </div>
            <div class="dashboard-card">
                <div class="opportunity-monitor-heading">
                    <div>
                        <h3>${t.opportunitiesTitle}</h3>
                        <span id="officialOpportunitiesCount" class="opportunity-count"></span>
                    </div>
                </div>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5;">${t.opportunitiesDesc}</p>
                <div class="opportunity-safety-note">${t.opportunitySafetyNotice}</div>
                <div id="officialOpportunitiesContainer" style="display:flex; flex-direction:column; gap:10px;">${t.loading}</div>
                <div id="officialOpportunityAdminContainer"></div>
            </div>
        `;
        setTimeout(() => {
            loadOfficialOpportunities();
            loadAirdropEligibility();
        }, 50);
        } else if (section === 'Farming') {
        const storedActivityPane = localStorage.getItem('ax_activity_pane');
        const activityPane = ['dex', 'bridges', 'lending', 'journal'].includes(storedActivityPane) ? storedActivityPane : 'dex';
        const rememberedBridgeSource = localStorage.getItem('ax_bridge_source_network');
        const bridgeSourceNetwork = UNIVERSAL_BRIDGE_NETWORKS[rememberedBridgeSource] ? rememberedBridgeSource : 'Base';
        const bridgeDestinationNetwork = bridgeSourceNetwork === 'Arbitrum' ? 'Base' : 'Arbitrum';

        const activityTabs = [
            ['dex', t.activityTabDex || 'DEX'],
            ['bridges', t.activityTabBridges || 'Bridges'],
            ['lending', t.activityTabLending || 'Lending'],
            ['journal', t.activityTabJournal || 'Journal'],
        ].map(([key, label]) => `<button type="button" onclick="switchActivityPane('${key}')" style="background:${activityPane === key ? 'rgba(124,58,237,.22)' : 'var(--bg-main)'}; color:${activityPane === key ? '#e9d5ff' : 'var(--text-muted)'}; border:1px solid ${activityPane === key ? '#7c3aed' : 'var(--border-color)'}; padding:9px 11px; border-radius:9px; cursor:pointer; font-size:12px; white-space:nowrap;">${label}</button>`).join('');
        const dexGuide = renderOperationGuide('operation-guide-dex', t.operationGuideTitle || 'How it works', t.operationGuideDex || '', 'dex');
        const bridgesGuide = renderOperationGuide('operation-guide-bridges', t.operationGuideTitle || 'How it works', t.operationGuideBridges || '', 'bridges');
        const lendingGuide = renderOperationGuide('operation-guide-lending', t.operationGuideTitle || 'How it works', t.operationGuideLending || '', 'lending');
        const activeWalletConnectControls = (networkExpression = "'Base'") => `
            <div class="operation-wallet-connect">
                <button type="button" onclick="connectActiveWalletForActions(this, ${networkExpression})" class="btn-dark-sm operation-wallet-connect-button">${t.operationConnectActiveWallet}</button>
                <button type="button" onclick="connectActiveWalletWithWalletConnect(this, ${networkExpression})" class="btn-dark-sm operation-wallet-connect-button operation-wallet-connect-wc">${t.btnConnectWalletConnect}</button>
            </div>
        `;

        const dexPane = `
            <div class="dashboard-card" style="margin-bottom:16px;">
                <h3 style="color:#fff; margin:0 0 5px; font-size:16px;">${t.dexTitle || 'DEX Exchange'}</h3>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5; margin:0 0 14px;">${t.dexDesc || 'Verified ETH → USDC route through Uniswap on Base.'}</p>
                ${dexGuide}
                <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelChain || 'Sender Chain'}
                        <select id="operationSourceNetwork" class="auth-input" disabled style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="Base">Base</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelProvider || 'Provider'}
                        <select class="auth-input" disabled style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="uniswap">Uniswap</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelTokenIn || 'From Token'}
                        <select id="operationSourceAsset" class="auth-input" disabled style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="${UNIVERSAL_BRIDGE_NATIVE_TOKEN}">ETH</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelTokenOut || 'To Token'}
                        <select class="auth-input" disabled style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="USDC">USDC</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.labelAmount || 'Amount'}
                        <input id="operationAmount" inputmode="decimal" placeholder="0.01" oninput="sanitizeDecimalInput(this, 18); validateOperationAmount()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                    </label>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; font-size:12px;">
                    <span id="operationAmountAvailability" style="color:var(--text-muted);">${t.loading}</span>
                    <button type="button" class="btn-dark-sm" onclick="useOperationMaxAmount()" style="padding:4px 8px; font-size:11px;">${t.maxShort || 'MAX'}</button>
                </div>
                <div id="operationWalletStatus" style="margin-top:8px; color:var(--text-muted); font-size:12px;">${t.loading}</div>
                ${activeWalletConnectControls()}
                <div style="margin-top:10px;">
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelSlippage || 'Slippage'}:
                        <select id="dexSlippage" class="auth-input" style="margin-top:5px; font-size:13px; padding:6px 12px;">
                            <option value="0.5">0.5%</option>
                            <option value="1.0">1.0%</option>
                        </select>
                    </label>
                </div>
                <button type="button" id="baseSwapQuoteButton" onclick="requestBaseSwapQuote()" class="btn-purple-lg" style="margin-top:14px; width:100%; font-size:13px; padding:12px;">${t.dexGetQuote || 'Get Quote'}</button>
                <div id="baseSwapResult" style="margin-top:12px; padding:12px; background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; font-size:12px;"></div>
            </div>
        `;

        const bridgesPane = `
            <div class="dashboard-card" style="margin-bottom:16px;">
                <h3 style="color:#fff; margin:0 0 5px; font-size:16px;">${t.bridgesTitle || 'Bridges Routing'}</h3>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5; margin:0 0 14px;">${t.bridgesDesc || 'Live cross-network routes supplied and validated through LI.FI.'}</p>
                ${bridgesGuide}
                <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelFromNetwork || 'From Network'}
                        <select id="operationSourceNetwork" onchange="handleOperationSourceNetworkChange()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            ${Object.keys(UNIVERSAL_BRIDGE_NETWORKS).map((network) => `<option value="${escapeHtml(network)}"${network === bridgeSourceNetwork ? ' selected' : ''}>${escapeHtml(network)}</option>`).join('')}
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelToNetwork || 'To Network'}
                        <select id="operationDestinationNetwork" onchange="handleOperationDestinationNetworkChange()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            ${Object.keys(UNIVERSAL_BRIDGE_NETWORKS).map((network) => `<option value="${escapeHtml(network)}"${network === bridgeDestinationNetwork ? ' selected' : ''}>${escapeHtml(network)}</option>`).join('')}
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelTokenIn || 'From Token'}
                        <select id="operationSourceAsset" onchange="handleOperationSourceTokenChange()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;"><option value="">${t.loading}</option></select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelTokenOut || 'To Token'}
                        <select id="operationReceiveAsset" onchange="handleOperationDestinationTokenChange()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;"><option value="">${t.loading}</option></select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.labelAmount || 'Amount'}
                        <input id="operationAmount" inputmode="decimal" placeholder="0.01" oninput="sanitizeDecimalInput(this, 18); validateOperationAmount()" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                    </label>
                </div>
                <div style="display:flex; justify-content:space-between; align-items:center; margin-top:10px; font-size:12px;">
                    <span id="operationAmountAvailability" style="color:var(--text-muted);">${t.loading}</span>
                    <button type="button" class="btn-dark-sm" onclick="useOperationMaxAmount()" style="padding:4px 8px; font-size:11px;">${t.maxShort || 'MAX'}</button>
                </div>
                <div id="operationWalletStatus" style="margin-top:8px; color:var(--text-muted); font-size:12px;">${t.loading}</div>
                ${activeWalletConnectControls('getOperationBuilderSource()')}
                <div id="universalBridgeCatalogStatus" style="margin-top:6px; color:var(--text-muted); font-size:12px;"></div>
                <button type="button" id="universalBridgeQuoteButton" onclick="requestUniversalBridgeQuote()" class="btn-purple-lg" style="margin-top:14px; width:100%; font-size:13px; padding:12px;">${t.bridgeGetQuote || 'Get Quote'}</button>
                <button type="button" id="universalBridgeReviewButton" onclick="executeUniversalBridge()" class="btn-dark-sm" style="display:none; margin-top:9px; width:100%; padding:11px; border-color:#7c3aed;">${t.universalBridgeReview}</button>
                <div id="universalBridgeResult" style="display:none; margin-top:12px; padding:12px; background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; font-size:12px;"></div>
            </div>
        `;

        const lendingPane = `
            <div class="dashboard-card" style="margin-bottom:16px;">
                <h3 style="color:#fff; margin:0 0 5px; font-size:16px;">${t.lendingTitle || 'Lending Markets'}</h3>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5; margin:0 0 14px;">${t.lendingDesc || 'DeFi Lending credit protocols integrations: Aave V3.'}</p>
                ${lendingGuide}
                <div style="display:grid; grid-template-columns:repeat(2,minmax(0,1fr)); gap:10px;">
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelChain || 'Network'}
                        <select id="lendingNetwork" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="Base">Base</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelProtocol || 'Protocol'}
                        <select id="lendingProtocol" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="aave_v3">Aave V3</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelAsset || 'Asset'}
                        <select id="lendingAsset" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="USDC">USDC</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px;">${t.labelAction || 'Action'}
                        <select id="lendingActionType" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                            <option value="supply">${t.actionSupply || 'Supply'}</option>
                            <option value="withdraw">${t.actionWithdraw || 'Withdraw'}</option>
                        </select>
                    </label>
                    <label style="color:var(--text-muted); font-size:12px; grid-column:1 / -1;">${t.labelAmount || 'Amount'}
                        <input id="lendingAmount" inputmode="decimal" placeholder="10.0" oninput="sanitizeDecimalInput(this, 6)" class="auth-input" style="margin-top:5px; font-size:13px; padding:10px 12px;">
                    </label>
                </div>
                <div id="lendingWalletStatus" style="margin-top:10px; color:var(--text-muted); font-size:12px;">${t.loading}</div>
                ${activeWalletConnectControls()}
                <div style="margin-top:10px; font-size:12px; color:var(--text-muted);">${t.lendingLiveRateNote || 'The live variable rate and available balance are checked before wallet confirmation.'}</div>
                <button type="button" id="lendingBuildButton" onclick="buildVerifiedLendingOperation()" class="btn-purple-lg" style="margin-top:14px; width:100%; font-size:13px; padding:12px;">${t.lendingSubmit || 'Supply / Withdraw'}</button>
                <div id="lendingResultContainer" style="margin-top:12px; padding:12px; background:var(--bg-main); border:1px solid var(--border-color); border-radius:10px; font-size:12px;"></div>
            </div>
            <div class="dashboard-card">
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:10px;"><h3 style="color:#fff; margin:0; font-size:15px;">${t.lendingPositionsTitle || 'Active Positions'}</h3><button type="button" class="btn-dark-sm" onclick="loadLendingPositions(true)" style="padding:7px 10px; font-size:11px;">${t.accountOverviewRefresh || 'Refresh'}</button></div>
                <div id="lendingPositionsList" style="font-size:12px; color:var(--text-muted);">${t.loading}</div>
            </div>
        `;

        const journalFilters = [
            ['all', t.operationsJournalAll], ['pending', t.operationsJournalPending], ['completed', t.operationsJournalCompleted], ['failed', t.operationsJournalIssues],
        ].map(([key, label]) => `<button type="button" onclick="setOperationsJournalFilter('${key}')" style="background:${operationsJournalFilter === key ? 'rgba(124,58,237,.22)' : 'var(--bg-main)'}; color:${operationsJournalFilter === key ? '#e9d5ff' : 'var(--text-muted)'}; border:1px solid ${operationsJournalFilter === key ? '#7c3aed' : 'var(--border-color)'}; padding:7px 10px; border-radius:8px; cursor:pointer; font-size:12px;">${label}</button>`).join('');
        const journalAction = `<div style="display:flex; flex-wrap:wrap; gap:8px; justify-content:flex-end;"><button type="button" onclick="loadOperationsJournal()" class="btn-dark-sm" style="padding:7px 10px; font-size:12px; white-space:nowrap;">${t.operationsJournalRefresh}</button>${operationsJournalFilter === 'pending' ? `<button type="button" id="operationsJournalCheckButton" onclick="checkPendingOperations(this)" class="btn-dark-sm" style="padding:7px 10px; font-size:12px; white-space:nowrap; border-color:#7c3aed;">${t.operationsJournalCheckPending}</button>` : ''}</div>`;
        const journalPane = `<div class="dashboard-card operations-journal-card"><div class="operations-journal-heading"><div><h3>${t.operationsJournalTitle}</h3><p>${t.operationsJournalDesc}</p></div>${journalAction}</div><div class="operations-journal-summary" id="operationsJournalSummary"><span style="color:var(--text-muted); font-size:12px;">${t.loading}</span></div><div class="operations-journal-toolbar"><div class="operations-journal-filter-group">${journalFilters}</div><label>${t.operationsJournalTypeLabel}<select id="operationsJournalTypeFilter" onchange="setOperationsJournalTypeFilter(this.value)" class="auth-input"><option value="all"${operationsJournalTypeFilter === 'all' ? ' selected' : ''}>${t.operationsJournalTypeAll}</option><option value="bridge"${operationsJournalTypeFilter === 'bridge' ? ' selected' : ''}>${t.operationsJournalTypeBridge}</option><option value="swap"${operationsJournalTypeFilter === 'swap' ? ' selected' : ''}>${t.operationsJournalTypeSwap}</option><option value="lending"${operationsJournalTypeFilter === 'lending' ? ' selected' : ''}>${t.operationsJournalTypeLending}</option><option value="transfer"${operationsJournalTypeFilter === 'transfer' ? ' selected' : ''}>${t.operationsJournalTypeTransfer}</option></select></label><label>${t.operationsJournalWalletLabel}<select id="operationsJournalWalletFilter" onchange="setOperationsJournalWalletFilter(this.value)" class="auth-input"><option value="all">${t.operationsJournalWalletAll}</option></select></label></div><div id="operationsJournalList" style="margin-top:12px;"><span style="color:var(--text-muted); font-size:13px;">${t.loading}</span></div></div>`;

        const activePane = { dex: dexPane, bridges: bridgesPane, lending: lendingPane, journal: journalPane }[activityPane];
        
        centerHtml = `
            <div class="dashboard-card" style="margin-bottom:16px;">
                <h3 style="color:#fff; margin:0 0 5px; font-size:17px;">${t.activityTitle}</h3>
                <p style="color:var(--text-muted); font-size:13px; line-height:1.5; margin:0 0 14px;">${t.activityDesc}</p>
                <div style="display:flex; flex-wrap:wrap; gap:8px;">${activityTabs}</div>
            </div>
            ${activePane}
        `;
        
        if (activityPane === 'dex') setTimeout(loadOperationBuilderWalletStatus, 50);
        if (activityPane === 'bridges') setTimeout(loadOperationBuilderWalletStatus, 50);
        if (activityPane === 'lending') setTimeout(() => {
            loadLendingPositions();
            loadLendingWalletConnectionStatus();
        }, 50);
        if (activityPane === 'journal') setTimeout(() => {
            loadOperationsJournalWalletOptions();
            loadOperationsJournal();
        }, 50);
    } else if (section === 'Wallets') {
        centerHtml = `
            <div class="dashboard-card" style="margin-bottom: 16px;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                    <h3 style="color: #fff; margin: 0; font-size: 16px;">${t.walTitle}</h3>
                    <span id="slot-info-badge" style="font-size: 12px; background: #1f1f1f; color: #fff; padding: 6px 12px; border-radius: 8px; border: 1px solid var(--border-color);">${t.loading}</span>
                </div>
                <div id="walletsListContainer" style="display: flex; flex-direction: column; gap: 8px;">${t.loading}</div>
                <div style="margin-top: 12px; color: var(--text-muted); font-size: 12px; line-height: 1.5;">${t.slotsPurchaseUnavailable}</div>
                <div id="buySlotMsg" style="margin-top: 6px; font-size:12px;"></div>
            </div>
            <div class="dashboard-card">
                <h3 style="color: #fff; margin-top: 0; font-size: 16px;">${t.walletConnectTitle}</h3>
                <p style="color: var(--text-muted); font-size: 13px; line-height: 1.5; margin-bottom: 10px;">${t.walletConnectDesc}</p>
                <div style="display:flex; flex-wrap:wrap; gap:8px;">
                    <button type="button" onclick="connectBaseWallet(true)" class="btn-dark-sm" style="width:auto; padding:10px 14px;">${t.btnConnectBase}</button>
                    <button type="button" onclick="connectWalletConnectBase()" class="btn-dark-sm" style="width:auto; padding:10px 14px; border-color:#7c3aed;">${t.btnConnectWalletConnect}</button>
                    <button type="button" id="disconnectBaseWalletButton" onclick="disconnectBaseWalletSession()" class="btn-dark-sm" style="display:none; width:auto; padding:10px 14px; border-color:#ef4444; color:#fca5a5;">${t.walletDisconnect}</button>
                </div>
                <div id="baseWalletConnectionStatus" style="display:none; color:#86efac; font-size:12px; margin-top:8px;"></div>
            </div>
        `;
        setTimeout(() => {
            updateBaseWalletConnectionState();
            loadWalletsFromDB();
            injectWalletSecurityBanner();
        }, 50);
    } else if (section === 'Networks') {
        const networksHtml = NETWORKS_CONFIG.map(net => `
            <article class="network-overview-card">
                <div class="network-overview-head">
                    <div style="display:flex; align-items:center; gap:10px; min-width:0;">
                        <div class="network-overview-icon">${net.icon}</div>
                        <div style="min-width:0;"><div class="network-overview-name">${net.name}</div><div class="network-overview-symbol">${net.symbol} · EVM</div></div>
                    </div>
                    <span id="networkStatus-${networkDomId(net.key)}" class="network-overview-status">${t.loading}</span>
                </div>
                <div id="networkOverview-${networkDomId(net.key)}" class="network-overview-data">${t.loading}</div>
                <div class="network-overview-gas"><span>${t.gasLabel}</span><b id="networkGas-${networkDomId(net.key)}">${t.loading}</b></div>
                <div class="network-overview-actions">
                    <button type="button" onclick="openBridgeFromNetwork('${net.key.replace(/'/g, "\\'")}')" class="btn-dark-sm">${t.networkOverviewOpenBridge}</button>
                    <a href="${net.explorer}" target="_blank" rel="noopener noreferrer">${t.btnExp}</a>
                </div>
            </article>
        `).join('');

        centerHtml = `
            <div class="dashboard-card">
                <div class="network-overview-title-row"><div><h3>${t.networkOverviewTitle}</h3><p>${t.networkOverviewDesc}</p></div><button type="button" class="btn-dark-sm" onclick="loadNetworksOverview()">${t.networkOverviewRefresh}</button></div>
                <div class="network-overview-toolbar">
                    <label>${t.networkOverviewWallet}<select id="networkOverviewWallet" onchange="setNetworkOverviewWallet(this.value)" class="auth-input" disabled><option>${t.loading}</option></select></label>
                    <div><b>${t.networkOverviewCount.replace('{count}', NETWORKS_CONFIG.length)}</b><span id="networkOverviewStatus">${t.loading}</span></div>
                </div>
                <p class="network-overview-note">${t.gasStatusNote}</p>
                <div class="network-overview-grid">${networksHtml}</div>
            </div>
        `;
        setTimeout(loadNetworksOverview, 50);
    }

    // Общий вывод дашборда
    content.innerHTML = `
        <div class="dashboard-topbar">
            <div class="dashboard-identity">
                <span class="dashboard-identity__mark">AX</span>
                <span class="dashboard-identity__copy">
                    <b>${username}</b>
                    <small>${userPlan} · ${subscriptionStatus === 'active' ? `${t.subActive} · ${subscriptionDaysLeft} ${t.days}` : (subscriptionStatus === 'grace' ? t.subscriptionGrace.replace('{days}', subscriptionGraceDaysLeft) : t.subscriptionExpired)}</small>
                </span>
            </div>
            <nav class="dashboard-topnav" aria-label="${t.menuMain}">
                <button type="button" class="dashboard-nav-item ${section === 'Account' ? 'active' : ''}" onclick="switchMenu(this, 'Account')">${t.menuAcc}</button>
                <button type="button" class="dashboard-nav-item ${section === 'Looter' ? 'active' : ''}" onclick="switchMenu(this, 'Looter')">${t.menuLooter}</button>
                <button type="button" class="dashboard-nav-item ${section === 'Farming' ? 'active' : ''}" onclick="switchMenu(this, 'Farming')">${t.menuFarm}</button>
                <button type="button" class="dashboard-nav-item ${section === 'Wallets' ? 'active' : ''}" onclick="switchMenu(this, 'Wallets')">${t.menuWallets}</button>
                <button type="button" class="dashboard-nav-item ${section === 'Networks' ? 'active' : ''}" onclick="switchMenu(this, 'Networks')">${t.menuNet}</button>
                <button type="button" class="dashboard-nav-item ${section === 'Settings' ? 'active' : ''}" onclick="switchMenu(this, 'Settings')">${t.menuSet}</button>
            </nav>
            <button type="button" class="dashboard-logout" onclick="logoutUser()">${t.menuExit}</button>
        </div>
        <div class="dashboard-main">${centerHtml}</div>
    `;
    syncMobileNavigation();
}
